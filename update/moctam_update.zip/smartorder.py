# -*- coding: utf-8 -*-
"""Đọc đơn hàng từ ảnh / file / văn bản -> dữ liệu có cấu trúc -> đối chiếu bảng giá.

Có 2 cách đọc:
  1) AI (Claude API) – đọc được ảnh chụp, ảnh tin nhắn, file scan, chữ viết tay, văn bản lộn xộn. Cần API key + internet.
  2) Quy tắc (không cần mạng) – chỉ đọc được văn bản/file có chữ (txt, docx, xlsx, pdf có chữ, dán trực tiếp).
Phần đối chiếu bảng giá (tìm sản phẩm gần giống nhất, lấy giá khi file không có giá) luôn chạy trên máy."""
import base64, difflib, io, json, os, re, unicodedata, urllib.error, urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = "claude-sonnet-5-5"
IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".heic", ".heif"}
TEXT_EXT = {".txt", ".csv", ".docx", ".xlsx", ".xlsm", ".pdf", ".md"}

SYSTEM_PROMPT = """Bạn là trợ lý nhập liệu của công ty nội thất Mộc Tâm Furniture (Việt Nam).
Nhiệm vụ: đọc đơn đặt hàng của khách (ảnh chụp, ảnh tin nhắn, file hoặc văn bản) và trích xuất thông tin để lập hóa đơn.
Chỉ trả về MỘT đối tượng JSON, không kèm lời giải thích, không dùng markdown. Cấu trúc:
{
 "customer": {"name": "", "phone": "", "address": ""},
 "order_type": "loose" | "wood" | "unknown",
 "wood_kind": "roi" | "congtrinh" | "unknown",
 "items": [
   {"name": "tên sản phẩm/hạng mục đúng như khách ghi (giữ kích thước nếu có)", "qty": 1, "unit": "cái|bộ|m2|md|... hoặc null",
    "dai": số mm hoặc null, "cao": số mm hoặc null, "sau": số mm hoặc null,
    "price": đơn giá 1 đơn vị (VNĐ, số nguyên) hoặc null, "amount": thành tiền của cả dòng (VNĐ) hoặc null, "note": "ghi chú của dòng nếu có"}
 ],
 "advance": số tiền khách đã ứng/cọc (VNĐ) hoặc null, "advance_pct": nếu khách ghi ứng/cọc theo % (vd 30) thì điền số %, ngược lại null,
 "notes": "ghi chú chung khác (ngày giao, yêu cầu...)"
}
Quy tắc: KHÔNG bịa dữ liệu – không có thì để "" hoặc null. Tiền đổi ra số nguyên VNĐ (2tr5 = 2500000, 300k = 300000).
Nếu chỉ có thành tiền mà không có đơn giá thì điền "amount", để "price" là null. Mỗi sản phẩm một phần tử, giữ đúng thứ tự trong đơn.
Số điện thoại viết liền không dấu cách. "order_type": "wood" nếu là hàng đóng theo kích thước (tủ bếp, tủ áo, ốp vách... tính theo m2/md), "loose" nếu là nội thất bán sẵn theo mẫu/bộ, không chắc thì "unknown"."""


# ----------------------------------------------------------------------------- tiện ích chuỗi
def strip_acc(s):
    s = unicodedata.normalize("NFD", str(s or "").replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def norm_text(s):
    return re.sub(r"[^a-z0-9]+", " ", strip_acc(s).lower()).strip()


def _meters(s):
    """1m6 -> 1600 ; 2m -> 2000 (chỉ để so khớp kích thước)."""
    s = re.sub(r"\b(\d)\s*m\s*(\d)\b", lambda m: str(int(m[1]) * 1000 + int(m[2]) * 100), s, flags=re.I)
    return re.sub(r"\b(\d)\s*m\b", lambda m: str(int(m[1]) * 1000), s, flags=re.I)


# ----------------------------------------------------------------------------- tiền
_MONEY_TR = re.compile(r"(\d+)(?:[.,](\d+))?\s*(?:triệu|trieu|tr)(?![A-Za-zÀ-ỹ])\s*(\d{1,3})?(?!\d)", re.I)
_MONEY_K = re.compile(r"(\d+(?:[.,]\d+)?)\s*k\b", re.I)
_MONEY_PLAIN = re.compile(r"(?<![\d.,])(\d{1,3}(?:[.,]\d{3})+|\d{4,})(?![\d])(?:\s*(đ|₫|vnd|vnđ|d)\b)?", re.I)


def find_moneys(s):
    """Danh sách (start, end, giá_trị) các số tiền trong dòng, theo thứ tự xuất hiện."""
    out = []
    for m in _MONEY_TR.finditer(s):
        v = int(m[1]) * 1_000_000
        if m[2]:
            v += int(m[2].ljust(6, "0")[:6])
        elif m[3]:
            v += int(m[3].ljust(6, "0")[:6])
        out.append((m.start(), m.end(), v))
    for m in _MONEY_K.finditer(s):
        if any(a <= m.start() < b for a, b, _ in out):
            continue
        out.append((m.start(), m.end(), int(round(float(m[1].replace(",", ".")) * 1000))))
    for m in _MONEY_PLAIN.finditer(s):
        if any(a <= m.start() < b for a, b, _ in out):
            continue
        v = int(re.sub(r"[.,]", "", m[1]))
        if v >= 10000 or (m[2] and v >= 1000):
            out.append((m.start(), m.end(), v))
    return sorted(out)


def to_money(x):
    """'2.500.000đ' / '2tr5' / '300k' / 2500000 -> int hoặc None."""
    if x is None or x == "":
        return None
    if isinstance(x, (int, float)):
        return int(round(x))
    s = str(x).strip()
    ms = find_moneys(s)
    if ms:
        return ms[0][2]
    d = re.sub(r"[^\d]", "", s)
    return int(d) if d else None


# ----------------------------------------------------------------------------- chuẩn hóa kết quả (AI + quy tắc dùng chung)
def _num(x):
    try:
        if x in (None, ""):
            return None
        v = float(str(x).replace(",", ".")) if not isinstance(x, (int, float)) else float(x)
        return v if v > 0 else None
    except ValueError:
        return None


def _phone(s):
    d = re.sub(r"[^\d+]", "", str(s or ""))
    if d.startswith("+84"):
        d = "0" + d[3:]
    elif d.startswith("84") and len(d) in (11, 12):
        d = "0" + d[2:]
    return d


def normalize(d):
    d = d if isinstance(d, dict) else {}
    cu = d.get("customer") or {}
    out = {"customer": {"name": str(cu.get("name") or "").strip(), "phone": _phone(cu.get("phone")), "address": str(cu.get("address") or "").strip()},
           "order_type": d.get("order_type") if d.get("order_type") in ("loose", "wood") else "unknown",
           "wood_kind": d.get("wood_kind") if d.get("wood_kind") in ("roi", "congtrinh") else "unknown",
           "items": [], "advance": to_money(d.get("advance")), "advance_pct": _num(d.get("advance_pct")),
           "notes": str(d.get("notes") or "").strip()}
    for it in d.get("items") or []:
        if not isinstance(it, dict) or not str(it.get("name") or "").strip():
            continue
        out["items"].append({"name": re.sub(r"\s+", " ", str(it["name"])).strip(), "qty": _num(it.get("qty")) or 1.0,
                             "unit": (str(it.get("unit") or "").strip() or None),
                             "dai": _num(it.get("dai")), "cao": _num(it.get("cao")), "sau": _num(it.get("sau")),
                             "price": to_money(it.get("price")), "amount": to_money(it.get("amount")), "note": str(it.get("note") or "").strip()})
    return out


# ----------------------------------------------------------------------------- đọc file
def _read_text_file(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-16", "cp1258", "cp1252"):
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, UnicodeError):
            continue
    return raw.decode("utf-8", errors="replace")


def read_any(path):
    """-> (text, images). images là danh sách đường dẫn ảnh hoặc bytes PNG (trang PDF scan)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in IMG_EXT:
        return "", [path]
    if ext == ".pdf":
        import fitz
        doc = fitz.open(path)
        text = "\n".join(p.get_text() for p in doc)
        if len(text.strip()) >= 40:
            return text, []
        return "", [p.get_pixmap(dpi=150).tobytes("png") for p in list(doc)[:6]]
    if ext == ".docx":
        import docx
        d = docx.Document(path)
        parts = [p.text for p in d.paragraphs if p.text.strip()]
        for t in d.tables:
            for r in t.rows:
                cells = []
                for c in r.cells:
                    if c.text.strip() and (not cells or c.text.strip() != cells[-1]):
                        cells.append(c.text.strip())
                parts.append(" | ".join(cells))
        return "\n".join(parts), []
    if ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        rows = []
        for ws in wb.worksheets:
            for r in ws.iter_rows(values_only=True):
                cells = [str(c).strip() for c in r if c is not None and str(c).strip() != ""]
                if cells:
                    rows.append(" | ".join(cells))
        return "\n".join(rows), []
    if ext in TEXT_EXT:
        return _read_text_file(path), []
    raise ValueError(f"Chưa hỗ trợ định dạng {ext or 'này'}. Dùng ảnh (jpg/png/webp), pdf, docx, xlsx, txt hoặc dán văn bản.")


def gather(paths, text=""):
    """Gộp văn bản dán tay + nội dung các file đính kèm."""
    texts, images = ([text.strip()] if text and text.strip() else []), []
    for p in paths or []:
        t, im = read_any(p)
        if t.strip():
            texts.append(t.strip())
        images += im
    return "\n\n".join(texts), images


# ----------------------------------------------------------------------------- AI (Claude API)
def prep_image(x, max_side=1800):
    from PIL import Image, ImageOps
    if isinstance(x, (bytes, bytearray)):
        im = Image.open(io.BytesIO(x))
    else:
        if os.path.splitext(x)[1].lower() in (".heic", ".heif"):
            try:
                import pillow_heif
                pillow_heif.register_heif_opener()
            except Exception:
                raise ValueError("Ảnh HEIC (iPhone) chưa đọc được – hãy đổi sang JPG rồi chọn lại.")
        im = Image.open(x)
    im = ImageOps.exif_transpose(im)
    if im.mode != "RGB":
        bg = Image.new("RGB", im.size, "white")
        bg.paste(im.convert("RGBA"), mask=im.convert("RGBA").split()[-1])
        im = bg
    if max(im.size) > max_side:
        k = max_side / max(im.size)
        im = im.resize((int(im.width * k), int(im.height * k)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=88)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def build_request(model, text, images, hint=""):
    blocks = []
    for im in images[:8]:
        blocks.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": prep_image(im)}})
    intro = "Hãy đọc đơn hàng dưới đây và trả về JSON theo đúng cấu trúc đã quy định."
    if hint:
        intro += f"\nGợi ý từ người dùng: {hint}"
    if text.strip():
        intro += "\n\n--- NỘI DUNG VĂN BẢN ---\n" + text.strip()[:20000]
    blocks.append({"type": "text", "text": intro})
    return {"model": model, "max_tokens": 4096, "system": SYSTEM_PROMPT, "messages": [{"role": "user", "content": blocks}]}


def _extract_json(txt):
    txt = re.sub(r"^```(?:json)?|```$", "", txt.strip(), flags=re.M).strip()
    a, b = txt.find("{"), txt.rfind("}")
    if a < 0 or b <= a:
        raise ValueError("AI không trả về dữ liệu đọc được.")
    return json.loads(txt[a:b + 1])


def extract_ai(api_key, text, images, model=DEFAULT_MODEL, hint="", timeout=120):
    body = json.dumps(build_request(model or DEFAULT_MODEL, text, images, hint)).encode("utf-8")
    req = urllib.request.Request(API_URL, data=body, method="POST", headers={
        "x-api-key": api_key.strip(), "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        hints = {401: "API key không đúng hoặc đã bị thu hồi.", 403: "API key không có quyền dùng chức năng này.",
                 429: "Đang bị giới hạn lượt gọi – thử lại sau ít phút.", 402: "Tài khoản API hết số dư.",
                 400: "Yêu cầu bị từ chối (ảnh quá lớn/hỏng, hoặc tài khoản chưa nạp tiền)."}
        raise RuntimeError(f"{hints.get(e.code, 'Lỗi máy chủ AI')} (mã {e.code}) {msg}".strip())
    except urllib.error.URLError as e:
        raise RuntimeError(f"Không kết nối được tới máy chủ AI – kiểm tra mạng. ({e.reason})")
    out = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text")
    return normalize(_extract_json(out))


# ----------------------------------------------------------------------------- đọc bằng quy tắc (không cần mạng)
_SKIP = re.compile(r"^\s*(stt|tt\b|tên sản phẩm|sản phẩm\s*$|hạng mục\s*$|tổng|cộng|thành tiền|total|thanh toán|còn lại|còn thiếu|phí|ship|vận chuyển|"
                   r"ghi chú|lưu ý|bảo hành|chuyển khoản|stk|số tk|ngân hàng|ngày|hẹn|giao hàng|xin chào|cảm ơn|dạ|chào)", re.I)
_LBL_NAME = re.compile(r"^\s*(?:tên(?:\s*khách(?:\s*hàng)?)?|khách(?:\s*hàng)?|kh|người\s*nhận|họ\s*tên)\s*[:\-–=|]\s*(.+)$", re.I)
_LBL_ADDR = re.compile(r"^\s*(?:địa\s*chỉ(?:\s*giao(?:\s*hàng)?)?|đ/c|đc|dc|giao\s*(?:hàng\s*)?(?:tại|đến))\s*[:\-–=|]?\s*(.+)$", re.I)
_LBL_PHONE = re.compile(r"(?:sđt|sdt|đt|điện\s*thoại|phone|zalo|tel)\s*[:\-–=]?\s*", re.I)
_LBL_ADV = re.compile(r"(?:tạm\s*ứng|đặt\s*cọc|cọc|ứng(?:\s*trước)?)\s*[:\-–=]?\s*(.*)$", re.I)
_PHONE = re.compile(r"(?<!\d)(?:\+?84|0)[\s.\-]?\d{2,3}[\s.\-]?\d{3}[\s.\-]?\d{3,4}(?!\d)")
_DIM = re.compile(r"(?<![\d.,])(\d{3,4})\s*(?:mm)?\s*[xX×*]\s*(\d{2,4})\s*(?:mm)?(?:\s*[xX×*]\s*(\d{2,4})\s*(?:mm)?)?(?![\d])")
_DIM_M = re.compile(r"(?<![\d.,])(\d)\s*m\s*(\d)?\s*[xX×*]\s*(\d)\s*m\s*(\d)?(?![\d])", re.I)
_KEYWORDS = ("tủ", "tu ", "bàn", "ban ", "ghế", "ghe ", "giường", "giuong", "kệ", "ke ", "tab", "đôn", "don ", "sofa", "nệm", "bếp", "vách", "ốp",
             "tivi", "gương", "hộc", "cánh", "kệ", "bàn thờ", "trang điểm", "lavabo", "tủ giày", "ván")
_UNITS = r"(?:cái|cai|bộ|bo|chiếc|chiec|cây|cay|tấm|tam|m2|md|c)"


def _clean_name(s):
    s = re.sub(r"\(\s*\)", " ", s)
    s = re.sub(r"\s*\|\s*", " ", s)
    s = re.sub(r"[\s\-–:=,;]+$", "", s)
    s = re.sub(r"^[\s\-–:=,;.]+", "", s)
    return re.sub(r"\s+", " ", s).strip()


def parse_item_line(line):
    s = re.sub(r"^\s*(?:\d{1,3}\s*[.)]\s+|[-•*+●▪►]\s*)", "", line).strip()
    if not s or _SKIP.match(s):
        return None
    cells = [c.strip() for c in re.split(r"\t|\s\|\s", s) if c.strip()]
    qty, unit, dims = None, None, None
    cut = []                                                    # các vùng chữ sẽ bỏ khỏi tên (giá, số lượng, đơn vị...)
    masked = s
    mm = _DIM_M.search(s)
    if mm:                                                      # 1m6 x 2m -> 1600 x 2000
        dims = [int(mm[1]) * 1000 + int(mm[2] or 0) * 100, int(mm[3]) * 1000 + int(mm[4] or 0) * 100, None]
        masked = masked[:mm.start()] + " " * (mm.end() - mm.start()) + masked[mm.end():]
    for m in _DIM.finditer(s):                                  # che kích thước để không bị nhầm thành tiền / số lượng
        masked = masked[:m.start()] + " " * (m.end() - m.start()) + masked[m.end():]
        if dims is None:
            dims = [float(m[1]), float(m[2]), float(m[3]) if m[3] else None]
    moneys = find_moneys(masked)
    if len(cells) >= 3:                                         # dạng bảng: tên | SL | giá ...
        name = cells[0]
        for c in cells[1:]:
            if re.fullmatch(r"\d{1,3}(?:[.,]0+)?", c) and qty is None:
                qty = float(c.replace(",", "."))
    else:
        name = s
        m = re.search(r"(?:^|\s)[xX×]\s*(\d{1,3})(?![\dA-Za-zÀ-ỹ])(?!\s*[xX×*]\s*\d)", masked) \
            or re.search(r"\b(?:sl|số lượng)\s*[:=]?\s*(\d{1,3})\b", masked, re.I) \
            or re.search(r"(?<![\d.,])(\d{1,3})\s*" + _UNITS + r"\b", masked, re.I) \
            or re.match(r"\s*(\d{1,3})\s+(?=[A-Za-zÀ-ỹ])", masked)
        if m:
            qty = float(m[1])
            cut.append((m.start(), m.end()))
        for a, b, _ in moneys:
            ext = re.match(r"\s*(?:đ|₫|vnd|vnđ)\b\.?", s[b:], re.I)
            cut.append((a, b + (ext.end() if ext else 0)))
            u = re.match(r"\s*/\s*(md|m2|m|cái|bộ|bo|cai)\b", s[b:], re.I)
            if u:
                unit = {"m": "md", "bo": "bộ", "cai": "cái"}.get(u[1].lower(), u[1].lower())
                cut.append((b, b + u.end()))
        for a, b in sorted(cut, reverse=True):
            name = name[:a] + " " + name[b:]
        name = re.sub(r"\b(?:giá|đơn giá|thành tiền|tt)\s*[:=]?\s*$", "", name, flags=re.I)
    name = _clean_name(name)
    low = name.lower()
    if len(re.findall(r"[A-Za-zÀ-ỹ]{2,}", name)) < 1:
        return None
    if not (moneys or qty or dims or any(k in low for k in _KEYWORDS)):
        return None
    price = amount = None
    if moneys:
        price = moneys[0][2]
        if len(moneys) >= 2:
            amount = moneys[1][2]
    return {"name": name, "qty": qty or 1.0, "unit": unit, "dai": dims[0] if dims else None, "cao": dims[1] if dims else None,
            "sau": dims[2] if dims else None, "price": price, "amount": amount, "note": ""}


def extract_rules(text):
    cust = {"name": "", "phone": "", "address": ""}
    advance, adv_pct, items, notes = None, None, [], []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        pm = _PHONE.search(line)
        m = _LBL_ADV.match(line) if re.match(r"\s*(?:tạm\s*ứng|đặt\s*cọc|cọc|ứng)", line, re.I) else None
        if m:
            pc = re.search(r"(\d+(?:[.,]\d+)?)\s*%", m[1] or "")
            if pc:
                adv_pct = float(pc[1].replace(",", "."))
            else:
                ms = find_moneys(m[1] or "")
                advance = ms[0][2] if ms else to_money(m[1])
            continue
        m = _LBL_NAME.match(line)
        if m and not cust["name"]:
            v = _PHONE.sub(" ", m[1])
            v = _LBL_PHONE.sub(" ", v)
            a = _LBL_ADDR.search(v) or re.search(r"\b(?:địa chỉ|đ/c)\s*[:\-–]?\s*", v, re.I)
            if a:
                cust["address"] = cust["address"] or _clean_name(v[a.end():] if a.re is not _LBL_ADDR else a[1])
                v = v[:a.start()]
            cust["name"] = _clean_name(v)
            if pm and not cust["phone"]:
                cust["phone"] = _phone(pm[0])
            continue
        m = _LBL_ADDR.match(line)
        if m and not cust["address"]:
            cust["address"] = _clean_name(_PHONE.sub(" ", m[1]))
            if pm and not cust["phone"]:
                cust["phone"] = _phone(pm[0])
            continue
        if pm and (_LBL_PHONE.search(line) or len(re.sub(r"\D", "", line)) <= 12):
            if not cust["phone"]:
                cust["phone"] = _phone(pm[0])
            rest = _clean_name(_LBL_PHONE.sub(" ", _PHONE.sub(" ", line)))
            if rest and not cust["name"] and re.match(r"^(anh|chị|chi|cô|chú|bác|ông|bà)\b", rest, re.I):
                cust["name"] = rest
            continue
        if re.match(r"^(anh|chị|cô|chú|bác|ông|bà)\s+\S+", line, re.I) and not cust["name"] and not find_moneys(line) and len(line) < 40:
            cust["name"] = _clean_name(line)
            continue
        it = parse_item_line(line)
        if it:
            items.append(it)
        elif len(line) > 3:
            notes.append(line)
    return normalize({"customer": cust, "items": items, "advance": advance, "advance_pct": adv_pct, "notes": "; ".join(notes[:5])})


# ----------------------------------------------------------------------------- đối chiếu bảng giá
_STOP = {"cai", "bo", "chiec", "cay", "tam", "cua", "va", "co", "kich", "thuoc", "mm", "cm", "md", "m2", "x", "loai", "mau", "cho"}


def _toks(s):
    words, nums = set(), set()
    s = _meters(str(s))
    s = re.sub(r"(?<=\d)\s*(?:mm|cm)(?![A-Za-z])", " ", s, flags=re.I)         # 800mm -> 800
    s = re.sub(r"(?<=\d)\s*[xX×*]\s*(?=\d)", " ", s)                            # 800x1800 -> 800 1800
    for t in norm_text(s).split():
        if t in _STOP:
            continue
        if t.isdigit() and len(t) >= 3:
            nums.add(t)                       # kích thước (800, 1800...)
        else:
            words.add(t)                      # chữ và số nhỏ như "2" (2 hộc kéo, 2 cánh) vẫn là đặc điểm phân biệt sản phẩm
    return words, nums


def score(a, b):
    wa, na = _toks(a)
    wb, nb = _toks(b)
    if not wa and not na:
        return 0.0
    dice = 2 * len(wa & wb) / (len(wa) + len(wb)) if (wa or wb) else 0.0
    ratio = difflib.SequenceMatcher(None, " ".join(sorted(wa)), " ".join(sorted(wb))).ratio()
    contain = len(wa & wb) / len(wa) if wa else 0.0
    base = 0.4 * dice + 0.2 * ratio + 0.4 * contain
    if na and nb:                                            # chỉ so kích thước khi tên trong bảng giá có ghi kích thước
        def close(n):
            if n in nb:
                return 1.0
            v = int(n)
            return 0.85 if any(abs(int(m) - v) <= 0.06 * v for m in nb) else 0.0
        nm = sum(close(n) for n in na) / len(na)
        total = 0.55 * base + 0.45 * nm
        if nm == 0:
            total *= 0.55
    else:
        total = base
    return total


OK_SCORE, NEAR_SCORE = 0.70, 0.48


def _item_text(it):
    t = it["name"]
    if it.get("dai") and it.get("cao") and not re.search(r"\d{3,4}\s*[xX×*]", t):
        t += f" {int(it['dai'])} x {int(it['cao'])}"
    return t


def best_match(it, candidates, text_of):
    q = _item_text(it)
    best, bs = None, 0.0
    for c in candidates:
        s = score(q, text_of(c))
        if s > bs:
            best, bs = c, s
    status = "ok" if bs >= OK_SCORE else "near" if bs >= NEAR_SCORE else "none"
    if status == "ok" and not _toks(q)[0] <= _toks(text_of(best))[0]:        # khách ghi từ mà sản phẩm không có -> chỉ là "gần giống"
        status = "near"
    return (best if status != "none" else None), round(bs, 2), status


def match_product(it, products):
    return best_match(it, [p for p in products if not p.get("addon")],
                      lambda p: f"{p.get('name', '')} {p.get('category', '')} {p.get('w', '')} {p.get('h', '')} {p.get('d', '')}")


def match_wood(it, wood_items):
    return best_match(it, wood_items, lambda w: w.get("name", ""))


def detect_canh(text):
    """Nhận cánh / loại ván từ chữ khách ghi -> (tên cánh, van_idx). Mặc định Melamin + Chống ẩm."""
    t = norm_text(text)
    canh = "Melamin"
    for key, name in (("tan co dien", "Tân cổ điển"), ("acrylic", "Acrylic"), ("acr", "Acrylic"), ("laminate", "Laminate"), ("lam ", "Laminate"),
                      ("son ", "Sơn"), ("melamin", "Melamin"), ("mel ", "Melamin")):
        if key in (t + " "):
            canh = name
            break
    return canh, 1 if "an cuong" in t else 0


def guess_type(items, products, wood_items):
    """Tự đoán: nội thất bán sẵn hay hàng gỗ. Mỗi dòng bỏ 1 phiếu cho bên khớp hơn (bên bán sẵn được ưu tiên nhẹ vì tên có ghi kích thước).
    Trả về ('loose'|'wood', số phiếu loose, số phiếu wood)."""
    vl = vw = 0
    for it in items:
        (_, sl, _), (_, sw, _) = match_product(it, products), match_wood(it, wood_items)
        if max(sl, sw) < NEAR_SCORE:
            continue
        if sl >= sw - 0.05:
            vl += 1
        else:
            vw += 1
    if vl == vw == 0:
        dims = sum(1 for it in items if it.get("dai") and it.get("cao"))
        return ("wood" if dims >= max(1, len(items) // 2) else "loose"), 0, 0
    return ("loose" if vl >= vw else "wood"), vl, vw
