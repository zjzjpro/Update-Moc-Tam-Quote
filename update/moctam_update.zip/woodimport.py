# -*- coding: utf-8 -*-
"""Đọc 'Bảng báo giá cơ sở phần gỗ' (PDF) -> danh mục hàng gỗ (đơn giá theo loại cánh x loại ván).
Chạy trên danh sách từ + toạ độ nên dùng được với PyMuPDF (runtime) lẫn pdftotext (kiểm thử)."""
import re, uuid

PRICE_KEYS = ["mel_ca", "mel_ac", "acr_ca", "acr_ac", "lam_ca", "lam_ac", "son_ca", "son_ac", "tcd_ca", "tcd_lq"]
PRICE_LABELS = {
    "mel_ca": "Cánh Melamin – Chống ẩm", "mel_ac": "Cánh Melamin – Chống ẩm An Cường",
    "acr_ca": "Cánh Acrylic – Chống ẩm", "acr_ac": "Cánh Acrylic – Chống ẩm An Cường",
    "lam_ca": "Cánh Laminate – Chống ẩm", "lam_ac": "Cánh Laminate – Chống ẩm An Cường",
    "son_ca": "Cánh sơn – Chống ẩm", "son_ac": "Cánh sơn – Chống ẩm An Cường",
    "tcd_ca": "Cánh tân cổ điển – Chống ẩm", "tcd_lq": "Cánh tân cổ điển – LacQue An Cường",
}
DEFAULT_X = [194, 237, 282, 325, 368, 413, 460, 508, 556, 605]  # tâm cột giá (khi không tự dò được)
NUM = re.compile(r"^\d{1,3}(,\d{3})+$")
UNITS = {"md", "m2", "bộ", "cái", "cạnh", "mđ", "m", "cai", "bo"}


def _lines(ws, tol=2.6):
    out = []
    for w in sorted(ws, key=lambda w: (w[1], w[0])):
        for L in out:
            if abs(L["y"] - w[1]) <= tol:
                L["w"].append(w)
                break
        else:
            out.append({"y": w[1], "w": [w]})
    for L in out:
        L["w"].sort(key=lambda w: w[0])
    return sorted(out, key=lambda L: L["y"])


def parse_pages(pages, images=None):
    """pages: list[list[(x0,y0,x1,y1,text)]]; images: list (theo trang) các (top, bottom, bytes PNG) -> (items, footer)"""
    allw = [w for p in pages for w in p]
    # tâm các cột giá: lấy từ dòng đầy đủ 10 giá
    centers = None
    for p in pages:
        for L in _lines(p):
            nums = [w for w in L["w"] if NUM.match(w[4]) and 170 < (w[0] + w[2]) / 2 < 640]
            if len(nums) == 10:
                centers = [(w[0] + w[2]) / 2 for w in nums]
                break
        if centers:
            break
    centers = centers or DEFAULT_X
    price_min = centers[0] - 25
    note_x = centers[-1] + 30          # ghi chú bắt đầu sau cột giá cuối
    name_x0, unit_x0, stt_x1 = 80, centers[0] - 40, 80
    items, footer = [], []
    for p in pages:
        top = 0
        for w in p:
            if w[4] == "Stt":
                top = w[3] + 8
        ls = [L for L in _lines(p) if top < L["y"] < 585]
        for i, L in enumerate(ls):                       # ghi chú cuối bảng: dòng bắt đầu bằng '+'
            if L["w"][0][4] == "+" and L["w"][0][0] < 140:
                footer += [" ".join(w[4] for w in X["w"]) for X in ls[i:]]
                ls = ls[:i]
                break
        anchors = []
        for L in ls:
            has_stt = any(w[0] < stt_x1 and re.fullmatch(r"\d{1,3}", w[4]) for w in L["w"])
            has_unit = any(unit_x0 <= w[0] < price_min and w[4].lower() in UNITS for w in L["w"])
            if has_stt or has_unit:
                if anchors and abs(anchors[-1]["y"] - L["y"]) < 4:
                    anchors[-1]["has_stt"] |= has_stt
                    continue
                anchors.append({"y": L["y"], "has_stt": has_stt})
        if not anchors:
            continue
        bounds = [-1e9] + [(anchors[i]["y"] + anchors[i + 1]["y"]) / 2 for i in range(len(anchors) - 1)] + [1e9]
        rows = [{"stt": None, "name": [], "unit": "", "prices": {}, "note": [], "img": None} for _ in anchors]
        pi = pages.index(p)
        for (it, ib, payload) in (images[pi] if images and pi < len(images) else []):
            best = None
            for i in range(len(anchors)):
                ov = max(0, min(bounds[i + 1], ib) - max(bounds[i], it))
                if ov / max(1, min(bounds[i + 1] - bounds[i], ib - it)) >= 0.4 and (best is None or ov > best[0]):
                    best = (ov, i)
            if best and rows[best[1]]["img"] is None:
                rows[best[1]]["img"] = payload
        for L in ls:
            for i in range(len(anchors)):
                if bounds[i] <= L["y"] < bounds[i + 1]:
                    r = rows[i]
                    for w in L["w"]:
                        x, t = w[0], w[4]
                        if x < stt_x1 and re.fullmatch(r"\d{1,3}", t):
                            if r["stt"] is None:
                                r["stt"] = int(t)
                        elif name_x0 <= x < unit_x0:
                            r["name"].append((L["y"], x, t))
                        elif unit_x0 <= x < price_min:
                            r["unit"] = (r["unit"] + " " + t).strip()
                        elif price_min <= x < note_x:
                            if NUM.match(t):
                                c = (w[0] + w[2]) / 2
                                k = min(range(10), key=lambda j: abs(centers[j] - c))
                                r["prices"].setdefault(PRICE_KEYS[k], int(t.replace(",", "")))
                            else:
                                r["note"].append((L["y"], x, t))     # chữ nằm giữa vùng giá (vd 'Pvc có chỉ định…')
                        elif x >= note_x:
                            r["note"].append((L["y"], x, t))
                    break
        for r in rows:
            name = " ".join(t for _, _, t in sorted(r["name"], key=lambda a: (round(a[0] / 3), a[1])))
            lines = {}
            for y, x, t in sorted(r["note"], key=lambda a: (round(a[0] / 3), a[1])):
                lines.setdefault(round(y / 3), []).append(t)
            note = "\n".join(" ".join(v) for _, v in sorted(lines.items()))
            if not name and not r["prices"]:
                continue
            items.append({"id": uuid.uuid4().hex[:12], "stt": r["stt"], "name": name.strip(), "unit": r["unit"],
                          "prices": r["prices"], "_img": r["img"], "note": note})
    return items, footer


def read_wood_pdf(path):
    import fitz
    doc = fitz.open(path)
    pages, imgs = [], []
    for page in doc:
        pages.append([(w[0], w[1], w[2], w[3], w[4]) for w in page.get_text("words")])
        lst = []
        for inf in page.get_image_info():
            r = fitz.Rect(inf["bbox"])
            if 15 < r.width < 400 and 15 < r.height < 400 and r.y0 > 140:       # bỏ logo đầu trang
                try:
                    lst.append((r.y0, r.y1, page.get_pixmap(clip=r, dpi=150).tobytes("png")))
                except Exception:
                    pass
        imgs.append(lst)
    items, footer = parse_pages(pages, imgs)
    if not items:
        raise ValueError("Không nhận dạng được bảng giá gỗ.")
    return items, footer
