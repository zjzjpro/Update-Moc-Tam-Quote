# -*- coding: utf-8 -*-
"""Xuất ảnh chi tiết đơn hàng (PNG) và quản lý thư mục lưu: <gốc>/DON HANG/THÁNG x/ddmmyyyyHHMMSS.png (GMT+7)."""
import datetime, os, re, unicodedata
from PIL import Image, ImageDraw, ImageFont

import store

GMT7 = datetime.timezone(datetime.timedelta(hours=7))
BRAND, DARK, GREY, LIGHT, LINE = (184, 101, 27), (40, 40, 40), (110, 110, 110), (251, 233, 213), (215, 200, 185)


def now_gmt7():
    return datetime.datetime.now(GMT7)


def documents_dir():
    """Thư mục Documents THẬT của người dùng (đúng cả khi bị OneDrive chuyển hướng)."""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0 and buf.value:  # 5 = CSIDL_PERSONAL
                return buf.value
        except Exception:
            pass
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    return docs if os.path.isdir(docs) else os.path.expanduser("~")


def clean_name(name):
    """Tên thư mục/tệp an toàn cho Windows: chuẩn hoá NFC, bỏ ký tự cấm, không kết thúc bằng dấu cách hoặc dấu chấm."""
    name = unicodedata.normalize("NFC", str(name))
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", name).strip(" .")
    return name or "DON HANG"


def base_dir(settings):
    d = (settings.get("orders_dir") or "").strip()
    return os.path.normpath(d) if d else documents_dir()


def orders_root(settings):
    return os.path.join(base_dir(settings), "DON HANG")


def _writable(folder):
    """Tạo thư mục (nếu cần) và thử ghi/xoá 1 tệp nhỏ để chắc chắn dùng được."""
    probe = None
    try:
        os.makedirs(folder, exist_ok=True)
        probe = os.path.join(folder, f".mt_probe_{os.getpid()}")
        with open(probe, "wb") as f:
            f.write(b"0")
        return True
    except OSError:
        return False
    finally:
        if probe:
            try:
                os.remove(probe)
            except OSError:
                pass


last_note = ""   # ghi chú khi phải dùng thư mục dự phòng


def month_folder(settings, when):
    """Thư mục <gốc>\\DON HANG\\THÁNG x ghi được. Nếu thư mục hỏng/không mở được (khoá, quyền, OneDrive…)
    thì tự dùng 'DON HANG (2)', 'DON HANG (3)'… rồi tới các vị trí dự phòng – không bắt người dùng đổi tên tay."""
    global last_note
    last_note = ""
    sub = clean_name(f"THÁNG {when.month}")
    primary = os.path.join(orders_root(settings), sub)
    if _writable(primary):
        return primary
    base = base_dir(settings)
    for n in range(2, 8):
        alt = os.path.join(base, f"DON HANG ({n})", sub)
        if _writable(alt):
            last_note = f"Không ghi được vào “{orders_root(settings)}” nên đã lưu vào “{os.path.dirname(alt)}”."
            return alt
    for fb in (os.path.join(os.path.expanduser("~"), "MocTamQuote_DonHang"),
               os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "MocTamQuote", "DON HANG")):
        alt = os.path.join(fb, sub)
        if _writable(alt):
            last_note = f"Thư mục đã chọn không ghi được nên đã lưu vào “{fb}”. Bạn có thể đổi nơi lưu ở tab Cài đặt."
            return alt
    raise OSError("Không tìm được thư mục nào ghi được. Hãy chọn thư mục lưu khác trong tab Cài đặt.")


def target_path(settings, when=None):
    when = when or now_gmt7()
    return os.path.join(month_folder(settings, when), when.strftime("%d%m%Y%H%M%S") + ".png")


_FONTS = {
    False: [r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\tahoma.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf"],
    True: [r"C:\Windows\Fonts\segoeuib.ttf", r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\tahomabd.ttf",
           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf"],
}


def font(size, bold=False):
    for p in _FONTS[bold]:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def money(v):
    return f"{float(v):,.0f}".replace(",", ".")


def wrap(draw, text, f, width):
    lines, cur = [], ""
    for word in str(text).split():
        t = (cur + " " + word).strip()
        if draw.textlength(t, font=f) <= width or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [""]


def render_order_image(order, settings, path, when=None):
    when = when or now_gmt7()
    r, cu, co = order["result"], order["customer"], settings["company"]
    W, M = 1240, 40
    fT, fB, fN, fS = font(34, True), font(20, True), font(19), font(16)
    tmp = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    ROW = 100
    # chiều cao động
    rows = []
    for l in r["lines"]:
        rows.append((wrap(tmp, l["name"], fB, 360), wrap(tmp, l["size"] or "-", fN, 190)))
    sum_rows = 3 + (r["tier_discount"] > 0) + (r["promo"] > 0) + (r["assembly"] > 0) + (r["moisture"] > 0)
    notes = list(r["ship"]["notes"])
    H = 130 + 70 + 170 + 50 + max(len(rows), 1) * ROW + 30 + sum_rows * 38 + 60 + len(notes) * 28 + 90
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    # Header
    d.rectangle([0, 0, W, 120], fill=BRAND)
    d.text((M, 22), co["name"], font=fT, fill="white")
    d.text((M, 70), f"{co['address']}   |   MST: {co['tax']}   |   {co['phone']}", font=fS, fill=(255, 235, 215))
    y = 140
    d.text((W / 2, y + 22), "CHI TIẾT ĐƠN HÀNG", font=font(30, True), fill=BRAND, anchor="mm")
    d.text((W - M, y + 22), when.strftime("%H:%M:%S  %d/%m/%Y") + "  (GMT+7)", font=fS, fill=GREY, anchor="rm")
    y += 60
    # Khách hàng
    d.rounded_rectangle([M, y, W - M, y + 150], 12, outline=LINE, width=2, fill=(253, 248, 242))
    d.text((M + 20, y + 14), "THÔNG TIN KHÁCH HÀNG", font=fB, fill=BRAND)
    d.text((M + 20, y + 48), f"Khách hàng:  {cu.get('name', '')}", font=fN, fill=DARK)
    d.text((W / 2 + 40, y + 48), f"SĐT:  {cu.get('phone', '')}", font=fN, fill=DARK)
    al = wrap(d, "Địa chỉ giao:  " + cu.get("address", ""), fN, W - 2 * M - 40)
    for i, t in enumerate(al[:2]):
        d.text((M + 20, y + 80 + i * 26), t, font=fN, fill=DARK)
    sh = r["ship"]
    d.text((M + 20, y + 118), f"Vùng ship: {sh['zone']}   |   Mức giá: {r['tier_label']}", font=fS, fill=GREY)
    y += 170
    # Bảng
    cols = {"stt": 40, "img": 85, "name": 185, "size": 560, "qty": 770, "price": 830, "amt": 1010}
    d.rectangle([M, y, W - M, y + 44], fill=BRAND)
    hd = font(18, True)
    d.text((cols["stt"] + 10, y + 22), "STT", font=hd, fill="white", anchor="lm")
    d.text((cols["img"] + 40, y + 22), "Ảnh", font=hd, fill="white", anchor="mm")
    d.text((cols["name"], y + 22), "Sản phẩm", font=hd, fill="white", anchor="lm")
    d.text((cols["size"], y + 22), "Kích thước", font=hd, fill="white", anchor="lm")
    d.text((cols["qty"] + 25, y + 22), "SL", font=hd, fill="white", anchor="mm")
    d.text((cols["price"] + 160, y + 22), "Đơn giá", font=hd, fill="white", anchor="rm")
    d.text((W - M - 10, y + 22), "Thành tiền", font=hd, fill="white", anchor="rm")
    y += 44
    for i, (l, (nl, sl)) in enumerate(zip(r["lines"], rows)):
        if i % 2:
            d.rectangle([M, y, W - M, y + ROW], fill=(250, 246, 241))
        d.text((cols["stt"] + 10, y + ROW / 2), str(i + 1), font=fN, fill=DARK, anchor="lm")
        fp = store.image_path(l.get("pid", ""))
        if os.path.exists(fp):
            try:
                t = Image.open(fp).convert("RGB")
                t.thumbnail((84, 84))
                img.paste(t, (cols["img"] + (84 - t.width) // 2, y + (ROW - t.height) // 2))
            except Exception:
                pass
        else:
            d.rectangle([cols["img"], y + 8, cols["img"] + 84, y + 92], outline=LINE)
        for k, t in enumerate(nl[:3]):
            d.text((cols["name"], y + 12 + k * 26), t, font=fB, fill=DARK)
        for k, t in enumerate(sl[:3]):
            d.text((cols["size"], y + 12 + k * 26), t, font=fN, fill=GREY)
        d.text((cols["qty"] + 25, y + ROW / 2), str(l["qty"]), font=fB, fill=DARK, anchor="mm")
        d.text((cols["price"] + 160, y + ROW / 2), money(l["unit_price"]), font=fN, fill=DARK, anchor="rm")
        d.text((W - M - 10, y + ROW / 2), money(l["amount"]), font=fB, fill=DARK, anchor="rm")
        d.line([M, y + ROW, W - M, y + ROW], fill=LINE)
        y += ROW
    y += 24
    # Tổng kết
    X0 = W - M - 520
    items = [("Tạm tính (giá niêm yết)", r["list_total"], 0)]
    if r["tier_discount"] > 0:
        items.append((f"Chiết khấu theo mức giá", -r["tier_discount"], 0))
    if r["promo"] > 0:
        items.append(("Khuyến mãi", -r["promo"], 0))
    items.append(("Tiền hàng", r["goods_total"], 1))
    if r["assembly"] > 0:
        items.append(("Phí lắp ráp", r["assembly"], 0))
    if r["moisture"] > 0:
        items.append(("Ván chống ẩm", r["moisture"], 0))
    items.append(("Phí vận chuyển", sh["fee"], 0))
    for label, v, b in items:
        d.text((X0, y), label, font=fB if b else fN, fill=DARK)
        d.text((W - M - 10, y), ("-" if v < 0 else "") + money(abs(v)) + " đ", font=fB if b else fN, fill=DARK, anchor="ra")
        y += 38
    d.rounded_rectangle([X0 - 10, y + 6, W - M, y + 62], 10, fill=BRAND)
    d.text((X0 + 6, y + 34), "TỔNG THANH TOÁN", font=font(22, True), fill="white", anchor="lm")
    d.text((W - M - 16, y + 34), money(r["grand"]) + " đ", font=font(26, True), fill="white", anchor="rm")
    y += 84
    for n in notes:
        d.text((M, y), "• " + n, font=fS, fill=GREY)
        y += 28
    d.text((W / 2, H - 36), "Cảm ơn quý khách đã tin tưởng Mộc Tâm Furniture!", font=font(18, True), fill=BRAND, anchor="mm")
    img = img.crop((0, 0, W, min(H, y + 70)))
    img.save(path, "PNG")
    return path
