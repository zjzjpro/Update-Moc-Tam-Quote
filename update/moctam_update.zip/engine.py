# -*- coding: utf-8 -*-
"""Tính giá, phân loại kích thước, chọn vùng ship, phí ship, xuất Excel."""
import re
from importer import strip_acc, fmt_pct


def dims_nums(p):
    out = []
    for k in ("w", "h", "d"):
        nums = [int(x) for x in re.findall(r"\d+", str(p.get(k) or "").replace(",", ""))]
        if nums:
            out.append(max(nums))
    return out


def size_text(p):
    parts = [str(p.get(k)).strip() for k in ("w", "h", "d") if str(p.get(k) or "").strip()]
    return (" x ".join(parts) + " mm") if parts else ""


def tier_price(p, tier):
    pct = tier["pct"]
    retail = float(p.get("retail") or 0)
    if not pct:
        return retail
    fp = (p.get("file_prices") or {}).get(fmt_pct(pct))
    return float(fp) if fp else round(retail * (1 - pct / 100.0))


def auto_tier_key(qty, settings):
    key = settings["tiers"][0]["key"]
    for r in sorted(settings["auto_tier"], key=lambda r: r["min_qty"]):
        if qty >= r["min_qty"]:
            key = r["tier"]
    return key


def ship_class(p, settings):
    classes = settings["ship_classes"]
    keys = {c["key"] for c in classes}
    ov = p.get("ship_class", "auto")
    if ov in keys:
        return ov
    name = strip_acc(p.get("name", ""))
    for kw, k in settings["class_keywords"]:
        if strip_acc(kw) in name and k in keys:
            return k
    dims = sorted(dims_nums(p), reverse=True)
    if not dims:
        return "medium"
    for c in classes:
        lim = c.get("max_dims")
        if lim is None or all(d <= l for d, l in zip(dims, sorted(lim, reverse=True))):
            return c["key"]
    return classes[-1]["key"]


def choose_zone(km, address, settings):
    a = strip_acc(address or "")
    for z in settings["zones"]:
        for kw in z.get("match", []):
            if re.search(r"\b" + re.escape(strip_acc(kw)) + r"\b", a):
                return z
    if km is None:
        return None
    for z in settings["zones"]:
        if z.get("max_km") is not None and not z.get("match") and km <= z["max_km"]:
            return z
    nofee = [z for z in settings["zones"] if z.get("fee") is None]
    return nofee[-1] if nofee else settings["zones"][-1]


def vn(v):
    return f"{v:,.0f}".replace(",", ".")


def calc_ship(zone, class_keys, goods_total, lalamove, settings, km=None):
    cls = {c["key"]: c for c in settings["ship_classes"]}
    pol = settings["ship_policy"]
    info = {"zone": zone["name"] if zone else "Chưa xác định", "base": 0, "class": "", "mult": 0,
            "raw": 0, "fee": 0, "notes": []}
    if zone is None:
        info["notes"].append("Chưa xác định vùng – nhập địa chỉ & bấm 'Tính khoảng cách' hoặc chọn vùng.")
        return info
    if zone.get("fee") is None:
        rate = float(settings.get("lalamove_per_km", 12000))
        if lalamove and float(lalamove) > 0:
            base = float(lalamove)
            info["notes"].append("Ngoại tỉnh: dùng phí Lalamove nhập tay.")
        elif km:
            base = float(km) * rate
            info["notes"].append(f"Ngoại tỉnh (Lalamove): {km:.1f} km × {vn(rate)}đ/km = {vn(base)}đ.")
        else:
            base = 0.0
            info["notes"].append("Ngoại tỉnh: cần tính khoảng cách (hoặc nhập km) để ra phí Lalamove = km × " + vn(rate) + "đ.")
        mult = 1.0
        info["class"] = "Lalamove (km × đơn giá)"
    else:
        base = float(zone["fee"])
        ms = [(cls[k]["mult"], cls[k]["name"]) for k in class_keys if k in cls]
        if not ms:
            mult = 0
        elif settings.get("ship_mode") == "sum":
            mult = sum(m for m, _ in ms)
            info["class"] = "Cộng theo từng sản phẩm"
        else:
            mult, nm = max(ms)
            info["class"] = nm
    raw = base * mult
    fee = raw
    if zone.get("free_eligible") and goods_total >= pol["free_from"]:
        fee = 0
        info["notes"].append(f"Miễn phí ship (đơn ≥ {vn(pol['free_from'])}đ, vùng < 30 km).")
    elif goods_total >= pol["half_from"]:
        fee = raw * (1 - pol["half_pct"] / 100.0)
        info["notes"].append(f"Giảm {pol['half_pct']}% phí ship (đơn ≥ {vn(pol['half_from'])}đ).")
    info.update(base=base, mult=mult, raw=round(raw), fee=round(fee))
    return info


def compute_order(items, settings, tier_key="auto", promo_pct=0.0, promo_amt=0.0,
                  assembly=False, moisture=False, zone=None, lalamove=0.0, km=None,
                  ship_override=None, asm_override=None, moist_override=None):
    """items: [{"p": product, "qty": n, "price_ov": đơn giá sửa tay (tuỳ chọn), "name_ov", "size_ov", "class_ov",
                "fee": True nếu là phụ phí/dòng phát sinh (không tính mức giá, KM, ship)}]"""
    goods_items = [i for i in items if not i.get("fee")]
    fee_items = [i for i in items if i.get("fee")]
    qty = sum(i["qty"] for i in goods_items)
    tk = auto_tier_key(qty, settings) if tier_key == "auto" else tier_key
    tier = next((t for t in settings["tiers"] if t["key"] == tk), settings["tiers"][0])
    lines, list_total, goods = [], 0.0, 0.0
    asm = moist = 0.0

    def make_line(it, is_fee):
        p, q = it["p"], it["qty"]
        lp = float(p.get("retail") or 0)
        up = tier_price(p, tier) if not is_fee else lp
        if it.get("price_ov") is not None:
            up = float(it["price_ov"])
            lp = up  # giá sửa tay: không hiện chiết khấu mức giá
        if is_fee:
            lp = up
        cls = "" if is_fee else ship_class(p, settings)
        if it.get("class_ov") is not None:
            cls = it["class_ov"]
        return {"pid": p["id"], "name": it.get("name_ov") or p["name"],
                "size": it["size_ov"] if it.get("size_ov") is not None else size_text(p),
                "unit": it.get("unit_ov") or p.get("unit", ""), "qty": q, "list_price": lp, "unit_price": up,
                "amount": up * q, "class": cls, "fee": bool(is_fee), "manual": bool(p.get("manual"))}

    for it in items:
        is_fee = bool(it.get("fee"))
        l = make_line(it, is_fee)
        lines.append(l)
        if is_fee:
            continue
        list_total += l["list_price"] * l["qty"]
        goods += l["amount"]
        p, q = it["p"], it["qty"]
        if assembly:
            asm += float(p.get("assembly") or 0) * q
        if moisture:
            moist += float(p.get("moisture") or 0) * q
    extra = sum(l["amount"] for l in lines if l["fee"])
    promo = min(goods, goods * promo_pct / 100.0 + promo_amt)
    goods_total = goods - promo
    if asm_override is not None:
        asm = float(asm_override)
    if moist_override is not None:
        moist = float(moist_override)
    ship_classes = [l["class"] for l in lines if not l["fee"]]
    if goods_items or fee_items:
        ship = calc_ship(zone, ship_classes, goods_total, lalamove, settings, km)
    else:
        ship = {"zone": zone["name"] if zone else "—", "base": 0, "class": "", "mult": 0, "raw": 0, "fee": 0, "notes": []}
    if ship_override is not None:
        ship = dict(ship)
        ship["auto_fee"] = ship.get("fee", 0)
        ship["fee"] = round(float(ship_override))
        ship["manual"] = True
        ship["notes"] = list(ship.get("notes", [])) + ["Phí vận chuyển nhập tay (thay cho phí tự tính)."]
    return {"lines": lines, "qty": qty, "tier_key": tier["key"], "tier_label": tier["label"],
            "list_total": list_total, "tier_discount": list_total - goods, "goods_before_promo": goods,
            "promo": promo, "goods_total": goods_total, "assembly": asm, "moisture": moist, "extra_fees": extra,
            "ship": ship, "grand": goods_total + extra + asm + moist + ship["fee"]}


def export_order_xlsx(order, path, settings):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    r, cu, co = order["result"], order["customer"], settings["company"]
    wb = Workbook()
    ws = wb.active
    ws.title = "Đơn hàng"
    thin = Side(style="thin", color="999999")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["A1"], ws["A1"].font = co["name"], Font(bold=True, size=14)
    ws["A2"] = f"Địa chỉ: {co['address']}"
    ws["A3"] = f"MST: {co['tax']}  |  Liên hệ: {co['phone']}"
    ws["A5"], ws["A5"].font = "BÁO GIÁ / ĐƠN HÀNG", Font(bold=True, size=13)
    ws["A6"] = f"Khách hàng: {cu.get('name','')}    SĐT: {cu.get('phone','')}"
    ws["A7"] = f"Địa chỉ giao: {cu.get('address','')}"
    ws["A8"] = f"Mức giá áp dụng: {r['tier_label']}   |   Vùng ship: {r['ship']['zone']}"
    hdr = ["STT", "Sản phẩm", "Kích thước", "ĐVT", "SL", "Đơn giá", "Thành tiền"]
    for c, h in enumerate(hdr, 1):
        x = ws.cell(row=10, column=c, value=h)
        x.font, x.border = Font(bold=True, color="FFFFFF"), box
        x.fill = PatternFill("solid", fgColor="B8651B")
        x.alignment = Alignment(horizontal="center")
    row = 11
    for i, l in enumerate(r["lines"], 1):
        vals = [i, l["name"], l["size"], l["unit"], l["qty"], l["unit_price"], l["amount"]]
        for c, v in enumerate(vals, 1):
            x = ws.cell(row=row, column=c, value=v)
            x.border = box
            if c >= 6:
                x.number_format = "#,##0"
        row += 1
    row += 1
    summary = [("Tạm tính (giá niêm yết)", r["list_total"]), ("Chiết khấu theo mức giá", -r["tier_discount"]),
               ("Khuyến mãi", -r["promo"]), ("Tiền hàng", r["goods_total"]), ("Phụ phí khác", r.get("extra_fees", 0)), ("Phí lắp ráp", r["assembly"]),
               ("Ván chống ẩm", r["moisture"]), ("Phí vận chuyển", r["ship"]["fee"]),
               ("TỔNG THANH TOÁN", r["grand"])]
    for label, v in summary:
        ws.cell(row=row, column=6, value=label).font = Font(bold=label.startswith("TỔNG"))
        x = ws.cell(row=row, column=7, value=v)
        x.number_format, x.font = "#,##0", Font(bold=label.startswith("TỔNG"))
        row += 1
    for n in r["ship"]["notes"]:
        ws.cell(row=row + 1, column=1, value="* " + n)
        row += 1
    for col, w in zip("ABCDEFG", (6, 48, 22, 8, 6, 16, 18)):
        ws.column_dimensions[col].width = w
    wb.save(path)
