# -*- coding: utf-8 -*-
"""Mộc Tâm – Báo giá & Lên đơn (giao diện Tkinter)."""
import datetime, os, queue, re, shutil, tempfile, threading, uuid
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from PIL import Image, ImageTk

import engine, geo, importer, orderimage, receipts, smartorder, store, updater, version, woodimport

BRAND, BG, LIGHT = "#A8742C", "#F7F4EE", "#F1E6CF"      # đồng vàng cổ điển / ngà / kem
DARK, GOLD, TEXT, MUTED = "#1E1A17", "#D4AF6A", "#2B2622", "#7A7166"
FONT = "Tahoma"
AUTHOR = "Hoàng Thiên"
AUTHOR_PHONE = "0977.184.093"


def money(v):
    return f"{float(v):,.0f}".replace(",", ".")


def parse_money(s):
    s = re.sub(r"[^\d]", "", str(s or ""))
    return float(s) if s else 0.0


def parse_float(s):
    try:
        return float(str(s).replace(",", ".").strip())
    except ValueError:
        return None


def run_bg(widget, fn, done):
    q = queue.Queue()

    def work():
        try:
            q.put((True, fn()))
        except Exception as e:  # noqa
            q.put((False, e))

    threading.Thread(target=work, daemon=True).start()

    def poll():
        try:
            ok, res = q.get_nowait()
        except queue.Empty:
            widget.after(150, poll)
            return
        done(ok, res)

    widget.after(150, poll)


def load_thumb(pid, size=(300, 300)):
    fp = store.image_path(pid)
    if not os.path.exists(fp):
        return None
    try:
        with Image.open(fp) as src:
            im = src.convert("RGB")
        im.thumbnail(size)
        return ImageTk.PhotoImage(im)
    except Exception:
        return None


def make_tree(parent, cols, widths, height=12, show="headings", hscroll=False):
    fr = ttk.Frame(parent)
    t = ttk.Treeview(fr, columns=[c[0] for c in cols], show=show, height=height, selectmode="browse")
    for (cid, title), w in zip(cols, widths):
        t.heading(cid, text=title)
        t.column(cid, width=w, minwidth=max(30, int(w * 0.5)), anchor="w" if w >= 150 else "center", stretch=(w >= 150))
    sb = ttk.Scrollbar(fr, orient="vertical", command=t.yview)
    t.configure(yscrollcommand=sb.set)
    fr.columnconfigure(0, weight=1)
    fr.rowconfigure(0, weight=1)
    t.grid(row=0, column=0, sticky="nsew")
    sb.grid(row=0, column=1, sticky="ns")
    if hscroll:
        hb = ttk.Scrollbar(fr, orient="horizontal", command=t.xview)
        t.configure(xscrollcommand=hb.set)
        hb.grid(row=1, column=0, sticky="ew")
    return fr, t


class Scroll(ttk.Frame):
    """Khung tự cuộn: cửa sổ thấp/hẹp hơn nội dung thì hiện thanh cuộn (không bị cắt);
    cửa sổ lớn hơn thì nội dung giãn ra lấp đầy (không thừa khoảng trống)."""

    def __init__(self, parent):
        super().__init__(parent)
        self.cv = tk.Canvas(self, highlightthickness=0, bd=0, bg=BG)
        self.vs = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
        self.hs = ttk.Scrollbar(self, orient="horizontal", command=self.cv.xview)
        self.cv.configure(yscrollcommand=self.vs.set, xscrollcommand=self.hs.set)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.cv.grid(row=0, column=0, sticky="nsew")
        self.body = ttk.Frame(self.cv)
        self.win = self.cv.create_window((0, 0), window=self.body, anchor="nw")
        self._busy, self._job, self._last, self._vis = False, None, None, (False, False)
        self.body.bind("<Configure>", lambda e: self.schedule())
        self.bind("<Configure>", lambda e: self.schedule())
        self.cv.bind("<Enter>", lambda e: self.cv.bind_all("<MouseWheel>", self.wheel))
        self.cv.bind("<Leave>", lambda e: self.cv.unbind_all("<MouseWheel>"))

    def schedule(self):
        """Gộp nhiều sự kiện thay đổi kích thước thành 1 lần tính (chống vòng lặp sự kiện)."""
        if self._job is None:
            self._job = self.after(30, self._run)

    def _run(self):
        self._job = None
        self.fit()

    def fit(self):
        if self._busy:
            return
        self._busy = True
        try:
            W, H = self.winfo_width(), self.winfo_height()      # kích thước khung ngoài – không phụ thuộc thanh cuộn
            if W < 60 or H < 60:
                return
            rw, rh = self.body.winfo_reqwidth(), self.body.winfo_reqheight()
            SB = 17
            need_v = rh > H
            need_h = rw > W - (SB if need_v else 0)
            if need_h and not need_v:
                need_v = rh > H - SB
            aw, ah = W - (SB if need_v else 0), H - (SB if need_h else 0)
            w, h = max(rw, aw), max(rh, ah)
            key = (need_v, need_h, w, h)
            if key == self._last:
                return
            self._last = key
            self.cv.itemconfigure(self.win, width=w, height=h)
            self.cv.configure(scrollregion=(0, 0, w, h))
            if need_v != self._vis[0]:
                (self.vs.grid(row=0, column=1, sticky="ns") if need_v else self.vs.grid_remove())
            if need_h != self._vis[1]:
                (self.hs.grid(row=1, column=0, sticky="ew") if need_h else self.hs.grid_remove())
            self._vis = (need_v, need_h)
        finally:
            self._busy = False

    def wheel(self, e):
        if e.widget.winfo_class() in ("Treeview", "Text", "TCombobox", "Listbox", "TSpinbox"):
            return
        if self.body.winfo_reqheight() > self.cv.winfo_height() + 1:
            self.cv.yview_scroll(int(-e.delta / 120), "units")


def place(win, app):
    """Đặt hộp thoại giữa cửa sổ chính và không vượt ngoài màn hình."""
    try:
        win.update_idletasks()
        w, h = win.winfo_reqwidth(), win.winfo_reqheight()
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w, h = min(w, sw - 40), min(h, sh - 80)
        x = max(0, min(app.winfo_rootx() + (app.winfo_width() - w) // 2, sw - w - 10))
        y = max(0, min(app.winfo_rooty() + (app.winfo_height() - h) // 3, sh - h - 50))
        win.geometry(f"{w}x{h}+{x}+{y}")
    except Exception:
        pass


# ======================================================================= Sản phẩm
class ProductDialog(tk.Toplevel):
    def __init__(self, app, product=None):
        super().__init__(app)
        self.app, self.result, self.img_src = app, None, None
        self.p = dict(product) if product else {"id": uuid.uuid4().hex[:12], "series": "", "category": "",
                                                 "name": "", "desc": "", "w": "", "h": "", "d": "", "unit": "BỘ",
                                                 "retail": 0, "file_prices": {}, "assembly": 0, "moisture": 0,
                                                 "ship_class": "auto"}
        self.title("Sản phẩm")
        self.transient(app)
        f = ttk.Frame(self, padding=12)
        f.pack(fill="both", expand=True)
        self.v = {}
        cats = sorted({p["category"] for p in app.products})
        sers = sorted({p["series"] for p in app.products if p["series"]})
        rows = [("Dòng sản phẩm", "series", sers), ("Danh mục", "category", cats), ("Tên sản phẩm", "name", None),
                ("Rộng (mm)", "w", None), ("Cao (mm)", "h", None), ("Sâu (mm)", "d", None), ("ĐVT", "unit", None),
                ("Giá bán lẻ (đ)", "retail", None), ("Phí lắp ráp (đ)", "assembly", None),
                ("Ván chống ẩm (đ)", "moisture", None),
                ("Phân loại ship", "ship_class", ["auto"] + [c["key"] for c in app.settings["ship_classes"]])]
        for r, (lab, key, vals) in enumerate(rows):
            ttk.Label(f, text=lab).grid(row=r, column=0, sticky="w", pady=3)
            val = self.p.get(key, "")
            if key in ("retail", "assembly", "moisture"):
                val = money(val)
            var = tk.StringVar(value=str(val))
            self.v[key] = var
            w = ttk.Combobox(f, textvariable=var, values=vals, width=62) if vals else ttk.Entry(f, textvariable=var, width=64)
            w.grid(row=r, column=1, sticky="ew", pady=3)
        n = len(rows)
        ttk.Label(f, text="Diễn giải").grid(row=n, column=0, sticky="nw")
        self.desc = tk.Text(f, width=64, height=7, wrap="word", font=(FONT, 11), padx=4, pady=2)
        self.desc.insert("1.0", self.p.get("desc", ""))
        self.desc.grid(row=n, column=1, pady=3)
        self.imglbl = ttk.Label(f, text="(chưa có ảnh)" if not os.path.exists(store.image_path(self.p["id"])) else "(đã có ảnh)")
        self.imglbl.grid(row=n + 1, column=1, sticky="w")
        ttk.Button(f, text="Chọn ảnh…", command=self.pick).grid(row=n + 1, column=0, sticky="w")
        bt = ttk.Frame(f)
        bt.grid(row=n + 2, column=0, columnspan=2, pady=(10, 0), sticky="e")
        ttk.Button(bt, text="Lưu", style="Accent.TButton", command=self.ok).pack(side="left", padx=4)
        ttk.Button(bt, text="Hủy", command=self.destroy).pack(side="left")
        place(self, app)
        self.grab_set()
        self.wait_window()

    def pick(self):
        fp = filedialog.askopenfilename(parent=self, filetypes=[("Ảnh", "*.png *.jpg *.jpeg *.webp *.bmp")])
        if fp:
            self.img_src = fp
            self.imglbl.config(text=os.path.basename(fp))

    def ok(self):
        g = lambda k: self.v[k].get().strip()
        if not g("name") or parse_money(g("retail")) <= 0:
            messagebox.showwarning("Thiếu thông tin", "Nhập tên sản phẩm và giá bán lẻ.", parent=self)
            return
        p = self.p
        retail = parse_money(g("retail"))
        if retail != float(p.get("retail") or 0):
            p["file_prices"] = {}
        p.update(series=g("series"), category=g("category") or "Khác", name=g("name"), w=g("w"), h=g("h"),
                 d=g("d"), unit=g("unit") or "BỘ", retail=retail, assembly=parse_money(g("assembly")),
                 moisture=parse_money(g("moisture")), ship_class=g("ship_class") or "auto",
                 desc=self.desc.get("1.0", "end").strip())
        if self.img_src:
            with open(self.img_src, "rb") as f:
                store.save_image_bytes(p["id"], f.read())
        self.result = p
        self.destroy()


class ImportPreview(tk.Toplevel):
    def __init__(self, app, prods):
        super().__init__(app)
        self.result = None
        self.title(f"Xem trước – {len(prods)} sản phẩm nhận dạng được")
        self.transient(app)
        cols = [("cat", "Danh mục"), ("name", "Sản phẩm"), ("size", "Kích thước"), ("retail", "Giá bán lẻ"),
                ("p15", "Giá CK trong file"), ("img", "Ảnh")]
        fr, t = make_tree(self, cols, (140, 330, 150, 100, 110, 60), height=18)
        fr.pack(fill="both", expand=True, padx=8, pady=8)
        for p in prods:
            fp = p.get("file_prices", {})
            t.insert("", "end", values=(p["category"], p["name"], engine.size_text(p), money(p["retail"]),
                                        money(fp.get("15", 0)) if fp.get("15") else "", "✔" if p.get("_img") else ""))
        self.mode = tk.StringVar(value="merge")
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=8, pady=6)
        ttk.Radiobutton(bar, text="Gộp: cập nhật sản phẩm trùng (giá, ảnh…) + thêm sản phẩm mới", variable=self.mode, value="merge").pack(anchor="w")
        ttk.Radiobutton(bar, text="Thay thế toàn bộ danh mục hiện tại", variable=self.mode, value="replace").pack(anchor="w")
        ttk.Button(bar, text="Nhập vào phần mềm", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(bar, text="Hủy", command=self.destroy).pack(side="right", padx=6)
        place(self, app)
        self.grab_set()
        self.wait_window()

    def ok(self):
        self.result = self.mode.get()
        self.destroy()


WOOD_CANH = [("Melamin", "mel_ca", "mel_ac", "Chống ẩm", "Chống ẩm An Cường"),
             ("Acrylic", "acr_ca", "acr_ac", "Chống ẩm", "Chống ẩm An Cường"),
             ("Laminate", "lam_ca", "lam_ac", "Chống ẩm", "Chống ẩm An Cường"),
             ("Sơn", "son_ca", "son_ac", "Chống ẩm", "Chống ẩm An Cường"),
             ("Tân cổ điển", "tcd_ca", "tcd_lq", "Chống ẩm", "Cánh LacQue An Cường")]
WOOD_KINDS = {"roi": "Hàng rời", "congtrinh": "Hàng công trình"}


def wood_price(item, canh, van_idx):
    spec = next((c for c in WOOD_CANH if c[0] == canh), WOOD_CANH[0])
    p = item.get("prices", {})
    for k in (spec[1 + van_idx], ("mel_ca", "mel_ac")[van_idx], "mel_ca"):
        if p.get(k):
            return p[k]
    return None


def wood_label(item, canh, van_idx):
    spec = next((c for c in WOOD_CANH if c[0] == canh), WOOD_CANH[0])
    if set(item.get("prices", {})) <= {"mel_ca", "mel_ac"}:
        return spec[3 + van_idx]
    return f"Cánh {spec[0]} – {spec[3 + van_idx]}"


def wood_unit(u):
    low = str(u or "").lower()
    if low.startswith("m2"):
        return "m2"
    if low.startswith(("md", "mđ")):
        return "md"
    return {"bộ": "bộ", "cái": "cái", "cạnh": "cái"}.get(low, "m2")


class WoodDialog(tk.Toplevel):
    def __init__(self, app, item=None):
        super().__init__(app)
        self.result = None
        self.it = dict(item) if item else {"id": uuid.uuid4().hex[:12], "stt": None, "name": "", "unit": "m2", "prices": {}, "note": ""}
        self.title("Hạng mục hàng gỗ")
        self.transient(app)
        f = ttk.Frame(self, padding=12)
        f.pack(fill="both", expand=True)
        self.v = {"name": tk.StringVar(value=self.it["name"]), "unit": tk.StringVar(value=self.it["unit"]),
                  "stt": tk.StringVar(value=str(self.it.get("stt") or ""))}
        for r, (lab, k, w) in enumerate((("STT", "stt", 8), ("Hạng mục", "name", 56), ("ĐVT", "unit", 14))):
            ttk.Label(f, text=lab).grid(row=r, column=0, sticky="w", pady=3)
            ttk.Entry(f, textvariable=self.v[k], width=w).grid(row=r, column=1, sticky="w", padx=8)
        self.pv = {}
        for i, k in enumerate(woodimport.PRICE_KEYS):
            ttk.Label(f, text=woodimport.PRICE_LABELS[k]).grid(row=3 + i, column=0, sticky="w", pady=2)
            self.pv[k] = tk.StringVar(value=money(self.it["prices"][k]) if self.it["prices"].get(k) else "")
            ttk.Entry(f, textvariable=self.pv[k], width=16).grid(row=3 + i, column=1, sticky="w", padx=8)
        ttk.Label(f, text="Ghi chú").grid(row=14, column=0, sticky="nw")
        self.note = tk.Text(f, width=56, height=4)
        self.note.insert("1.0", self.it.get("note", ""))
        self.note.grid(row=14, column=1, pady=3)
        bt = ttk.Frame(f)
        bt.grid(row=15, column=0, columnspan=2, sticky="e", pady=(8, 0))
        ttk.Button(bt, text="Lưu", style="Accent.TButton", command=self.ok).pack(side="left", padx=4)
        ttk.Button(bt, text="Hủy", command=self.destroy).pack(side="left")
        place(self, app)
        self.grab_set()
        self.wait_window()

    def ok(self):
        if not self.v["name"].get().strip():
            messagebox.showwarning("Thiếu thông tin", "Nhập tên hạng mục.", parent=self)
            return
        prices = {k: int(parse_money(v.get())) for k, v in self.pv.items() if parse_money(v.get()) > 0}
        if not prices:
            messagebox.showwarning("Thiếu thông tin", "Nhập ít nhất một đơn giá.", parent=self)
            return
        stt = self.v["stt"].get().strip()
        self.it.update(name=self.v["name"].get().strip(), unit=self.v["unit"].get().strip(), prices=prices,
                       stt=int(stt) if stt.isdigit() else None, note=self.note.get("1.0", "end").strip())
        self.result = self.it
        self.destroy()


class CatalogTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app, self.thumb, self.cur = app, None, []
        self.group = tk.StringVar(value="loose")
        self.q, self.series, self.tier = tk.StringVar(), tk.StringVar(value="Tất cả"), tk.StringVar()
        self.canh, self.van = tk.StringVar(value="Melamin"), tk.StringVar(value="Chống ẩm")
        top = ttk.Frame(self, padding=(10, 8, 10, 0))
        top.pack(fill="x")
        for val, lab in (("loose", "🪑 Nội thất bán sẵn"), ("roi", "🪵 Hàng gỗ – Hàng rời"), ("congtrinh", "🏗 Hàng gỗ – Hàng công trình")):
            ttk.Radiobutton(top, text=lab, value=val, variable=self.group, style="Toolbutton", command=self.on_group).pack(side="left", padx=(0, 4))
        ttk.Button(top, text="Mở rộng", command=lambda: self.toggle(True)).pack(side="right")
        ttk.Button(top, text="Thu gọn", command=lambda: self.toggle(False)).pack(side="right", padx=4)
        ttk.Button(top, text="✕", width=3, command=lambda: self.q.set("")).pack(side="right")
        ttk.Entry(top, textvariable=self.q, width=30).pack(side="right", padx=4)
        ttk.Label(top, text="🔍").pack(side="right")
        opts = ttk.Frame(self, padding=(10, 6, 10, 0))
        opts.pack(fill="x")
        ttk.Button(opts, text="🗑 Xóa", command=self.delete).pack(side="right")
        ttk.Button(opts, text="✎ Sửa", command=self.edit).pack(side="right", padx=4)
        ttk.Button(opts, text="➕ Thêm", command=self.add).pack(side="right")
        self.btn_import = ttk.Button(opts, text="📥 Nhập file", style="Accent.TButton", command=self.import_any)
        self.btn_import.pack(side="right", padx=(0, 8))
        self.btn_imgs = ttk.Button(opts, text="🖼 Gán ảnh từ báo giá…", command=self.assign_images)
        self.btn_imgs.pack(side="right", padx=(0, 4))
        self.opt_loose, self.opt_wood = ttk.Frame(opts), ttk.Frame(opts)
        ttk.Label(self.opt_loose, text="Dòng:").pack(side="left")
        self.cb_series = ttk.Combobox(self.opt_loose, textvariable=self.series, width=12, state="readonly")
        self.cb_series.pack(side="left", padx=(4, 14))
        ttk.Label(self.opt_loose, text="Xem giá:").pack(side="left")
        self.cb_tier = ttk.Combobox(self.opt_loose, textvariable=self.tier, width=28, state="readonly")
        self.cb_tier.pack(side="left", padx=4)
        ttk.Label(self.opt_wood, text="Loại cánh:").pack(side="left")
        ttk.Combobox(self.opt_wood, textvariable=self.canh, values=[c[0] for c in WOOD_CANH], width=14, state="readonly").pack(side="left", padx=(4, 14))
        ttk.Label(self.opt_wood, text="Loại ván:").pack(side="left")
        self.cb_van = ttk.Combobox(self.opt_wood, textvariable=self.van, width=24, state="readonly")
        self.cb_van.pack(side="left", padx=4)
        pw = ttk.PanedWindow(self, orient="horizontal")
        pw.pack(fill="both", expand=True, padx=10, pady=10)
        left = ttk.Frame(pw)
        self.tree = ttk.Treeview(left, show="tree headings", selectmode="browse", style="Compact.Treeview")
        sb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.tag_configure("cat", background=LIGHT, font=(FONT, 10, "bold"))
        pw.add(left, weight=3)
        right = ttk.Frame(pw, padding=(12, 0, 0, 0))
        pw.add(right, weight=1)
        self.img = ttk.Label(right, text="Chưa có ảnh", anchor="center", relief="groove")
        self.img.pack(fill="x", ipady=24)
        self.info = ttk.Label(right, text="", wraplength=260, justify="left", anchor="nw")
        self.info.pack(fill="both", expand=True, pady=8)
        right.bind("<Configure>", lambda e: self.info.config(wraplength=max(140, e.width - 30)))
        self.qty = tk.IntVar(value=1)
        row = ttk.Frame(right)
        row.pack(fill="x")
        self.spin = ttk.Spinbox(row, from_=1, to=999, textvariable=self.qty, width=5)
        self.spin.pack(side="left")
        self.btn_order = ttk.Button(row, text="➕ Thêm vào đơn hàng", style="Accent.TButton", command=self.to_order)
        self.btn_order.pack(side="left", padx=6)
        for v in (self.q, self.series, self.tier, self.canh, self.van):
            v.trace_add("write", lambda *a: self.refresh())
        self.canh.trace_add("write", lambda *a: self.update_van())
        self.tree.bind("<<TreeviewSelect>>", self.show)
        self.tree.bind("<Double-1>", lambda e: self.edit())
        self.on_group()
        self.reload_options()

    # ---- nhóm hàng
    def is_wood(self):
        return self.group.get() != "loose"

    def wdata(self):
        return self.app.wood[self.group.get()]

    def update_van(self):
        spec = next((c for c in WOOD_CANH if c[0] == self.canh.get()), WOOD_CANH[0])
        vals = [spec[3], spec[4]]
        self.cb_van["values"] = vals
        if self.van.get() not in vals:
            self.van.set(vals[0])

    def van_idx(self):
        vals = list(self.cb_van["values"])
        return vals.index(self.van.get()) if self.van.get() in vals else 0

    def on_group(self):
        wood = self.is_wood()
        for f in (self.opt_loose, self.opt_wood):
            f.pack_forget()
        (self.opt_wood if wood else self.opt_loose).pack(side="left")
        self.update_van()
        self.btn_import.config(text="📥 Nhập bảng giá gỗ (PDF)" if wood else "📥 Nhập file (Excel/PDF/Word/CSV)")
        self.btn_order.config(text="➕ Lập dòng trong đơn gỗ" if wood else "➕ Thêm vào đơn hàng")
        self.btn_imgs.state(["disabled" if wood else "!disabled"])
        self.spin.state(["disabled" if wood else "!disabled"])
        cols = ([("stt", "STT", 45), ("unit", "ĐVT", 80), ("price", "Đơn giá", 125)] if wood else
                [("stt", "STT", 40), ("size", "Kích thước", 150), ("unit", "ĐVT", 50), ("list", "Giá niêm yết", 105), ("tier", "Giá theo mức", 115)])
        self.tree.configure(columns=[c[0] for c in cols])
        self.tree.heading("#0", text="Hạng mục / Sản phẩm  (gõ vào ô tìm kiếm để lọc)")
        self.tree.column("#0", width=380)
        for cid, t, w in cols:
            self.tree.heading(cid, text=t)
            self.tree.column(cid, width=w, anchor="e" if cid in ("list", "tier", "price") else "center", stretch=False)
        self.info.config(text="")
        self.img.config(image="", text="🪵  Hàng gỗ – đơn giá theo m² / md" if wood else "Chưa có ảnh")
        self.refresh()

    def reload_options(self):
        S = self.app.settings
        labels = [t["label"] for t in S["tiers"]]
        self.cb_tier["values"] = labels
        if self.tier.get() not in labels:
            self.tier.set(labels[1] if len(labels) > 1 else labels[0])
        self.cb_series["values"] = ["Tất cả"] + sorted({p["series"] for p in self.app.products if p["series"]})
        self.refresh()

    def current_tier(self):
        return next((t for t in self.app.settings["tiers"] if t["label"] == self.tier.get()), self.app.settings["tiers"][0])

    def toggle(self, opened):
        for iid in self.tree.get_children():
            if iid.startswith("cat::"):
                self.tree.item(iid, open=opened)

    # ---- hiển thị
    def refresh(self):
        if not hasattr(self, "tree") or not self.tree["columns"]:
            return
        opened = {i for i in self.tree.get_children() if self.tree.item(i, "open")}
        self.tree.delete(*self.tree.get_children())
        q = importer.strip_acc(self.q.get())
        if self.is_wood():
            self.cur = []
            idx = self.van_idx()
            for it in self.wdata()["items"]:
                if q and q not in importer.strip_acc(it["name"] + " " + it.get("note", "") + " " + str(it.get("unit", ""))):
                    continue
                self.cur.append(it)
                pr = wood_price(it, self.canh.get(), idx)
                self.tree.insert("", "end", iid=it["id"], text=it["name"], values=(it.get("stt") or "", it.get("unit", ""), money(pr) if pr else "—"))
            return
        tier = self.current_tier()
        groups = {}
        for p in self.app.products:
            if self.series.get() not in ("Tất cả", "") and p["series"] != self.series.get():
                continue
            if q and q not in importer.strip_acc(p["name"] + " " + p["category"] + " " + p["series"] + " " + p.get("desc", "")):
                continue
            groups.setdefault(p["category"], []).append(p)
        for cat, ps in groups.items():
            iid = "cat::" + cat
            self.tree.insert("", "end", iid=iid, text=f"{cat}  ({len(ps)})", open=bool(q) or iid in opened, tags=("cat",))
            for i, p in enumerate(ps, 1):
                nm = p["name"] + (f"   [{p['series']}]" if p["series"] else "")
                self.tree.insert(iid, "end", iid=p["id"], text=nm,
                                 values=(i, engine.size_text(p), p["unit"], money(p["retail"]), money(engine.tier_price(p, tier))))

    def selected(self):
        s = self.tree.selection()
        if not s:
            return None
        if self.is_wood():
            return next((it for it in self.wdata()["items"] if it["id"] == s[0]), None)
        return self.app.pmap.get(s[0])

    def show(self, _=None):
        p = self.selected()
        if not p:
            return
        if self.is_wood():
            self.thumb = load_thumb("wood_" + p["id"], (250, 170))
            self.img.config(image=self.thumb or "", text="" if self.thumb else "🪵  Hàng gỗ – đơn giá theo m² / md")
            lines = [p["name"], f"ĐVT: {p.get('unit') or '-'}", ""]
            lines += [f"{woodimport.PRICE_LABELS[k]}: {money(v)}đ" for k, v in p["prices"].items()]
            if p.get("note"):
                lines += ["", p["note"]]
            self.info.config(text="\n".join(lines))
            return
        self.thumb = load_thumb(p["id"], (250, 170))
        self.img.config(image=self.thumb or "", text="" if self.thumb else "Chưa có ảnh")
        S = self.app.settings
        lines = [p["name"], f"Dòng: {p['series'] or '-'}  |  Danh mục: {p['category']}",
                 f"Kích thước: {engine.size_text(p) or '-'}", f"Chất liệu/diễn giải: {p.get('desc') or '-'}", ""]
        lines += [f"{t['label']}: {money(engine.tier_price(p, t))}đ" for t in S["tiers"]]
        k = engine.ship_class(p, S)
        lines += ["", f"Phân loại ship: {next(c['name'] for c in S['ship_classes'] if c['key'] == k)}",
                  f"Lắp ráp: {money(p.get('assembly', 0))}đ  |  Ván chống ẩm: {money(p.get('moisture', 0))}đ"]
        self.info.config(text="\n".join(lines))

    def to_order(self):
        p = self.selected()
        if not p:
            messagebox.showinfo("Chọn sản phẩm", "Hãy chọn một dòng trong danh sách.")
            return
        if self.is_wood():
            idx = self.van_idx()
            pr = wood_price(p, self.canh.get(), idx)
            self.app.order.prefill_wood(p, pr or 0, wood_label(p, self.canh.get(), idx), WOOD_KINDS[self.group.get()])
        else:
            fee = self.app.settings.get("moist_fee", 300000)
            kem = messagebox.askyesno("Ván chống ẩm", f"Kèm ván chống ẩm cho sản phẩm này?\n(cộng thêm {money(fee)}đ / sản phẩm – sửa tay được trong đơn)")
            self.app.order.add_product(p["id"], max(1, self.qty.get()), fee if kem else None)
        self.app.show_tab(self.app.order)

    # ---- thêm / sửa / xóa
    def add(self):
        if self.is_wood():
            d = WoodDialog(self.app)
            if d.result:
                self.wdata()["items"].append(d.result)
                self.save_wood()
            return
        d = ProductDialog(self.app)
        if d.result:
            self.app.products.append(d.result)
            self.app.save_products()

    def edit(self):
        p = self.selected()
        if not p:
            return
        if self.is_wood():
            d = WoodDialog(self.app, p)
            if d.result:
                p.update(d.result)
                self.save_wood()
            return
        d = ProductDialog(self.app, p)
        if d.result:
            p.update(d.result)
            self.app.save_products()
            self.show()

    def delete(self):
        p = self.selected()
        if not p or not messagebox.askyesno("Xóa", f"Xóa:\n{p['name']}?"):
            return
        if self.is_wood():
            self.wdata()["items"].remove(p)
            self.save_wood()
        else:
            self.app.products.remove(p)
            self.app.save_products()

    def save_wood(self):
        store.save_wood(self.app.wood)
        self.refresh()

    # ---- nhập file
    def import_any(self):
        (self.import_wood if self.is_wood() else self.import_file)()

    def import_wood(self):
        fp = filedialog.askopenfilename(filetypes=[("Bảng giá gỗ (PDF)", "*.pdf")])
        if not fp:
            return
        self.app.status("Đang đọc bảng giá gỗ…")

        def done(ok, res):
            self.app.status("")
            if not ok:
                messagebox.showerror("Không đọc được file", str(res))
                return
            items, footer = res
            nm = WOOD_KINDS[self.group.get()]
            nimg = sum(1 for it in items if it.get("_img"))
            if messagebox.askyesno("Nhập bảng giá gỗ", f"Đọc được {len(items)} hạng mục ({nimg} ảnh).\nThay thế toàn bộ bảng giá '{nm}' hiện tại?"):
                for it in items:
                    img = it.pop("_img", None)
                    if img:
                        store.save_image_bytes("wood_" + it["id"], img)
                self.app.wood[self.group.get()] = {"items": items, "footer": footer}
                self.save_wood()

        run_bg(self, lambda: woodimport.read_wood_pdf(fp), done)

    def assign_images(self):
        """Gán ảnh sản phẩm từ file báo giá (PDF/Excel) – khớp theo tên + kích thước, rồi tên, rồi kích thước + giá."""
        fp = filedialog.askopenfilename(title="Chọn file báo giá có ảnh sản phẩm", filetypes=[("Bảng giá có ảnh", "*.pdf *.xlsx *.xlsm"), ("Tất cả", "*.*")])
        if not fp:
            return
        ans = messagebox.askyesnocancel("Gán ảnh", "Chỉ gán ảnh cho sản phẩm CHƯA có ảnh?\n\n"
                                        "Có = chỉ sản phẩm đang thiếu ảnh.\nKhông = gán lại ảnh cho tất cả sản phẩm khớp trong file (ghi đè ảnh cũ).", parent=self)
        if ans is None:
            return
        self.app.status("Đang đọc ảnh từ file báo giá…")

        def done(ok, res):
            self.app.status("")
            if not ok:
                messagebox.showerror("Không đọc được file", str(res))
                return
            entries = [e for e in res if e.get("_img")]
            n, missing = 0, []
            for p in self.app.products:
                has = os.path.exists(store.image_path(p["id"]))
                if has and ans:
                    continue
                e = importer.match_entry(p, entries)
                if e:
                    store.save_image_bytes(p["id"], e["_img"])
                    n += 1
                elif not has:
                    missing.append(p["name"])
            self.show()
            msg = f"Đã gán ảnh cho {n} sản phẩm."
            if missing:
                msg += f"\n\nCòn {len(missing)} sản phẩm chưa có ảnh khớp trong file:\n" + "\n".join("• " + m for m in missing[:15]) + ("\n…" if len(missing) > 15 else "")
            messagebox.showinfo("Gán ảnh", msg)

        run_bg(self, lambda: importer.import_file(fp), done)

    def import_file(self):
        fp = filedialog.askopenfilename(filetypes=[("Bảng giá", "*.xlsx *.xlsm *.pdf *.docx *.csv *.txt"), ("Tất cả", "*.*")])
        if not fp:
            return
        series = simpledialog.askstring("Dòng sản phẩm", "Tên dòng/bộ sưu tập (để trống nếu file có nhiều dòng):", parent=self) or ""
        self.app.status("Đang đọc file…")

        def done(ok, res):
            self.app.status("")
            if not ok:
                messagebox.showerror("Không đọc được file", str(res))
                return
            dlg = ImportPreview(self.app, res)
            if dlg.result:
                a, u = store.merge_products(self.app.products, res, dlg.result)
                self.app.save_products()
                messagebox.showinfo("Hoàn tất", f"Đã thêm {a} sản phẩm mới, cập nhật {u} sản phẩm.")

        run_bg(self, lambda: importer.import_file(fp, series.strip()), done)


class WoodPicker(tk.Toplevel):
    def __init__(self, app, kind_key):
        super().__init__(app)
        self.app, self.kind_key, self.result = app, kind_key, None
        self.title("Chọn từ bảng giá gỗ – " + WOOD_KINDS[kind_key])
        self.transient(app)
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")
        self.q, self.canh, self.van = tk.StringVar(), tk.StringVar(value="Melamin"), tk.StringVar(value="Chống ẩm")
        ttk.Label(top, text="🔍").pack(side="left")
        e = ttk.Entry(top, textvariable=self.q, width=30)
        e.pack(side="left", padx=4)
        e.focus_set()
        ttk.Label(top, text="Cánh:").pack(side="left", padx=(12, 2))
        ttk.Combobox(top, textvariable=self.canh, values=[c[0] for c in WOOD_CANH], width=12, state="readonly").pack(side="left")
        ttk.Label(top, text="Ván:").pack(side="left", padx=(12, 2))
        self.cb_van = ttk.Combobox(top, textvariable=self.van, width=20, state="readonly")
        self.cb_van.pack(side="left")
        fr, self.t = make_tree(self, [("stt", "STT"), ("name", "Hạng mục"), ("unit", "ĐVT"), ("price", "Đơn giá")], (45, 440, 80, 110), height=18)
        fr.pack(fill="both", expand=True, padx=8)
        ttk.Button(self, text="Dùng hạng mục này", style="Accent.TButton", command=self.ok).pack(pady=8)
        for v in (self.q, self.canh, self.van):
            v.trace_add("write", lambda *a: self.fill())
        self.canh.trace_add("write", lambda *a: self.upd())
        self.t.bind("<Double-1>", lambda e: self.ok())
        self.upd()
        place(self, app)
        self.grab_set()
        self.wait_window()

    def upd(self):
        spec = next((c for c in WOOD_CANH if c[0] == self.canh.get()), WOOD_CANH[0])
        self.cb_van["values"] = [spec[3], spec[4]]
        if self.van.get() not in (spec[3], spec[4]):
            self.van.set(spec[3])
        self.fill()

    def idx(self):
        return list(self.cb_van["values"]).index(self.van.get()) if self.van.get() in list(self.cb_van["values"]) else 0

    def fill(self):
        if not hasattr(self, "t"):
            return
        self.t.delete(*self.t.get_children())
        q = importer.strip_acc(self.q.get())
        for it in self.app.wood[self.kind_key]["items"]:
            if q and q not in importer.strip_acc(it["name"]):
                continue
            pr = wood_price(it, self.canh.get(), self.idx())
            self.t.insert("", "end", iid=it["id"], values=(it.get("stt") or "", it["name"], it.get("unit", ""), money(pr) if pr else "—"))

    def ok(self):
        s = self.t.selection()
        if s:
            it = next(x for x in self.app.wood[self.kind_key]["items"] if x["id"] == s[0])
            self.result = (it, wood_price(it, self.canh.get(), self.idx()) or 0, wood_label(it, self.canh.get(), self.idx()))
            self.destroy()


# ======================================================================= Chọn sản phẩm
class Picker(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app, self.result = app, None
        self.title("Chọn sản phẩm")
        self.transient(app)
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")
        self.q = tk.StringVar()
        ttk.Label(top, text="🔍 Tìm:").pack(side="left")
        e = ttk.Entry(top, textvariable=self.q, width=40)
        e.pack(side="left", padx=6)
        e.focus_set()
        ttk.Label(top, text="SL:").pack(side="left", padx=(12, 2))
        self.qty = tk.IntVar(value=1)
        ttk.Spinbox(top, from_=1, to=999, textvariable=self.qty, width=5).pack(side="left")
        mrow = ttk.Frame(self, padding=(8, 0, 8, 6))
        mrow.pack(fill="x")
        self.moist, self.moist_fee = tk.BooleanVar(), tk.StringVar(value=money(app.settings.get("moist_fee", 300000)))
        ttk.Checkbutton(mrow, text="Kèm ván chống ẩm", variable=self.moist).pack(side="left")
        ttk.Label(mrow, text="   cộng thêm").pack(side="left")
        ttk.Entry(mrow, textvariable=self.moist_fee, width=10).pack(side="left", padx=4)
        ttk.Label(mrow, text="đ / sản phẩm (sửa tay được)", foreground=MUTED).pack(side="left")
        fr, self.t = make_tree(self, [("cat", "Danh mục"), ("name", "Sản phẩm"), ("size", "Kích thước"), ("price", "Giá niêm yết")],
                               (110, 320, 150, 100), height=18)
        fr.pack(fill="both", expand=True, padx=8)
        ttk.Button(self, text="Thêm vào đơn", style="Accent.TButton", command=self.ok).pack(pady=8)
        self.q.trace_add("write", lambda *a: self.fill())
        self.t.bind("<Double-1>", lambda e: self.ok())
        self.fill()
        place(self, app)
        self.grab_set()
        self.wait_window()

    def fill(self):
        self.t.delete(*self.t.get_children())
        q = importer.strip_acc(self.q.get())
        for p in self.app.products:
            if q and q not in importer.strip_acc(p["name"] + " " + p["category"] + " " + p["series"]):
                continue
            self.t.insert("", "end", iid=p["id"], values=(p["category"], p["name"], engine.size_text(p), money(p["retail"])))

    def ok(self):
        s = self.t.selection()
        if s:
            self.result = (s[0], max(1, self.qty.get()), parse_money(self.moist_fee.get()) if self.moist.get() else None)
            self.destroy()


class TextDialog(tk.Toplevel):
    """Hộp nhập rộng rãi: 1 dòng (số, giá) hoặc nhiều dòng (tên, diễn giải) – dễ nhìn, dễ sửa. Ctrl+Enter = OK."""
    def __init__(self, app, title, prompt, initial="", multiline=False, collapse=False):
        super().__init__(app)
        self.result, self.collapse = None, collapse
        self.title(title)
        self.transient(app)
        f = ttk.Frame(self, padding=16)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text=prompt, wraplength=680, justify="left", font=(FONT, 11)).pack(anchor="w", pady=(0, 8))
        if multiline:
            box = ttk.Frame(f)
            box.pack(fill="both", expand=True)
            self.w = tk.Text(box, width=72, height=7, wrap="word", font=(FONT, 12), undo=True, padx=8, pady=6)
            sb = ttk.Scrollbar(box, command=self.w.yview)
            self.w.configure(yscrollcommand=sb.set)
            self.w.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")
            self.w.insert("1.0", str(initial or ""))
            self.w.bind("<Control-Return>", lambda e: (self.ok(), "break")[1])
            self.w.bind("<Tab>", lambda e: (e.widget.tk_focusNext().focus(), "break")[1])
            self.w.tag_add("sel", "1.0", "end-1c")
            hint = "Enter = xuống dòng  ·  Ctrl+Enter = OK  ·  Esc = hủy"
        else:
            self.var = tk.StringVar(value=str(initial or ""))
            self.w = ttk.Entry(f, textvariable=self.var, width=62, font=(FONT, 13))
            self.w.pack(fill="x", ipady=5)
            self.w.select_range(0, "end")
            self.w.bind("<Return>", lambda e: self.ok())
            hint = "Enter = OK  ·  Esc = hủy"
        ttk.Label(f, text=hint, foreground=MUTED).pack(anchor="w", pady=(6, 0))
        bt = ttk.Frame(f)
        bt.pack(fill="x", pady=(10, 0))
        ttk.Button(bt, text="OK", style="Accent.TButton", command=self.ok).pack(side="right")
        ttk.Button(bt, text="Hủy", command=self.destroy).pack(side="right", padx=6)
        self.bind("<Escape>", lambda e: self.destroy())
        self.w.focus_set()
        place(self, app)
        self.grab_set()
        self.wait_window()

    def ok(self):
        v = self.w.get("1.0", "end-1c") if isinstance(self.w, tk.Text) else self.var.get()
        self.result = " ".join(v.split()) if self.collapse else v.strip()
        self.destroy()


def ask_text(app, title, prompt, initial="", multiline=False, collapse=False):
    """Trả về chuỗi đã nhập (có thể rỗng) hoặc None nếu bấm Hủy."""
    return TextDialog(app, title, prompt, initial, multiline, collapse).result


class TextVar:
    """Giống tk.StringVar nhưng gắn với ô Text nhiều dòng (để nhập diễn giải nhiều dòng)."""
    def __init__(self, text):
        self.t, self._cbs = text, []
        text.bind("<KeyRelease>", lambda e: [cb() for cb in self._cbs])
        text.bind("<Tab>", lambda e: (e.widget.tk_focusNext().focus(), "break")[1])

    def get(self):
        return self.t.get("1.0", "end-1c")

    def set(self, v):
        self.t.delete("1.0", "end")
        self.t.insert("1.0", v or "")

    def trace_add(self, mode, cb):
        self._cbs.append(cb)


class ChoiceDialog(tk.Toplevel):
    """Hộp chọn 1 giá trị trong danh sách (dùng khi nhấp đúp ô Loại ship / ĐVT)."""
    def __init__(self, app, title, prompt, options, initial=0):
        super().__init__(app)
        self.result, self.options = None, list(options)
        self.title(title)
        self.transient(app)
        f = ttk.Frame(self, padding=12)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text=prompt, justify="left").pack(anchor="w")
        self.v = tk.StringVar(value=self.options[initial] if self.options else "")
        cb = ttk.Combobox(f, textvariable=self.v, values=self.options, state="readonly", width=36)
        cb.pack(pady=8, anchor="w")
        bt = ttk.Frame(f)
        bt.pack(anchor="e")
        ttk.Button(bt, text="OK", style="Accent.TButton", command=self.ok).pack(side="left")
        ttk.Button(bt, text="Hủy", command=self.destroy).pack(side="left", padx=6)
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        place(self, app)
        self.grab_set()
        cb.focus_set()
        self.wait_window()

    def ok(self):
        if self.v.get() in self.options:
            self.result = self.options.index(self.v.get())
        self.destroy()


class LineDialog(tk.Toplevel):
    """Thêm tay 1 sản phẩm ngoài danh mục hoặc 1 khoản phụ phí / chi phí phát sinh."""
    def __init__(self, app, fee=False):
        super().__init__(app)
        self.app, self.result, self.fee = app, None, fee
        self.title("Thêm phụ phí / chi phí phát sinh" if fee else "Thêm sản phẩm ngoài danh mục")
        self.transient(app)
        S = app.settings
        self.cls_names = ["Không tính vào phí ship"] + [c["name"] for c in S["ship_classes"]]
        self.cls_keys = [""] + [c["key"] for c in S["ship_classes"]]
        self.v = {k: tk.StringVar() for k in ("name", "size", "unit", "qty", "price", "cls")}
        self.v["qty"].set("1")
        self.v["unit"].set("gói" if fee else "bộ")
        self.v["cls"].set(self.cls_names[0])
        f = ttk.Frame(self, padding=12)
        f.pack(fill="both", expand=True)
        rows = [("Nội dung phụ phí" if fee else "Tên sản phẩm", "name", 70), ("Kích thước / ghi chú (không bắt buộc)", "size", 70),
                ("Đơn vị tính", "unit", 12), ("Số lượng", "qty", 8), ("Đơn giá (đ)", "price", 16)]
        for r, (lab, k, w) in enumerate(rows):
            ttk.Label(f, text=lab).grid(row=r, column=0, sticky="w", pady=3)
            if k == "unit":
                ttk.Combobox(f, textvariable=self.v[k], values=["bộ", "cái", "gói", "chuyến", "m", "m2", "kg"], width=w).grid(row=r, column=1, sticky="w", padx=(8, 0))
            else:
                e = ttk.Entry(f, textvariable=self.v[k], width=w, font=(FONT, 11) if w > 20 else None)
                e.grid(row=r, column=1, sticky="w", padx=(8, 0), ipady=2 if w > 20 else 0)
                if k == "name":
                    e.focus_set()
        n = len(rows)
        self.moist, self.moist_fee = tk.BooleanVar(), tk.StringVar(value=money(S.get("moist_fee", 300000)))
        if not fee:
            ttk.Label(f, text="Loại ship").grid(row=n, column=0, sticky="w", pady=3)
            ttk.Combobox(f, textvariable=self.v["cls"], values=self.cls_names, state="readonly", width=24).grid(row=n, column=1, sticky="w", padx=(8, 0))
            n += 1
            mf = ttk.Frame(f)
            mf.grid(row=n, column=0, columnspan=2, sticky="w", pady=3)
            ttk.Checkbutton(mf, text="Kèm ván chống ẩm", variable=self.moist).pack(side="left")
            ttk.Label(mf, text="   cộng thêm").pack(side="left")
            ttk.Entry(mf, textvariable=self.moist_fee, width=10).pack(side="left", padx=4)
            ttk.Label(mf, text="đ / sản phẩm", foreground=MUTED).pack(side="left")
            n += 1
        note = ("Phụ phí được cộng thẳng vào tổng thanh toán, không bị tính vào mức giá, khuyến mãi % hay phí ship."
                if fee else "Sản phẩm ngoài danh mục dùng đúng đơn giá bạn nhập (không áp chiết khấu mức giá).\n"
                            "Mặc định không tính vào phí ship – chọn 'Loại ship' nếu muốn tính.")
        ttk.Label(f, text=note, foreground=MUTED, wraplength=440, justify="left").grid(row=n, column=0, columnspan=2, sticky="w", pady=(8, 4))
        bt = ttk.Frame(f)
        bt.grid(row=n + 1, column=0, columnspan=2, sticky="e", pady=(6, 0))
        ttk.Button(bt, text="Thêm vào đơn", style="Accent.TButton", command=self.ok).pack(side="left")
        ttk.Button(bt, text="Hủy", command=self.destroy).pack(side="left", padx=6)
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        place(self, app)
        self.grab_set()
        self.wait_window()

    def ok(self):
        g = lambda k: self.v[k].get().strip()
        if not g("name"):
            messagebox.showwarning("Thiếu thông tin", "Nhập tên / nội dung.", parent=self)
            return
        if not g("price"):
            messagebox.showwarning("Thiếu đơn giá", "Nhập đơn giá (đ). Nhập 0 nếu là hàng tặng.", parent=self)
            return
        qty = parse_float(g("qty"))
        if not qty or qty <= 0:
            messagebox.showwarning("Số lượng", "Số lượng phải lớn hơn 0.", parent=self)
            return
        if qty == int(qty):
            qty = int(qty)
        ci = self.cls_names.index(g("cls")) if g("cls") in self.cls_names else 0
        self.result = {"name": g("name"), "size": g("size"), "unit": g("unit"), "qty": qty,
                       "price": parse_money(g("price")), "class_ov": "" if self.fee else self.cls_keys[ci],
                       "moist_fee": parse_money(self.moist_fee.get()) if (self.moist.get() and not self.fee) else None}
        self.destroy()


# ======================================================================= Lên đơn
SMART_CHOICES = [("Tự nhận", "auto"), ("Nội thất bán sẵn", "loose"), ("Hàng gỗ – Hàng rời", "roi"), ("Hàng gỗ – Hàng công trình", "congtrinh")]


def build_smart_plan(app, res, choice):
    """Kết quả đọc được -> kế hoạch lập đơn: loại đơn, từng dòng + sản phẩm khớp trong bảng giá + giá."""
    items = res["items"]
    kind = res["wood_kind"] if res["wood_kind"] != "unknown" else "congtrinh"
    if choice == "loose":
        t = "loose"
    elif choice in ("roi", "congtrinh"):
        t, kind = "wood", choice
    elif res["order_type"] != "unknown":
        t = res["order_type"]
    else:
        t = smartorder.guess_type(items, app.products, app.wood[kind]["items"])[0]
    rows = []
    for it in items:
        r = {"name": it["name"], "qty": it["qty"], "unit": it["unit"], "dai": it["dai"], "cao": it["cao"], "sau": it["sau"], "price": it["price"],
             "amount": it["amount"], "note": it["note"], "match": None, "score": 0.0, "status": "none", "cat_price": None, "label": ""}
        if t == "loose":
            p, sc, st = smartorder.match_product(it, app.products)
            r.update(match=p, score=sc, status=st, cat_price=(p or {}).get("retail"))
        else:
            w, sc, st = smartorder.match_wood(it, app.wood[kind]["items"])
            r.update(match=w, score=sc, status=st)
            set_wood_match(r, w)
        rows.append(r)
    return {"otype": t, "kind": kind if t == "wood" else None, "customer": dict(res["customer"]), "advance": res["advance"],
            "advance_pct": res.get("advance_pct"), "notes": res.get("notes", ""), "rows": rows}


def set_wood_match(r, w):
    r["match"] = w
    if w:
        canh, vi = smartorder.detect_canh(r["name"] + " " + r["note"])
        r["cat_price"], r["label"] = wood_price(w, canh, vi), wood_label(w, canh, vi)
    else:
        r["cat_price"], r["label"] = None, ""


def smart_row_price(r):
    """Giá đang dùng cho dòng: ưu tiên giá trong file, rồi thành tiền/SL, rồi bảng giá."""
    if r["price"]:
        return r["price"], "file"
    if r["amount"] and r["qty"]:
        return r["amount"] / r["qty"], "file"
    if r["cat_price"]:
        return r["cat_price"], "bảng giá"
    return None, ""


class SmartImportDialog(tk.Toplevel):
    """Đọc đơn từ ảnh / file / văn bản dán tay -> xem lại -> tạo đơn (sửa tay hoặc xuất ngay)."""
    def __init__(self, app):
        super().__init__(app)
        self.app, self.files, self.plan, self.result, self.busy = app, [], None, None, False
        self.q = queue.Queue()
        self.title("Đọc đơn từ ảnh / file / văn bản")
        self.transient(app)
        self.choice = tk.StringVar(value=SMART_CHOICES[0][0])
        self.use_ai = tk.BooleanVar(value=True)
        self.v_name, self.v_phone, self.v_addr, self.v_adv = tk.StringVar(), tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.s1, self.s2 = ttk.Frame(self, padding=14), ttk.Frame(self, padding=14)
        self._build1()
        self._build2()
        self.s1.pack(fill="both", expand=True)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        place(self, app)
        self.grab_set()
        self.wait_window()

    # --- bước 1: nhập liệu
    def _build1(self):
        f = self.s1
        ttk.Label(f, text="Dán / gõ nội dung đơn hàng vào ô dưới, và/hoặc chọn ảnh, file (jpg, png, pdf, docx, xlsx, txt).",
                  font=(FONT, 11, "bold")).pack(anchor="w")
        ttk.Label(f, text="Có hoặc chưa có giá đều được – dòng nào thiếu giá sẽ lấy từ bảng giá.", foreground=MUTED).pack(anchor="w", pady=(0, 6))
        box = ttk.Frame(f)
        box.pack(fill="both", expand=True)
        self.txt = tk.Text(box, width=96, height=10, wrap="word", font=(FONT, 11), undo=True, padx=8, pady=6)
        sb = ttk.Scrollbar(box, command=self.txt.yview)
        self.txt.configure(yscrollcommand=sb.set)
        self.txt.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.txt.focus_set()
        fr = ttk.Frame(f)
        fr.pack(fill="x", pady=(8, 0))
        ttk.Button(fr, text="📎 Chọn ảnh / file…", command=self.pick_files).pack(side="left")
        ttk.Button(fr, text="📋 Dán ảnh từ clipboard", command=self.paste_image).pack(side="left", padx=4)
        ttk.Button(fr, text="🧹 Bỏ file", command=self.clear_files).pack(side="left")
        self.files_lbl = ttk.Label(f, text="Chưa chọn file nào", foreground=MUTED, wraplength=820, justify="left")
        self.files_lbl.pack(fill="x", pady=(4, 0))
        opt = ttk.Frame(f)
        opt.pack(fill="x", pady=(10, 0))
        ttk.Label(opt, text="Loại đơn:").pack(side="left")
        ttk.Combobox(opt, textvariable=self.choice, values=[c[0] for c in SMART_CHOICES], state="readonly", width=26).pack(side="left", padx=(4, 16))
        ttk.Checkbutton(opt, text="Dùng AI để đọc (đọc được ảnh, chữ lộn xộn)", variable=self.use_ai).pack(side="left")
        ak = ttk.Frame(f)
        ak.pack(fill="x", pady=(6, 0))
        self.key_lbl = ttk.Label(ak, text="", foreground=BRAND, font=(FONT, 10, "bold"))
        self.key_lbl.pack(side="left")
        ttk.Button(ak, text="🔑 Cài API key…", command=self.set_key).pack(side="left", padx=8)
        ttk.Label(f, text="Khi dùng AI, ảnh/văn bản đơn hàng được gửi tới Anthropic (Claude) để đọc. Không dùng AI thì chỉ đọc được văn bản/file có chữ, không đọc được ảnh.",
                  foreground=MUTED, wraplength=820, justify="left").pack(fill="x", pady=(4, 0))
        self.status = ttk.Label(f, text="", foreground=BRAND, font=(FONT, 10, "bold"), wraplength=820, justify="left")
        self.status.pack(fill="x", pady=(8, 0))
        bt = ttk.Frame(f)
        bt.pack(fill="x", pady=(8, 0))
        self.btn_go = ttk.Button(bt, text="🔍 Đọc & phân tích", style="Accent.TButton", command=self.analyze)
        self.btn_go.pack(side="right")
        ttk.Button(bt, text="Đóng", command=self.destroy).pack(side="right", padx=6)
        self.refresh_key()

    def refresh_key(self):
        k = (self.app.settings.get("ai_key") or "").strip()
        self.key_lbl.config(text=("🔑 API key: đã cài (…" + k[-4:] + ")") if k else "🔑 API key: chưa cài (cần để đọc ảnh)")

    def set_key(self):
        v = ask_text(self.app, "API key", "Dán API key của Anthropic (bắt đầu bằng sk-ant-…).\\nLấy tại console.anthropic.com → API keys. Key chỉ lưu trên máy này.\\nĐể trống = xóa key.",
                     self.app.settings.get("ai_key", ""))
        if v is not None:
            self.app.settings["ai_key"] = v.strip()
            self.app.save_settings()
            self.refresh_key()

    def pick_files(self):
        fps = filedialog.askopenfilenames(parent=self, title="Chọn ảnh / file đơn hàng", filetypes=[
            ("Ảnh / file đơn hàng", "*.jpg *.jpeg *.png *.webp *.bmp *.pdf *.docx *.xlsx *.xlsm *.txt *.csv"), ("Tất cả", "*.*")])
        for fp in fps:
            if fp not in self.files:
                self.files.append(fp)
        self.show_files()

    def paste_image(self):
        try:
            from PIL import ImageGrab
            im = ImageGrab.grabclipboard()
        except Exception as e:  # noqa
            messagebox.showinfo("Clipboard", f"Không đọc được clipboard trên máy này ({e}).\\nHãy lưu ảnh thành file rồi bấm “Chọn ảnh / file…”.", parent=self)
            return
        if im is None:
            messagebox.showinfo("Clipboard", "Clipboard chưa có ảnh. Chụp/copy ảnh đơn hàng trước rồi bấm lại.", parent=self)
            return
        if isinstance(im, list):
            self.files += [p for p in im if p not in self.files]
        else:
            fp = os.path.join(tempfile.gettempdir(), f"moctam_clip_{len(self.files) + 1}_{uuid.uuid4().hex[:6]}.png")
            im.save(fp)
            self.files.append(fp)
        self.show_files()

    def clear_files(self):
        self.files = []
        self.show_files()

    def show_files(self):
        self.files_lbl.config(text=("Đã chọn %d file: " % len(self.files) + ", ".join(os.path.basename(p) for p in self.files)) if self.files else "Chưa chọn file nào")

    def analyze(self):
        if self.busy:
            return
        pasted = self.txt.get("1.0", "end-1c")
        if not pasted.strip() and not self.files:
            messagebox.showinfo("Chưa có nội dung", "Hãy dán văn bản hoặc chọn ảnh/file đơn hàng trước.", parent=self)
            return
        S = self.app.settings
        key, use_ai, model = (S.get("ai_key") or "").strip(), bool(self.use_ai.get()), S.get("ai_model") or smartorder.DEFAULT_MODEL
        files = list(self.files)
        self.busy = True
        self.btn_go.state(["disabled"])
        self.status.config(text="⏳ Đang đọc đơn hàng… (ảnh có thể mất 10–30 giây)")

        def work():
            try:
                text, images = smartorder.gather(files, pasted)
                if not text.strip() and not images:
                    raise ValueError("Không đọc được chữ trong file. Nếu là ảnh/scan hãy dùng AI (cài API key).")
                if images and not (key and use_ai):
                    raise ValueError("Đọc ảnh cần AI: bấm “🔑 Cài API key…” và tích “Dùng AI để đọc”.")
                warn = ""
                if key and use_ai:
                    try:
                        res = smartorder.extract_ai(key, text, images, model)
                    except Exception as e:  # noqa
                        if text.strip() and not images:
                            res, warn = smartorder.extract_rules(text), f"AI lỗi ({e}) – đã đọc bằng quy tắc, nhớ kiểm tra kỹ."
                        else:
                            raise
                else:
                    res = smartorder.extract_rules(text)
                self.q.put(("ok", res, warn))
            except Exception as e:  # noqa
                self.q.put(("err", str(e), ""))
        threading.Thread(target=work, daemon=True).start()
        self.after(200, self._poll)

    def _poll(self):
        try:
            kind, a, warn = self.q.get_nowait()
        except queue.Empty:
            if self.winfo_exists():
                self.after(200, self._poll)
            return
        self.busy = False
        self.btn_go.state(["!disabled"])
        if kind == "err":
            self.status.config(text="❌ " + a)
            return
        self.status.config(text="")
        choice = next(v for k, v in SMART_CHOICES if k == self.choice.get())
        self.plan = build_smart_plan(self.app, a, choice)
        self.show_plan(warn)

    # --- bước 2: xem lại kết quả
    def _build2(self):
        f = self.s2
        self.head = ttk.Label(f, text="", font=(FONT, 11, "bold"), foreground=BRAND, wraplength=900, justify="left")
        self.head.pack(anchor="w")
        cf = ttk.LabelFrame(f, text="Khách hàng (sửa được)", padding=(10, 4, 10, 8))
        cf.pack(fill="x", pady=(6, 0))
        for i, (lbl, var, w) in enumerate((("Tên khách", self.v_name, 22), ("SĐT", self.v_phone, 14), ("Địa chỉ giao", self.v_addr, 44), ("Tiền ứng (đ)", self.v_adv, 14))):
            ttk.Label(cf, text=lbl).grid(row=0, column=i * 2, sticky="w", padx=(0 if i == 0 else 10, 4))
            ttk.Entry(cf, textvariable=var, width=w).grid(row=0, column=i * 2 + 1, sticky="w")
        cols = [("name", "Tên khách ghi"), ("qty", "SL"), ("price", "Giá trong file"), ("match", "Khớp bảng giá"), ("cat", "Giá bảng giá"), ("status", "Trạng thái")]
        fr, self.t = make_tree(f, cols, (260, 45, 100, 260, 100, 190), height=11)
        fr.pack(fill="both", expand=True, pady=(8, 0))
        self.t.tag_configure("ok", background="#E6F2E3")
        self.t.tag_configure("near", background="#FBEFD2")
        self.t.tag_configure("none", background="#F8DAD6")
        self.t.bind("<Double-1>", self.on_dbl)
        ttk.Label(f, text="💡 Nhấp đúp ô SL / Giá trong file để sửa; nhấp đúp ô “Khớp bảng giá” để chọn lại sản phẩm đúng. Xanh = khớp, vàng = gần giống (nên kiểm tra), đỏ = không thấy trong bảng giá (sẽ thêm dòng nhập tay).",
                  foreground=MUTED, wraplength=900, justify="left").pack(fill="x", pady=(4, 0))
        self.note = ttk.Label(f, text="", foreground=MUTED, wraplength=900, justify="left")
        self.note.pack(fill="x")
        bt = ttk.Frame(f)
        bt.pack(fill="x", pady=(8, 0))
        ttk.Button(bt, text="⚡ Tạo đơn & xuất biên lai ngay", style="Accent.TButton", command=lambda: self.finish("export")).pack(side="right")
        ttk.Button(bt, text="✔ Tạo đơn (để tôi sửa)", style="Accent.TButton", command=lambda: self.finish("make")).pack(side="right", padx=6)
        ttk.Button(bt, text="🗑 Bỏ dòng chọn", command=self.drop_row).pack(side="left")
        ttk.Button(bt, text="← Quay lại", command=self.back).pack(side="left", padx=6)

    def show_plan(self, warn=""):
        p = self.plan
        c = p["customer"]
        self.v_name.set(c["name"]); self.v_phone.set(c["phone"]); self.v_addr.set(c["address"])
        self.v_adv.set(money(p["advance"]) if p["advance"] else "")
        kind = "Nội thất bán sẵn" if p["otype"] == "loose" else "Hàng gỗ – " + WOOD_KINDS[p["kind"]]
        n = len(p["rows"])
        ok = sum(1 for r in p["rows"] if r["status"] == "ok")
        self.head.config(text=f"Đọc được {n} dòng sản phẩm  ·  Loại đơn: {kind}  ·  Khớp bảng giá: {ok}/{n}")
        notes = []
        if warn:
            notes.append(warn)
        if p.get("advance_pct"):
            notes.append(f"Khách ghi ứng {p['advance_pct']:g}% – sẽ tự tính theo tổng tiền khi tạo đơn.")
        if p.get("notes"):
            notes.append("Ghi chú đọc được: " + p["notes"])
        if n == 0:
            notes.append("Không thấy dòng sản phẩm nào – hãy quay lại, kiểm tra nội dung hoặc thử bật AI.")
        self.note.config(text="\\n".join(notes))
        self.fill_rows()
        self.s1.pack_forget()
        self.s2.pack(fill="both", expand=True)
        place(self, self.app)

    def fill_rows(self):
        self.t.delete(*self.t.get_children())
        for i, r in enumerate(self.plan["rows"]):
            price, src = smart_row_price(r)
            m = r["match"]
            mname = (m or {}).get("name", "") if m else "— (nhập tay)"
            if r["status"] == "none" and not price:
                st = "✖ Thiếu giá – nhập sau"
            elif r["status"] == "ok":
                st = "✔ Khớp" + (" · giá theo file" if r["price"] or r["amount"] else " · giá bảng giá")
            elif r["status"] == "near":
                st = "⚠ Gần giống – kiểm tra"
            else:
                st = "✖ Không có trong bảng giá"
            self.t.insert("", "end", iid=str(i), tags=(r["status"] if not (r["status"] == "none" and not price) else "none",),
                          values=(r["name"], f"{r['qty']:g}", money(r["price"] or (r["amount"] / r["qty"] if r["amount"] and r["qty"] else 0)) or "—",
                                  mname, money(r["cat_price"]) if r["cat_price"] else "—", st))

    def on_dbl(self, e):
        iid = self.t.identify_row(e.y)
        if not iid or self.t.identify_region(e.x, e.y) != "cell":
            return
        r = self.plan["rows"][int(iid)]
        col = self.t["columns"][int(self.t.identify_column(e.x)[1:]) - 1]
        if col == "name":
            v = ask_text(self.app, "Tên", "Tên sản phẩm:", r["name"], multiline=True, collapse=True)
            if v:
                r["name"] = v
        elif col == "qty":
            v = ask_text(self.app, "Số lượng", "Số lượng:", f"{r['qty']:g}")
            if v:
                try:
                    r["qty"] = max(0.01, float(v.replace(",", ".")))
                except ValueError:
                    pass
        elif col in ("price", "cat"):
            v = ask_text(self.app, "Đơn giá", "Đơn giá (đ) – để trống = lấy theo bảng giá:", money(r["price"]) if r["price"] else "")
            if v is not None:
                r["price"] = int(parse_money(v)) or None
                r["amount"] = None
        elif col in ("match", "status"):
            self.rematch(r)
        self.fill_rows()

    def rematch(self, r):
        p = self.plan
        if p["otype"] == "loose":
            d = Picker(self.app)
            if d.result and d.result[0] in self.app.pmap:
                pr = self.app.pmap[d.result[0]]
                r.update(match=pr, score=1.0, status="ok", cat_price=pr.get("retail"))
        else:
            d = WoodPicker(self.app, p["kind"])
            if d.result:
                it, price, label = d.result
                r.update(match=it, score=1.0, status="ok", cat_price=price or None, label=label)

    def drop_row(self):
        for iid in sorted(self.t.selection(), key=int, reverse=True):
            del self.plan["rows"][int(iid)]
        self.fill_rows()

    def back(self):
        self.s2.pack_forget()
        self.s1.pack(fill="both", expand=True)
        place(self, self.app)

    def finish(self, mode):
        p = self.plan
        if not p["rows"]:
            messagebox.showinfo("Chưa có dòng nào", "Không có dòng sản phẩm để tạo đơn.", parent=self)
            return
        p["customer"] = {"name": self.v_name.get().strip(), "phone": self.v_phone.get().strip(), "address": self.v_addr.get().strip()}
        adv = parse_money(self.v_adv.get())
        p["advance"] = int(adv) if adv else None
        self.result = (mode, p)
        self.destroy()


class OrderTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.items, self.geo, self.last = [], None, None
        self.order_id = None
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        left = ttk.Frame(self, padding=(12, 10, 6, 10))
        left.grid(row=0, column=0, sticky="nsew")
        right = ttk.Frame(self, padding=(6, 10, 12, 10))
        right.grid(row=0, column=1, sticky="nsew")

        self.otype, self.wood_kind = tk.StringVar(value="loose"), tk.StringVar(value="Hàng công trình")
        self.wood_lines = []
        self.inst = []                                    # các đợt ứng nhập tay (hàng công trình)
        self.final_reason = tk.StringVar(value=receipts.FINAL_REASON)
        self.iv_reason, self.iv_pct, self.iv_amt, self.iv_paid = tk.StringVar(), tk.StringVar(), tk.StringVar(), tk.BooleanVar()
        self.inst_sum = tk.StringVar()
        self.itree, self.inst_win, self.inst_lbl = None, None, None
        self.final_reason.trace_add("write", lambda *a: self.recalc())
        tb = ttk.Frame(left)
        tb.pack(fill="x", pady=(0, 8))
        ttk.Label(tb, text="Loại đơn:", font=(FONT, 10, "bold")).pack(side="left")
        ttk.Radiobutton(tb, text="🪑 Nội thất bán sẵn", value="loose", variable=self.otype, style="Toolbutton", command=self.switch).pack(side="left", padx=6)
        ttk.Radiobutton(tb, text="🪵 Hàng gỗ", value="wood", variable=self.otype, style="Toolbutton", command=self.switch).pack(side="left")
        ttk.Button(tb, text="🤖 Đọc đơn từ ảnh / file / văn bản", style="Accent.TButton", command=self.smart_import).pack(side="right")
        self.wk_frame = ttk.Frame(tb)
        ttk.Label(self.wk_frame, text="   Loại hàng gỗ:").pack(side="left")
        ttk.Combobox(self.wk_frame, textvariable=self.wood_kind, values=["Hàng rời", "Hàng công trình"], width=18, state="readonly").pack(side="left", padx=4)
        self.loose_box, self.wood_box = ttk.Frame(left), ttk.Frame(left)

        cf = ttk.LabelFrame(left, text="Khách hàng", padding=(10, 4, 10, 8))
        cf.pack(fill="x")
        self.name, self.phone, self.addr = tk.StringVar(), tk.StringVar(), tk.StringVar()
        ttk.Label(cf, text="Tên khách").grid(row=0, column=0, sticky="w")
        ttk.Entry(cf, textvariable=self.name, width=24).grid(row=0, column=1, padx=(6, 14), sticky="w")
        ttk.Label(cf, text="SĐT").grid(row=0, column=2, sticky="w")
        ttk.Entry(cf, textvariable=self.phone, width=15).grid(row=0, column=3, padx=(6, 14), sticky="w")
        ttk.Label(cf, text="Địa chỉ giao").grid(row=0, column=4, sticky="w")
        ttk.Entry(cf, textvariable=self.addr).grid(row=0, column=5, padx=(6, 0), sticky="ew")
        cf.columnconfigure(5, weight=1)

        rf = ttk.LabelFrame(left, text="Thông tin biên lai", padding=(10, 4, 10, 8))
        rf.pack(fill="x", pady=(8, 8))
        self.code = tk.StringVar()
        self.tech = tk.StringVar(value=app.settings["receipt"].get("tech", ""))
        self.handover, self.advance = tk.StringVar(), tk.StringVar()
        self.priority, self.paid = tk.StringVar(value="Tiêu Chuẩn"), tk.BooleanVar()
        self.title_var = tk.StringVar()
        ttk.Label(rf, text="Mã đơn").grid(row=0, column=0, sticky="w")
        fcode = ttk.Frame(rf)
        fcode.grid(row=0, column=1, padx=(6, 14), sticky="w")
        ttk.Entry(fcode, textvariable=self.code, width=11).pack(side="left")
        ttk.Button(fcode, text="↻", width=2, command=lambda: self.code.set(receipts.next_code(self.app.orders))).pack(side="left", padx=(3, 0))
        ttk.Label(rf, text="Kỹ thuật").grid(row=0, column=2, sticky="w")
        ttk.Entry(rf, textvariable=self.tech, width=15).grid(row=0, column=3, padx=(6, 14), sticky="w")
        ttk.Label(rf, text="Dự kiến bàn giao").grid(row=0, column=4, sticky="w")
        ttk.Entry(rf, textvariable=self.handover).grid(row=0, column=5, padx=(6, 0), sticky="ew")
        ttk.Label(rf, text="Tạm ứng (đ)").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(rf, textvariable=self.advance, width=14).grid(row=1, column=1, padx=(6, 14), pady=(6, 0), sticky="w")
        ttk.Label(rf, text="Ưu tiên").grid(row=1, column=2, sticky="w", pady=(6, 0))
        ttk.Combobox(rf, textvariable=self.priority, values=["Ưu Tiên", "Tiêu Chuẩn", "Linh Hoạt"], width=13, state="readonly").grid(row=1, column=3, padx=(6, 14), pady=(6, 0), sticky="w")
        ttk.Checkbutton(rf, text="Đã thanh toán khoản tạm ứng  (trống tạm ứng = 50%)", variable=self.paid).grid(row=1, column=4, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Label(rf, text="Tiêu đề in").grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(rf, textvariable=self.title_var).grid(row=2, column=1, columnspan=5, padx=(6, 0), pady=(6, 0), sticky="ew")
        self.inst_bar = ttk.Frame(rf)                       # chỉ hiện ở đơn hàng gỗ (hàng rời + hàng công trình)
        self.inst_bar.grid(row=3, column=0, columnspan=6, sticky="ew", pady=(6, 0))
        ttk.Button(self.inst_bar, text="💰 Các đợt ứng / thanh toán…", command=self.open_inst).pack(side="left")
        ttk.Label(self.inst_bar, textvariable=self.inst_sum, foreground=BRAND, font=(FONT, 10, "bold")).pack(side="left", padx=10)
        self.inst_bar.grid_remove()
        rf.columnconfigure(5, weight=1)

        sf = ttk.LabelFrame(self.loose_box, text="Vận chuyển – từ Nhà máy Mộc Tâm (Dĩ An)", padding=(10, 4, 10, 8))
        sf.pack(fill="x", pady=(0, 8))
        self.km_manual, self.zone_sel, self.lala = tk.StringVar(), tk.StringVar(value="Tự động"), tk.StringVar(value="0")
        self.ship_manual, self.asm_ov, self.moist_ov = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.btn_geo = ttk.Button(sf, text="📍 Tính khoảng cách", style="Accent.TButton", command=self.measure)
        self.btn_geo.grid(row=0, column=0, sticky="w")
        ttk.Label(sf, text="Km nhập tay").grid(row=0, column=1, sticky="e", padx=(14, 4))
        ttk.Entry(sf, textvariable=self.km_manual, width=7).grid(row=0, column=2, sticky="w")
        ttk.Label(sf, text="Vùng").grid(row=0, column=3, sticky="e", padx=(14, 4))
        self.cb_zone = ttk.Combobox(sf, textvariable=self.zone_sel, width=26, state="readonly")
        self.cb_zone.grid(row=0, column=4, sticky="w")
        ttk.Label(sf, text="Lalamove tay (đ)").grid(row=0, column=5, sticky="e", padx=(14, 4))
        ttk.Entry(sf, textvariable=self.lala, width=11).grid(row=0, column=6, sticky="w")
        ttk.Label(sf, text="Phí vận chuyển nhập tay (đ)", font=(FONT, 9, "bold")).grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(sf, textvariable=self.ship_manual, width=14).grid(row=1, column=1, columnspan=2, sticky="w", padx=(14, 0), pady=(6, 0))
        ttk.Label(sf, text="Để trống = tự tính theo vùng  ·  nhập 0 = miễn phí ship  ·  có số = dùng đúng số này", foreground=MUTED).grid(row=1, column=3, columnspan=4, sticky="w", padx=(10, 0), pady=(6, 0))
        self.geo_lbl = ttk.Label(sf, text="Chưa tính khoảng cách  ·  Ngoại tỉnh: phí Lalamove = km × 12.000đ (để trống ô Lalamove tay)", justify="left", foreground=MUTED, wraplength=800)
        self.geo_lbl.grid(row=2, column=0, columnspan=7, sticky="w", pady=(6, 0))
        sf.bind("<Configure>", lambda e: self.geo_lbl.config(wraplength=max(200, e.width - 30)))

        self.loose_box.pack(fill="both", expand=True)
        self._build_wood()
        bar = ttk.Frame(self.loose_box)
        bar.pack(fill="x")
        ttk.Button(bar, text="➕ Thêm sản phẩm", style="Accent.TButton", command=self.pick).pack(side="left")
        ttk.Button(bar, text="➕ SP ngoài danh mục…", command=lambda: self.add_manual(False)).pack(side="left", padx=4)
        ttk.Button(bar, text="➕ Phụ phí / phát sinh…", command=lambda: self.add_manual(True)).pack(side="left")
        ttk.Button(bar, text="✎ Sửa SL", command=self.edit_qty).pack(side="left", padx=4)
        ttk.Button(bar, text="🗑 Xóa dòng", command=self.remove).pack(side="left")
        ttk.Button(bar, text="🔗 Gộp combo…", command=self.set_combo).pack(side="left", padx=4)
        ttk.Button(bar, text="🧱 Kèm/bỏ ván chống ẩm", command=self.toggle_moist).pack(side="left")
        ttk.Label(self.loose_box, text="💡 Nhấp đúp vào bất kỳ ô nào (tên, kích thước, SL, đơn giá, thành tiền, loại ship, combo) để sửa tay.", foreground=MUTED).pack(fill="x", pady=(6, 0))
        cols = [("stt", "STT"), ("name", "Sản phẩm"), ("size", "Kích thước"), ("qty", "SL"), ("price", "Đơn giá"), ("amt", "Thành tiền"), ("cls", "Loại ship"), ("combo", "Combo")]
        fr, self.tree = make_tree(self.loose_box, cols, (36, 290, 140, 40, 100, 104, 92, 56), height=5, hscroll=True)
        fr.pack(fill="both", expand=True, pady=(8, 0))
        self.tree.bind("<Double-1>", self.on_tree_dbl)

        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        of = self.of = ttk.LabelFrame(right, text="Tùy chọn đơn hàng", padding=(10, 4, 10, 8))
        of.grid(row=0, column=0, sticky="ew")
        self.tier, self.promo_pct, self.promo_amt = tk.StringVar(value="Tự động theo số lượng"), tk.StringVar(value="0"), tk.StringVar(value="0")
        self.asm, self.moist = tk.BooleanVar(), tk.BooleanVar()
        ttk.Label(of, text="Mức giá").grid(row=0, column=0, sticky="w")
        self.cb_tier = ttk.Combobox(of, textvariable=self.tier, width=30, state="readonly")
        self.cb_tier.grid(row=0, column=1, columnspan=3, padx=(6, 0), sticky="ew")
        ttk.Label(of, text="KM thêm (%)").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(of, textvariable=self.promo_pct, width=7).grid(row=1, column=1, padx=(6, 12), pady=(6, 0), sticky="w")
        ttk.Label(of, text="Giảm thêm (đ)").grid(row=1, column=2, sticky="w", pady=(6, 0))
        ttk.Entry(of, textvariable=self.promo_amt, width=12).grid(row=1, column=3, padx=(6, 0), pady=(6, 0), sticky="ew")
        ttk.Checkbutton(of, text="Tính phí lắp ráp", variable=self.asm).grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Checkbutton(of, text="Ván chống ẩm", variable=self.moist).grid(row=2, column=2, columnspan=2, sticky="w", pady=(6, 0))
        of.columnconfigure(3, weight=1)

        sm = self.sm = ttk.LabelFrame(right, text="Tổng kết", padding=(8, 4, 8, 8))
        sm.grid(row=1, column=0, sticky="nsew", pady=8)
        self.sum = tk.Text(sm, width=44, height=12, bg="white", relief="flat", font=(FONT, 10), state="disabled",
                           wrap="word", tabs=("300", "right"), padx=8, pady=6, highlightthickness=0, spacing1=2)
        self.sum.pack(fill="both", expand=True)
        self.sum.bind("<Double-1>", self.on_sum_dbl)
        self.sum.tag_configure("b", font=(FONT, 10, "bold"), foreground=BRAND)
        self.sum.tag_configure("n", foreground=MUTED)
        bb = ttk.Frame(right)
        bb.grid(row=2, column=0, sticky="ew")
        ttk.Button(bb, text="💾 Lưu đơn", style="Accent.TButton", command=self.save).pack(side="left")
        ttk.Button(bb, text="📤 Xuất biên lai", command=self.export_now).pack(side="left", padx=6)
        ttk.Button(bb, text="🆕 Đơn mới", command=self.new).pack(side="left")
        ff = ttk.LabelFrame(right, text="Nơi lưu biên lai", padding=(10, 4, 10, 8))
        ff.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        self.dir_lbl = ttk.Label(ff, text="", justify="left", wraplength=340, foreground=MUTED)
        self.dir_lbl.pack(anchor="w", fill="x")
        ff.bind("<Configure>", lambda e: self.dir_lbl.config(wraplength=max(160, e.width - 30)))
        br = ttk.Frame(ff)
        br.pack(anchor="w", pady=(6, 0))
        ttk.Button(br, text="📁 Chọn nơi lưu…", command=self.choose_dir).pack(side="left")
        ttk.Button(br, text="Mở thư mục", command=self.open_dir).pack(side="left", padx=6)
        self.refresh_dir_label()
        for v in (self.tier, self.promo_pct, self.promo_amt, self.asm, self.moist, self.zone_sel, self.lala, self.km_manual, self.advance, self.wood_kind,
                  self.ship_manual, self.asm_ov, self.moist_ov):
            v.trace_add("write", lambda *a: self.recalc())
        self.reload_options()
        self.code.set(receipts.next_code(app.orders))

    def refresh_dir_label(self):
        self.dir_lbl.config(text=orderimage.orders_root(self.app.settings))

    def choose_dir(self):
        d = filedialog.askdirectory(initialdir=orderimage.base_dir(self.app.settings), mustexist=True,
                                    title="Chọn nơi lưu (phần mềm sẽ tạo thư mục DON HANG bên trong)")
        if not d:
            return
        d = os.path.normpath(d)
        if not orderimage._writable(os.path.join(d, "DON HANG")):
            messagebox.showwarning("Không ghi được", f"Không tạo/ghi được thư mục trong:\n{d}\nHãy chọn vị trí khác (ví dụ ổ D: hoặc Desktop).")
            return
        self.app.settings["orders_dir"] = d
        self.app.save_settings()

    def open_dir(self):
        try:
            folder = orderimage.month_folder(self.app.settings, orderimage.now_gmt7())
            self.app.open_path(os.path.dirname(folder))
        except OSError as e:
            messagebox.showwarning("Không mở được", str(e))

    def reload_options(self):
        S = self.app.settings
        self.cb_tier["values"] = ["Tự động theo số lượng"] + [t["label"] for t in S["tiers"]]
        self.cb_zone["values"] = ["Tự động"] + [z["name"] for z in S["zones"]]
        self.recalc()

    # --- chuyển chế độ
    def switch(self):
        wood = self.otype.get() == "wood"
        if wood:
            self.loose_box.pack_forget()
            self.wood_box.pack(fill="both", expand=True)
            self.wk_frame.pack(side="left")
            self.of.grid_remove()
        else:
            self.wood_box.pack_forget()
            self.loose_box.pack(fill="both", expand=True)
            self.wk_frame.pack_forget()
            self.of.grid()
        self.inst_visibility()
        self.recalc()

    # --- hàng gỗ
    def _build_wood(self):
        wb = self.wood_box
        wf = ttk.LabelFrame(wb, text="Nhập dòng hàng gỗ – kích thước & đơn giá nhập tay", padding=(10, 4, 10, 8))
        wf.pack(fill="x", pady=(0, 8))
        self.wv = {k: tk.StringVar() for k in ("cat", "desc", "dai", "cao", "sau", "price")}
        self.w_unit, self.w_qty = tk.StringVar(value="m2"), tk.StringVar(value="1")
        ttk.Label(wf, text="Hạng mục:").grid(row=0, column=0, sticky="w")
        ttk.Entry(wf, textvariable=self.wv["cat"], font=(FONT, 11)).grid(row=0, column=1, columnspan=3, padx=6, pady=2, sticky="ew", ipady=2)
        ttk.Button(wf, text="📋 Chọn từ bảng giá gỗ…", command=self.pick_wood).grid(row=0, column=4, padx=4)
        ttk.Label(wf, text="Diễn giải:").grid(row=1, column=0, sticky="nw", pady=(4, 0))
        self.w_desc = tk.Text(wf, height=3, wrap="word", font=(FONT, 11), undo=True, padx=4, pady=2)
        self.w_desc.grid(row=1, column=1, columnspan=3, padx=6, pady=(4, 2), sticky="ew")
        self.wv["desc"] = TextVar(self.w_desc)
        ttk.Button(wf, text="⛶ Mở rộng ô", command=self.w_desc_big).grid(row=1, column=4, padx=4, sticky="n", pady=(4, 0))
        wf.columnconfigure(3, weight=1)
        rw = ttk.Frame(wf)
        rw.grid(row=2, column=0, columnspan=5, sticky="w", pady=(6, 2))
        for i, (lab, k, w) in enumerate((("Dài (mm):", "dai", 9), ("Cao (mm):", "cao", 9), ("Sâu (mm):", "sau", 9))):
            ttk.Label(rw, text=lab).grid(row=0, column=i * 2, sticky="e", padx=(0 if i == 0 else 10, 2))
            ttk.Entry(rw, textvariable=self.wv[k], width=7).grid(row=0, column=i * 2 + 1)
        ttk.Label(rw, text="ĐVT:").grid(row=0, column=6, sticky="e", padx=(10, 2))
        ttk.Combobox(rw, textvariable=self.w_unit, values=["m2", "md", "bộ", "cái", "gói", "chuyến"], width=8, state="readonly").grid(row=0, column=7)
        ttk.Label(rw, text="SL:").grid(row=0, column=8, sticky="e", padx=(10, 2))
        ttk.Entry(rw, textvariable=self.w_qty, width=6).grid(row=0, column=9)
        ttk.Label(rw, text="Đơn giá (đ):").grid(row=0, column=10, sticky="e", padx=(10, 2))
        ttk.Entry(rw, textvariable=self.wv["price"], width=14).grid(row=0, column=11)
        self.w_moist = tk.BooleanVar()
        self.w_moist_fee = tk.StringVar(value=money(self.app.settings.get("moist_fee", 300000)))
        mf = ttk.Frame(wf)
        mf.grid(row=4, column=0, columnspan=5, sticky="w", pady=(4, 0))
        ttk.Checkbutton(mf, text="Kèm ván chống ẩm", variable=self.w_moist).pack(side="left")
        ttk.Label(mf, text="   cộng thêm").pack(side="left")
        ttk.Entry(mf, textvariable=self.w_moist_fee, width=10).pack(side="left", padx=4)
        ttk.Label(mf, text="đ / sản phẩm (sửa tay được) – hiện thành 1 dòng riêng dưới sản phẩm", foreground=MUTED).pack(side="left")
        self.w_calc = ttk.Label(wf, text="", foreground=BRAND, font=(FONT, 10, "bold"))
        self.w_calc.grid(row=3, column=0, columnspan=3, sticky="w", pady=(4, 0))
        bt = ttk.Frame(wf)
        bt.grid(row=3, column=3, columnspan=2, sticky="e", pady=(4, 0))
        ttk.Button(bt, text="➕ Thêm dòng", style="Accent.TButton", command=self.w_add).pack(side="left")
        ttk.Button(bt, text="💾 Cập nhật dòng chọn", command=self.w_update).pack(side="left", padx=4)
        ttk.Button(bt, text="🗑 Xóa dòng", command=self.w_remove).pack(side="left")
        ttk.Button(bt, text="Làm mới", command=self.w_clear).pack(side="left", padx=4)
        ttk.Button(bt, text="🚚 Phí vận chuyển / phụ phí", command=self.w_fee).pack(side="left")
        cols = [("stt", "STT"), ("cat", "Hạng mục"), ("desc", "Diễn giải"), ("dai", "Dài"), ("cao", "Cao"), ("sau", "Sâu"), ("unit", "ĐVT"),
                ("kl", "Khối lượng"), ("qty", "SL"), ("price", "Đơn giá"), ("amt", "Thành tiền")]
        fr, self.wtree = make_tree(wb, cols, (34, 160, 200, 50, 50, 50, 44, 66, 34, 86, 96), height=5, hscroll=True)
        fr.pack(fill="both", expand=True)
        self.wtree.bind("<<TreeviewSelect>>", self.w_select)
        self.wtree.bind("<Double-1>", self.w_dbl)
        ttk.Label(wb, text="💡 Nhấp đúp vào bất kỳ ô nào (hạng mục, diễn giải, kích thước, ĐVT, SL, đơn giá, thành tiền) để sửa tay.", foreground=MUTED).pack(fill="x", before=fr)
        for v in (*self.wv.values(), self.w_unit, self.w_qty):
            v.trace_add("write", lambda *a: self.w_preview())

    def w_read(self):
        g = lambda k: self.wv[k].get().strip()
        if not (g("cat") or g("desc")):
            messagebox.showwarning("Thiếu thông tin", "Nhập hạng mục hoặc diễn giải.")
            return None
        if parse_money(g("price")) <= 0:
            messagebox.showwarning("Thiếu đơn giá", "Nhập đơn giá (đ) cho dòng này.")
            return None
        qty = parse_float(self.w_qty.get())
        if not qty or qty <= 0:
            messagebox.showwarning("Số lượng", "Số lượng phải lớn hơn 0.")
            return None
        u = self.w_unit.get()
        if receipts.line_issue({"unit": u, "dai": g("dai"), "cao": g("cao")}):
            messagebox.showwarning("Thiếu kích thước", "ĐVT m2 cần nhập Dài và Cao (mm); ĐVT md cần nhập Dài (mm).\n"
                                   "Nếu không có kích thước, hãy đổi ĐVT sang 'bộ', 'cái' hoặc 'gói'.")
            return None
        return {"cat": g("cat"), "desc": g("desc"), "dai": g("dai"), "cao": g("cao"), "sau": g("sau"),
                "unit": self.w_unit.get(), "qty": qty, "price": parse_money(g("price"))}

    def w_preview(self):
        if not hasattr(self, "w_calc"):
            return
        kl, amt = receipts.calc_line(self.w_unit.get(), self.wv["dai"].get(), self.wv["cao"].get(), parse_float(self.w_qty.get()) or 0, parse_money(self.wv["price"].get()))
        self.w_calc.config(text=f"Khối lượng: {kl:.2f}    |    Thành tiền: {money(amt)} đ")

    def w_index(self):
        s = self.wtree.selection()
        return self.wtree.index(s[0]) if s else None

    # --- ván chống ẩm kèm theo từng dòng hàng gỗ: 1 dòng phụ thu đi liền dưới dòng gốc (giá sửa tay được như mọi dòng)
    def w_moist_child(self, lid):
        return next((x for x in self.wood_lines if lid and x.get("moist_of") == lid), None)

    def w_set_moist(self, line, fee):
        """fee = số tiền/sản phẩm -> bật hoặc cập nhật; None -> bỏ."""
        if not line.get("id"):
            line["id"] = uuid.uuid4().hex[:8]
        ch = self.w_moist_child(line["id"])
        if fee is None:
            if ch:
                self.wood_lines.remove(ch)
            return
        if ch:
            ch["price"] = float(fee)
            return
        name = line.get("cat") or line.get("desc") or ""
        self.wood_lines.insert(self.wood_lines.index(line) + 1,
                               {"cat": "Ván chống ẩm", "desc": ("Kèm " + name).strip(), "dai": "", "cao": "", "sau": "", "unit": "cái",
                                "qty": line.get("qty", 1), "price": float(fee), "moist_of": line["id"]})

    def w_sync_moist(self):
        ids = {x["id"]: x for x in self.wood_lines if x.get("id") and not x.get("moist_of")}
        self.wood_lines[:] = [x for x in self.wood_lines if not x.get("moist_of") or x["moist_of"] in ids]
        for x in self.wood_lines:
            if x.get("moist_of"):
                x["qty"] = ids[x["moist_of"]].get("qty", 1)

    def w_desc_big(self):
        v = ask_text(self.app, "Diễn giải", "Diễn giải (Enter = xuống dòng, hiện đúng như vậy trên biên lai):", self.wv["desc"].get(), multiline=True)
        if v is not None:
            self.wv["desc"].set(v)

    def w_fee_val(self):
        return parse_money(self.w_moist_fee.get()) if self.w_moist.get() else None

    def w_add(self):
        d = self.w_read()
        if d:
            self.wood_lines.append(d)
            if self.w_fee_val() is not None:
                self.w_set_moist(d, self.w_fee_val())
            self.w_clear()
            self.recalc()

    def w_update(self):
        i = self.w_index()
        if i is None:
            messagebox.showinfo("Cập nhật", "Chọn một dòng trong bảng bên dưới để cập nhật.")
            return
        d = self.w_read()
        if d:
            old = self.wood_lines[i]
            for k in ("id", "moist_of"):
                if old.get(k):
                    d[k] = old[k]
            self.wood_lines[i] = d
            if not d.get("moist_of"):
                self.w_set_moist(d, self.w_fee_val())
            self.recalc()

    def w_remove(self):
        i = self.w_index()
        if i is not None:
            del self.wood_lines[i]
            self.w_clear()
            self.recalc()

    def w_fee(self):
        """Điền sẵn dòng phí vận chuyển / phụ phí: chỉ cần nhập đơn giá rồi bấm 'Thêm dòng'."""
        self.w_clear()
        self.wv["cat"].set("Phí vận chuyển")
        self.w_unit.set("chuyến")
        self.w_qty.set("1")

    def w_dbl(self, e):
        if self.wtree.identify_region(e.x, e.y) != "cell":
            return
        iid = self.wtree.identify_row(e.y)
        if not iid:
            return
        self.wtree.selection_set(iid)
        i = self.w_index()
        if i is None or i >= len(self.wood_lines):
            return
        key = self.wtree["columns"][int(self.wtree.identify_column(e.x)[1:]) - 1]
        l = self.wood_lines[i]
        if key in ("cat", "desc", "dai", "cao", "sau"):
            names = {"cat": "Hạng mục", "desc": "Diễn giải", "dai": "Dài (mm)", "cao": "Cao (mm)", "sau": "Sâu (mm)"}
            v = ask_text(self.app, names[key], names[key] + (" (Enter = xuống dòng):" if key == "desc" else ":"), str(l.get(key, "")),
                         multiline=key in ("cat", "desc"), collapse=key == "cat")
            if v is None:
                return
            l[key] = v.strip()
        elif key == "unit":
            units = ["m2", "md", "bộ", "cái", "gói", "chuyến"]
            cur = l.get("unit", "m2")
            d = ChoiceDialog(self.app, "Đơn vị tính", "Chọn đơn vị tính:", units, units.index(cur) if cur in units else 0)
            if d.result is None:
                return
            l["unit"] = units[d.result]
        elif key == "qty":
            v = ask_text(self.app, "Số lượng", "Nhập số lượng:", f"{l.get('qty', 1):g}")
            q = parse_float(v) if v is not None else None
            if not q or q <= 0:
                return
            l["qty"] = q
        elif key == "price":
            v = ask_text(self.app, "Đơn giá", "Nhập đơn giá (đ):", money(l.get("price", 0)))
            if v is None or not v.strip():
                return
            l["price"] = parse_money(v)
        elif key == "amt":
            kl, _ = receipts.calc_line(l.get("unit"), l.get("dai"), l.get("cao"), l.get("qty", 1), 1)
            _, amt = receipts.calc_line(l.get("unit"), l.get("dai"), l.get("cao"), l.get("qty", 1), l.get("price", 0))
            v = ask_text(self.app, "Thành tiền", "Nhập thành tiền (đ) của cả dòng – đơn giá sẽ tự tính lại:", money(amt))
            if v is None or not v.strip():
                return
            _, unit_amt = receipts.calc_line(l.get("unit"), l.get("dai"), l.get("cao"), l.get("qty", 1), 1)
            if unit_amt <= 0:
                messagebox.showwarning("Thiếu kích thước", "Dòng này chưa có kích thước (m2/md) nên không tính được đơn giá từ thành tiền.\nHãy nhập Dài/Cao hoặc nhập thẳng Đơn giá.", parent=self)
                return
            l["price"] = parse_money(v) / unit_amt
        else:
            return
        self.recalc()
        kids = self.wtree.get_children()
        if i < len(kids):
            self.wtree.selection_set(kids[i])

    def w_clear(self):
        for v in self.wv.values():
            v.set("")
        self.w_unit.set("m2")
        self.w_qty.set("1")
        self.w_moist.set(False)
        self.w_moist_fee.set(money(self.app.settings.get("moist_fee", 300000)))

    def w_select(self, _=None):
        i = self.w_index()
        if i is None or i >= len(self.wood_lines):
            return
        l = self.wood_lines[i]
        for k in self.wv:
            self.wv[k].set(money(l[k]) if k == "price" else str(l.get(k, "")))
        self.w_unit.set(l.get("unit", "m2"))
        self.w_qty.set(f"{l.get('qty', 1):g}")
        ch = self.w_moist_child(l.get("id"))
        self.w_moist.set(bool(ch))
        self.w_moist_fee.set(money(ch["price"]) if ch else money(self.app.settings.get("moist_fee", 300000)))

    # --- đọc đơn từ ảnh / file / văn bản
    def smart_import(self):
        d = SmartImportDialog(self.app)
        if d.result:
            self.apply_smart(d.result[1], export=(d.result[0] == "export"))

    def apply_smart(self, plan, export=False):
        if (self.items or self.wood_lines) and not messagebox.askyesno("Thay đơn đang soạn?", "Đơn đang soạn dở sẽ được thay bằng đơn vừa đọc.\nTiếp tục?"):
            return
        self.new()
        c = plan["customer"]
        self.name.set(c["name"]); self.phone.set(c["phone"]); self.addr.set(c["address"])
        missing = 0
        if plan["otype"] == "loose":
            for r in plan["rows"]:
                price, src = smart_row_price(r)
                if r["match"] and r["status"] in ("ok", "near"):
                    pid = r["match"]["id"]
                    self.add_product(pid, r["qty"])
                    if src == "file":
                        next(it for it in self.items if it["pid"] == pid)["price_ov"] = float(price)
                else:
                    if not price:
                        missing += 1
                    dims = " x ".join(f"{v:g}" for v in (r["dai"], r["cao"], r["sau"]) if v)
                    self.items.append({"pid": "m_" + uuid.uuid4().hex[:8], "manual": True, "fee": False, "qty": r["qty"], "name_ov": r["name"],
                                       "size_ov": dims, "unit_ov": r["unit"] or "Cái", "price_ov": float(price or 0), "class_ov": ""})
        else:
            self.otype.set("wood")
            self.wood_kind.set(WOOD_KINDS[plan["kind"]])
            self.switch()
            for r in plan["rows"]:
                m = r["match"] if r["status"] in ("ok", "near") else None
                dai, cao, sau = (f"{v:g}" if v else "" for v in (r["dai"], r["cao"], r["sau"]))
                unit = (r["unit"] or (wood_unit(m.get("unit")) if m else ("m2" if r["dai"] and r["cao"] else "md" if r["dai"] else "cái"))).lower()
                kl = receipts.calc_line(unit, dai, cao, 1, 1)[0]
                price, src = smart_row_price(r)
                if r["amount"] and not r["price"] and kl:
                    price = r["amount"] / (kl * r["qty"]) if unit in ("m2", "md") else r["amount"] / r["qty"]
                if not price:
                    missing += 1
                desc = " – ".join(x for x in (r["label"] if m else "", r["note"]) if x)
                self.wood_lines.append({"cat": m["name"] if m else r["name"], "desc": desc, "dai": dai, "cao": cao, "sau": sau, "unit": unit,
                                        "qty": r["qty"], "price": float(price or 0)})
        self.recalc()
        total = self.inst_total() if plan["otype"] == "wood" else (self.last or {}).get("grand", 0)
        adv = plan["advance"] or (round(total * plan["advance_pct"] / 100) if plan.get("advance_pct") and total else None)
        if adv:
            self.advance.set(money(adv))
            self.recalc()
        self.app.show_tab(self)
        n = len(plan["rows"])
        near = sum(1 for r in plan["rows"] if r["status"] == "near")
        self.app.status(f"Đã tạo đơn từ file: {n} dòng" + (f" · {missing} dòng thiếu giá – nhập thêm" if missing else "") + ". Kiểm tra rồi xuất biên lai.")
        if missing or near:
            messagebox.showinfo("Cần kiểm tra trước khi xuất", "\n".join(x for x in (
                f"• {missing} dòng không có giá (không thấy trong bảng giá): nhấp đúp ô Đơn giá của dòng đó để nhập." if missing else "",
                f"• {near} dòng chỉ khớp gần giống bảng giá: kiểm tra tên sản phẩm và giá." if near else "") if x))
        if export:
            self.export_now()

    def pick_wood(self):
        key = "roi" if self.wood_kind.get() == "Hàng rời" else "congtrinh"
        d = WoodPicker(self.app, key)
        if d.result:
            it, price, label = d.result
            self.prefill_wood(it, price, label)

    def prefill_wood(self, item, price, label, kind_label=None):
        self.otype.set("wood")
        if kind_label:
            self.wood_kind.set(kind_label)
        self.switch()
        self.w_clear()
        self.wv["cat"].set(item["name"])
        self.wv["desc"].set(label)
        self.w_unit.set(wood_unit(item.get("unit")))
        self.wv["price"].set(money(price) if price else "")

    # --- các đợt ứng / thanh toán (hàng công trình)
    def open_inst(self):
        """Cửa sổ riêng để thêm / sửa các đợt ứng (không chiếm chỗ màn hình lên đơn)."""
        if self.inst_win is not None and self.inst_win.winfo_exists():
            self.inst_win.lift()
            self.inst_win.focus_set()
            return
        w = self.inst_win = tk.Toplevel(self.app)
        w.title("Các đợt ứng / thanh toán")
        w.transient(self.app)
        f = ttk.Frame(w, padding=12)
        f.pack(fill="both", expand=True)
        cols = [("stt", "Đợt"), ("label", "Nội dung in trên biên lai"), ("pct", "%"), ("amt", "Số tiền"), ("paid", "Đã TT")]
        fr, self.itree = make_tree(f, cols, (60, 380, 60, 120, 60), height=6)
        fr.pack(fill="both", expand=True)
        self.itree.bind("<<TreeviewSelect>>", self.inst_select)
        r1 = ttk.Frame(f)
        r1.pack(fill="x", pady=(8, 0))
        ttk.Label(r1, text="Lý do ứng:").pack(side="left")
        ttk.Combobox(r1, textvariable=self.iv_reason, values=receipts.ADVANCE_PRESETS, width=34).pack(side="left", padx=(4, 10))
        ttk.Label(r1, text="% ứng:").pack(side="left")
        ttk.Entry(r1, textvariable=self.iv_pct, width=6).pack(side="left", padx=(4, 10))
        ttk.Label(r1, text="hoặc số tiền (đ):").pack(side="left")
        ttk.Entry(r1, textvariable=self.iv_amt, width=13).pack(side="left", padx=(4, 10))
        ttk.Checkbutton(r1, text="Đã thanh toán", variable=self.iv_paid).pack(side="left")
        r2 = ttk.Frame(f)
        r2.pack(fill="x", pady=(8, 0))
        ttk.Button(r2, text="➕ Thêm đợt ứng", style="Accent.TButton", command=self.inst_add).pack(side="left")
        ttk.Button(r2, text="💾 Cập nhật đợt chọn", command=self.inst_update).pack(side="left", padx=4)
        ttk.Button(r2, text="🗑 Xóa đợt", command=self.inst_remove).pack(side="left")
        ttk.Button(r2, text="↻ Mẫu 40% + 40% + còn lại", command=self.inst_template).pack(side="left", padx=4)
        r3 = ttk.Frame(f)
        r3.pack(fill="x", pady=(8, 0))
        ttk.Label(r3, text="Dòng cuối (phần còn lại) – nội dung sau “THANH TOÁN y%”:").pack(side="left")
        ttk.Entry(r3, textvariable=self.final_reason).pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.inst_lbl = ttk.Label(f, text="", foreground=BRAND, font=(FONT, 10, "bold"), wraplength=720, justify="left")
        self.inst_lbl.pack(fill="x", pady=(8, 0))
        ttk.Label(f, text="💡 Nhập % (VD 40 hoặc 33,5) hoặc số tiền – nhập cả hai thì lấy %. Dòng cuối tự tính = Tổng tiền − các đợt ứng. "
                          "Chưa có đợt nào thì biên lai dùng ô “Tạm ứng (đ)” (trống = 50%).",
                  foreground=MUTED, wraplength=720, justify="left").pack(fill="x", pady=(2, 8))
        ttk.Button(f, text="Xong", style="Accent.TButton", command=w.destroy).pack(anchor="e")
        w.protocol("WM_DELETE_WINDOW", w.destroy)
        w.bind("<Destroy>", lambda e: self._inst_closed(e, w))
        self.inst_refresh()
        place(w, self.app)

    def _inst_closed(self, e, w):
        if e.widget is w:
            self.itree, self.inst_lbl, self.inst_win = None, None, None

    def inst_active(self):
        return self.otype.get() == "wood"

    def inst_total(self):
        return sum(receipts.calc_line(l.get("unit"), l.get("dai"), l.get("cao"), l.get("qty", 1), l.get("price", 0))[1] for l in self.wood_lines)

    def inst_rc(self):
        return {"installments": self.inst, "final_reason": self.final_reason.get()}

    def inst_visibility(self):
        if self.inst_active():
            self.inst_bar.grid()
        else:
            self.inst_bar.grid_remove()

    def inst_refresh(self, total=None):
        total = self.inst_total() if total is None else total
        rows = receipts.build_installments(self.inst_rc(), total)
        adv = sum(x["amount"] for x in rows if x["kind"] == "adv")
        if rows:
            self.inst_sum.set(f"{len(rows) - 1} đợt ứng ({receipts.fmt_pct(adv / total * 100 if total else 0)}%) + dòng còn lại {money(rows[-1]['amount'])}đ")
        else:
            self.inst_sum.set("Chưa có đợt ứng – dùng ô Tạm ứng (trống = 50%)")
        if self.itree is None:
            return
        self.itree.delete(*self.itree.get_children())
        for k, x in enumerate(rows):
            pct = receipts.fmt_pct(x["amount"] / total * 100) if total else "0"
            self.itree.insert("", "end", values=("Còn lại" if x["kind"] == "final" else k + 1, x["label"], pct, money(x["amount"]), "✔" if x["paid"] else ""))
        if rows:
            self.inst_lbl.config(text=f"Đã ứng {receipts.fmt_pct(adv / total * 100 if total else 0)}% = {money(adv)} đ   ·   Còn lại: {money(rows[-1]['amount'])} đ")
        else:
            self.inst_lbl.config(text="Chưa có đợt ứng nào – đang dùng Tạm ứng ở phần Thông tin biên lai.")

    def inst_read(self):
        reason = self.iv_reason.get().strip()
        raw_p = self.iv_pct.get().replace("%", "").replace(",", ".").strip()
        pct = parse_float(raw_p) if raw_p else 0.0
        amt = parse_money(self.iv_amt.get())
        if pct is None:
            messagebox.showwarning("% ứng", "% ứng phải là số (VD 40 hoặc 33,5).", parent=self)
            return None
        if pct <= 0 and amt <= 0:
            messagebox.showwarning("Thiếu số liệu", "Nhập % ứng hoặc số tiền của đợt ứng này.", parent=self)
            return None
        if pct > 100:
            messagebox.showwarning("% ứng", "% ứng không được lớn hơn 100.", parent=self)
            return None
        if not reason:
            messagebox.showwarning("Thiếu lý do", "Nhập lý do ứng (chọn mẫu có sẵn hoặc gõ tay).", parent=self)
            return None
        return {"reason": reason, "pct": raw_p if pct > 0 else "", "amt": "" if pct > 0 else str(int(amt)), "paid": bool(self.iv_paid.get())}

    def inst_clear_fields(self):
        self.iv_reason.set(""); self.iv_pct.set(""); self.iv_amt.set(""); self.iv_paid.set(False)

    def inst_add(self):
        d = self.inst_read()
        if d:
            self.inst.append(d)
            self.inst_clear_fields()
            self.recalc()

    def inst_idx(self):
        s = self.itree.selection()
        i = self.itree.index(s[0]) if s else None
        return i if (i is not None and i < len(self.inst)) else None

    def inst_select(self, _=None):
        i = self.inst_idx()
        if i is None:
            return
        x = self.inst[i]
        self.iv_reason.set(x.get("reason", "")); self.iv_pct.set(str(x.get("pct", "") or "")); self.iv_amt.set(str(x.get("amt", "") or ""))
        self.iv_paid.set(bool(x.get("paid")))

    def inst_update(self):
        i = self.inst_idx()
        if i is None:
            messagebox.showinfo("Cập nhật", "Chọn một đợt ứng trong bảng để cập nhật.", parent=self)
            return
        d = self.inst_read()
        if d:
            self.inst[i] = d
            self.recalc()

    def inst_remove(self):
        i = self.inst_idx()
        if i is not None:
            del self.inst[i]
            self.inst_clear_fields()
            self.recalc()

    def inst_template(self):
        if self.inst and not messagebox.askyesno("Mẫu đợt ứng", "Thay toàn bộ các đợt ứng hiện có bằng mẫu 40% + 40% + còn lại?", parent=self):
            return
        self.inst = [{"reason": receipts.ADVANCE_PRESETS[0], "pct": "40", "amt": "", "paid": False},
                     {"reason": receipts.ADVANCE_PRESETS[1], "pct": "40", "amt": "", "paid": False}]
        self.final_reason.set(receipts.FINAL_REASON)
        self.inst_clear_fields()
        self.recalc()

    def recalc_wood(self):
        self.w_sync_moist()
        self.inst_visibility()
        self.wtree.delete(*self.wtree.get_children())
        total, lines, warns = 0.0, [], []
        for i, l in enumerate(self.wood_lines, 1):
            kl, amt = receipts.calc_line(l.get("unit"), l.get("dai"), l.get("cao"), l.get("qty", 1), l.get("price", 0))
            total += amt
            if receipts.line_issue(l):
                warns.append(i)
            lines.append({"name": l.get("cat") or l.get("desc"), "amount": amt})
            self.wtree.insert("", "end", values=(i, l.get("cat", ""), str(l.get("desc", "")).replace("\n", " ⏎ "), l.get("dai", ""), l.get("cao", ""), l.get("sau", ""),
                                                 l.get("unit", ""), f"{kl:.2f}", f"{l.get('qty', 1):g}", money(l.get("price", 0)), money(amt)))
        adv = parse_money(self.advance.get())
        pct50 = adv <= 0
        adv = min(total, round(total / 2) if pct50 else adv)
        self.last = {"lines": lines, "qty": len(lines), "tier_label": "", "list_total": total, "tier_discount": 0, "goods_before_promo": total,
                     "promo": 0, "goods_total": total, "assembly": 0, "moisture": 0, "grand": total,
                     "ship": {"zone": "", "base": 0, "class": "", "mult": 0, "raw": 0, "fee": 0, "notes": []}}
        kind = self.wood_kind.get()
        rows_i = receipts.build_installments(self.inst_rc(), total) if self.inst_active() else []
        L = [(f"Loại hàng: {kind}", "n"), (f"Số hạng mục: {len(lines)}", "n"), ("", ""),
             (f"TỔNG TIỀN\t{money(total)}", "b")]
        if rows_i:
            for x in rows_i:
                L += [(x["label"] + ("  ✔ đã thanh toán" if x["paid"] else ""), "n"), (f"\t{money(x['amount'])}", "b" if x["kind"] == "final" else "")]
            L.append(("(Đang dùng bảng các đợt ứng; ô “Tạm ứng (đ)” phía trên được bỏ qua.)", "n"))
        else:
            L += [(f"{'TẠM ỨNG 50%' if pct50 else 'TẠM ỨNG'}\t{money(adv)}", ""),
                  (f"THANH TOÁN CÒN LẠI\t{money(total - adv)}", "b")]
        L.append(("", ""))
        if warns:
            L.insert(2, ("⚠ Dòng " + ", ".join(map(str, warns)) + " thiếu kích thước → thành tiền = 0. Chọn dòng và nhập Dài/Cao rồi bấm 'Cập nhật'.", "b"))
        for fl in self.app.wood["roi"if kind == "Hàng rời" else "congtrinh"].get("footer", []):
            L.append(("• " + fl.lstrip("+ ").strip(), "n"))
        self.sum.config(state="normal")
        self.sum.delete("1.0", "end")
        for t, tag in L:
            self.sum.insert("end", t + "\n", tag)
        self.sum.config(state="disabled")
        self.inst_refresh(total)

    # --- items
    def add_product(self, pid, qty=1, moist_fee=None):
        for it in self.items:
            if it["pid"] == pid:
                it["qty"] += qty
                break
        else:
            self.items.append({"pid": pid, "qty": qty})
        if moist_fee is not None:
            self.set_moist(pid, moist_fee)
        self.recalc()

    # --- ván chống ẩm kèm theo từng sản phẩm: là 1 dòng phụ thu đi liền dưới sản phẩm (giá sửa tay được như mọi dòng)
    def item_name(self, it):
        if it.get("manual"):
            return it.get("name_ov") or "(chưa đặt tên)"
        return it.get("name_ov") or self.app.pmap.get(it["pid"], {}).get("name", "")

    def moist_child(self, pid):
        return next((x for x in self.items if x.get("moist_of") == pid), None)

    def set_moist(self, pid, fee):
        """fee = số tiền /sản phẩm -> bật (hoặc cập nhật giá); fee = None -> bỏ."""
        i = next((n for n, x in enumerate(self.items) if x["pid"] == pid), None)
        if i is None:
            return
        ch = self.moist_child(pid)
        if fee is None:
            if ch:
                self.items.remove(ch)
            return
        if ch:
            ch["price_ov"] = float(fee)
        else:
            self.items.insert(i + 1, {"pid": "m_" + uuid.uuid4().hex[:8], "manual": True, "fee": True, "moist_of": pid, "qty": self.items[i]["qty"],
                                      "name_ov": "Ván chống ẩm – " + self.item_name(self.items[i]), "size_ov": "", "unit_ov": "Cái",
                                      "price_ov": float(fee), "class_ov": ""})

    def sync_moist(self):
        """Dòng ván chống ẩm luôn theo số lượng sản phẩm gốc; sản phẩm gốc bị xóa thì dòng này cũng bỏ."""
        ids = {x["pid"]: x for x in self.items if not x.get("moist_of")}
        self.items[:] = [x for x in self.items if not x.get("moist_of") or x["moist_of"] in ids]
        for x in self.items:
            if x.get("moist_of"):
                x["qty"] = ids[x["moist_of"]]["qty"]

    def toggle_moist(self):
        i = self.sel_index()
        if i is None:
            messagebox.showinfo("Ván chống ẩm", "Chọn một dòng sản phẩm trong bảng trước.")
            return
        it = self.items[i]
        if it.get("moist_of"):
            self.items.remove(it)
        elif it.get("fee"):
            messagebox.showinfo("Ván chống ẩm", "Phụ phí / phát sinh không có ván chống ẩm kèm theo.")
            return
        elif self.moist_child(it["pid"]):
            self.set_moist(it["pid"], None)
        else:
            self.set_moist(it["pid"], self.app.settings.get("moist_fee", 300000))
        self.recalc()

    def pick(self):
        d = Picker(self.app)
        if d.result:
            self.add_product(*d.result)

    def sel_index(self):
        s = self.tree.selection()
        if not s:
            return None
        for n, it in enumerate(self.items):
            if it["pid"] == s[0]:
                return n
        return None

    def edit_qty(self):
        i = self.sel_index()
        if i is None:
            return
        if self.items[i].get("moist_of"):
            messagebox.showinfo("Số lượng", "Số lượng ván chống ẩm tự theo số lượng sản phẩm phía trên.\nMuốn đổi số tiền: nhấp đúp vào ô Đơn giá / Thành tiền.", parent=self)
            return
        n = simpledialog.askinteger("Số lượng", "Nhập số lượng (0 = xóa):", initialvalue=self.items[i]["qty"], minvalue=0, maxvalue=9999, parent=self)
        if n is not None:
            if n == 0:
                del self.items[i]
            else:
                self.items[i]["qty"] = n
            self.recalc()

    def eng_items(self):
        """Chuyển danh sách dòng trên đơn sang dạng engine tính (gồm dòng thêm tay & giá/tên/kích thước sửa tay)."""
        out = []
        for i in self.items:
            pid = i["pid"]
            if i.get("manual"):
                p = {"id": pid, "name": i.get("name_ov") or "(chưa đặt tên)", "retail": i.get("price_ov") or 0,
                     "unit": i.get("unit_ov") or "", "manual": True}
            elif pid in self.app.pmap:
                p = self.app.pmap[pid]
            else:
                continue
            d = {"p": p, "qty": i["qty"]}
            if p.get("addon"):        # sản phẩm dạng phụ thu (VD ván chống ẩm): giá cố định, không tính vào mức giá/KM/ship
                d["fee"] = True
            for k in ("price_ov", "name_ov", "size_ov", "class_ov", "unit_ov", "fee"):
                if i.get(k) is not None:
                    d[k] = i[k]
            out.append(d)
        return out

    def add_manual(self, fee=False):
        d = LineDialog(self.app, fee=fee)
        if not d.result:
            return
        r = d.result
        self.items.append({"pid": "m_" + uuid.uuid4().hex[:8], "manual": True, "fee": bool(fee), "qty": r["qty"],
                           "name_ov": r["name"], "size_ov": r["size"], "unit_ov": r["unit"],
                           "price_ov": r["price"], "class_ov": r["class_ov"]})
        if r.get("moist_fee") is not None:
            self.set_moist(self.items[-1]["pid"], r["moist_fee"])
        self.recalc()

    # --- nhấp đúp để sửa từng ô
    def on_tree_dbl(self, e):
        if self.tree.identify_region(e.x, e.y) != "cell":
            return
        iid = self.tree.identify_row(e.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        key = self.tree["columns"][int(self.tree.identify_column(e.x)[1:]) - 1]
        self.edit_cell(key)

    def edit_cell(self, key):
        i = self.sel_index()
        if i is None:
            return
        it = self.items[i]
        line = next((l for l in (self.last or {}).get("lines", []) if l["pid"] == it["pid"]), None)
        if line is None:
            return
        manual = bool(it.get("manual"))
        if key == "qty":
            return self.edit_qty()
        if key == "combo":
            return self.set_combo()
        if key == "name":
            v = ask_text(self.app, "Tên sản phẩm", "Tên hiển thị trên biên lai" + ("" if manual else "\n(xóa trắng = lấy lại tên gốc)") + ":",
                         line["name"], multiline=True, collapse=True)
            if v is None:
                return
            v = v.strip()
            if manual and not v:
                return
            it["name_ov"] = v or None
        elif key == "size":
            v = ask_text(self.app, "Kích thước / ghi chú", "Kích thước hiển thị (xóa trắng = không ghi):", line["size"], multiline=True, collapse=True)
            if v is None:
                return
            it["size_ov"] = v.strip()
        elif key == "price":
            v = ask_text(self.app, "Đơn giá", "Nhập đơn giá (đ)" + ("" if manual else "\n(xóa trắng = lấy lại giá theo bảng giá/mức giá)") + ":",
                         money(line["unit_price"]))
            if v is None:
                return
            if not v.strip():
                if manual:
                    return
                it["price_ov"] = None
            else:
                it["price_ov"] = parse_money(v)
        elif key == "amt":
            v = ask_text(self.app, "Thành tiền", "Nhập thành tiền (đ) của cả dòng.\nĐơn giá sẽ tự tính = thành tiền ÷ số lượng:", money(line["amount"]))
            if v is None or not v.strip():
                return
            it["price_ov"] = parse_money(v) / (it["qty"] or 1)
        elif key == "cls":
            if line.get("fee"):
                messagebox.showinfo("Loại ship", "Phụ phí không tính vào phí ship.", parent=self)
                return
            S = self.app.settings
            opts = ([] if manual else ["Tự động (theo sản phẩm)"]) + ["Không tính vào phí ship"] + [c["name"] for c in S["ship_classes"]]
            keys = ([None] if not manual else []) + [""] + [c["key"] for c in S["ship_classes"]]
            cur = it.get("class_ov")
            init = keys.index(cur) if cur in keys else 0
            d = ChoiceDialog(self.app, "Loại ship", "Chọn loại ship cho dòng này:", opts, init)
            if d.result is None:
                return
            it["class_ov"] = keys[d.result]
        else:
            return
        self.recalc()

    def on_sum_dbl(self, e):
        if self.otype.get() == "wood" or not self.last:
            return
        ln = self.sum.index(f"@{e.x},{e.y}").split(".")[0]
        txt = self.sum.get(f"{ln}.0", f"{ln}.end").strip()
        r = self.last
        if txt.startswith("PHÍ VẬN CHUYỂN"):
            var, label, auto = self.ship_manual, "phí vận chuyển", r["ship"]["fee"]
        elif txt.startswith("Phí lắp ráp"):
            var, label, auto = self.asm_ov, "phí lắp ráp", r["assembly"]
        elif txt.startswith("Ván chống ẩm"):
            var, label, auto = self.moist_ov, "phí ván chống ẩm", r["moisture"]
        else:
            return
        v = ask_text(self.app, "Nhập tay " + label, f"Nhập {label} (đ).\n0 = miễn phí  ·  xóa trắng = để phần mềm tự tính:", var.get().strip() or money(auto))
        if v is None:
            return
        var.set(money(parse_money(v)) if v.strip() else "")

    def set_combo(self):
        i = self.sel_index()
        if i is None:
            messagebox.showinfo("Combo", "Chọn một dòng sản phẩm trước.")
            return
        v = ask_text(self.app, "Gộp combo", "Số combo cho dòng này (vd 1, 2…).\nCác dòng cùng số sẽ gộp thành 1 dòng COMBO trên biên lai.\nĐể trống = không gộp.",
                     str(self.items[i].get("combo", "")))
        if v is not None:
            self.items[i]["combo"] = v.strip()
            self.recalc()

    def remove(self):
        i = self.sel_index()
        if i is not None:
            del self.items[i]
            self.recalc()

    # --- shipping
    def measure(self):
        a = self.addr.get().strip()
        if len(a) < 5:
            messagebox.showinfo("Địa chỉ", "Nhập địa chỉ khách hàng (số nhà, đường, phường/xã, quận/huyện, tỉnh).")
            return
        self.btn_geo.state(["disabled"])
        self.geo_lbl.config(text="Đang tìm địa chỉ & tính đường đi… (có thể mất vài giây)")

        def done(ok, res):
            self.btn_geo.state(["!disabled"])
            if not ok:
                self.geo = None
                self.geo_lbl.config(text="⚠ " + str(res) + "\n→ Có thể nhập km thủ công ở bên dưới.")
            else:
                self.geo = res
                txt = f"Khoảng cách đường bộ: {res['km']:.1f} km ({res['method']})\nĐịa chỉ tìm thấy: {res['found']}"
                if res["notes"]:
                    txt += "\n⚠ " + " ".join(res["notes"])
                self.geo_lbl.config(text=txt)
            self.recalc()

        run_bg(self, lambda: geo.measure(a, self.app.settings), done)

    def km(self):
        m = parse_float(self.km_manual.get()) if self.km_manual.get().strip() else None
        return m if m is not None else (self.geo["km"] if self.geo else None)

    # --- compute
    def recalc(self):
        if not hasattr(self, "sum"):
            return
        if self.otype.get() == "wood":
            return self.recalc_wood()
        S = self.app.settings
        self.sync_moist()
        items = self.eng_items()
        tl = self.tier.get()
        tk_ = "auto" if tl.startswith("Tự động") else next((t["key"] for t in S["tiers"] if t["label"] == tl), "auto")
        km = self.km()
        if self.zone_sel.get() == "Tự động":
            zone = engine.choose_zone(km, self.addr.get(), S)
        else:
            zone = next((z for z in S["zones"] if z["name"] == self.zone_sel.get()), None)
        r = engine.compute_order(items, S, tk_, parse_float(self.promo_pct.get()) or 0, parse_money(self.promo_amt.get()),
                                 self.asm.get(), self.moist.get(), zone, parse_money(self.lala.get()), km,
                                 ship_override=(parse_money(self.ship_manual.get()) if self.ship_manual.get().strip() else None),
                                 asm_override=(parse_money(self.asm_ov.get()) if self.asm_ov.get().strip() else None),
                                 moist_override=(parse_money(self.moist_ov.get()) if self.moist_ov.get().strip() else None))
        self.last = r
        cn = {c["key"]: c["name"] for c in S["ship_classes"]}
        prev_sel = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        combo_of = {it["pid"]: it.get("combo", "") for it in self.items}
        ovr = {it["pid"]: it for it in self.items}
        seen = set()
        for i, l in enumerate(r["lines"], 1):
            it = ovr.get(l["pid"], {})
            edited = it.get("price_ov") is not None and not it.get("manual")
            cls_txt = "Phụ phí" if l.get("fee") else (cn.get(l["class"], "") or "—")
            iid = l["pid"] if l["pid"] not in seen else ""
            seen.add(l["pid"])
            self.tree.insert("", "end", **({"iid": iid} if iid else {}), values=(i, l["name"], l["size"], f"{l['qty']:g}", money(l["unit_price"]) + (" ✎" if edited else ""),
                                                              money(l["amount"]), cls_txt, combo_of.get(l["pid"], "")))
        if prev_sel and self.tree.exists(prev_sel[0]):
            self.tree.selection_set(prev_sel[0])
        sh = r["ship"]
        kv = lambda a, b: f"{a}\t{b}"
        L = [("Mức giá áp dụng:", "n"), (f"  {r['tier_label']}", ""), ("", ""),
             (kv("Tạm tính (niêm yết)", money(r["list_total"])), ""),
             (kv("Chiết khấu mức giá", "-" + money(r["tier_discount"])), ""),
             (kv("Khuyến mãi thêm", "-" + money(r["promo"])), ""),
             (kv("TIỀN HÀNG", money(r["goods_total"])), "b"),
             (kv("Phí lắp ráp", "+" + money(r["assembly"])), ""),
             (kv("Ván chống ẩm", "+" + money(r["moisture"])), "")]
        if r.get("extra_fees"):
            L.append((kv("Phụ phí / phát sinh", "+" + money(r["extra_fees"])), ""))
        L += [("", ""),
             (f"Vùng ship: {sh['zone']}", "n")]
        if km is not None:
            L.append((f"Khoảng cách: {km:.1f} km", "n"))
        if sh["class"]:
            L.append((f"Phân loại: {sh['class']} (phí gốc {money(sh['raw'])})", "n"))
        for n in sh["notes"]:
            L.append(("• " + n, "n"))
        L += [(kv("PHÍ VẬN CHUYỂN" + (" (nhập tay)" if sh.get("manual") else ""), "+" + money(sh["fee"])), "b"), ("", ""),
              (kv("TỔNG THANH TOÁN", money(r["grand"])), "b"), ("", ""),
              ("💡 Nhấp đúp vào dòng Phí vận chuyển / Phí lắp ráp / Ván chống ẩm để nhập tay.", "n")]
        self.sum.config(state="normal")
        self.sum.delete("1.0", "end")
        for t, tag in L:
            self.sum.insert("end", t + "\n", tag)
        self.sum.config(state="disabled")

    def order_dict(self):
        return {"id": self.order_id or uuid.uuid4().hex[:10], "created": orderimage.now_gmt7().strftime("%Y-%m-%d %H:%M:%S"),
                "customer": {"name": self.name.get().strip(), "phone": self.phone.get().strip(), "address": self.addr.get().strip()},
                "items": self.items, "result": self.last, "type": self.otype.get(), "wood_kind": self.wood_kind.get(),
                "wood_lines": self.wood_lines,
                "receipt": {"code": self.code.get().strip() or receipts.next_code(self.app.orders), "tech": self.tech.get().strip(),
                            "title": self.title_var.get().strip(),
                            "handover": self.handover.get().strip(), "advance": self.advance.get().strip(),
                            "priority": self.priority.get(), "paid": self.paid.get(),
                            "installments": [dict(x) for x in self.inst] if self.inst_active() else [],
                            "final_reason": self.final_reason.get().strip()},
                "opts": {"tier": self.tier.get(), "promo_pct": self.promo_pct.get(), "promo_amt": self.promo_amt.get(),
                         "asm": self.asm.get(), "moist": self.moist.get(), "zone": self.zone_sel.get(),
                         "lala": self.lala.get(), "km_manual": self.km_manual.get(), "geo": self.geo,
                         "ship_manual": self.ship_manual.get(), "asm_ov": self.asm_ov.get(), "moist_ov": self.moist_ov.get()}}

    def save(self):
        wood = self.otype.get() == "wood"
        if not self.name.get().strip() or not (self.wood_lines if wood else self.items):
            messagebox.showwarning("Thiếu thông tin", "Nhập tên khách hàng và thêm ít nhất 1 " + ("dòng hàng gỗ." if wood else "sản phẩm."))
            return
        if not self.check_wood():
            return
        o = self.order_dict()
        self.order_id = o["id"]
        self.app.orders = [x for x in self.app.orders if x["id"] != o["id"]] + [o]
        store.save_json("orders.json", self.app.orders)
        self.app.orders_tab.refresh()
        msg = f"Đã lưu đơn của {o['customer']['name']} – tổng {money(o['result']['grand'])}đ"
        self.run_export(o, msg)

    def run_export(self, o, msg=""):
        try:
            paths = receipts.export_receipts(o, self.app.settings, self.app.pmap)
            o["images"] = paths
            if any(x["id"] == o["id"] for x in self.app.orders):
                store.save_json("orders.json", self.app.orders)
            jpgs = [p for p in paths if p.lower().endswith(".jpg")]
            if orderimage.last_note:
                msg = (msg + "\n\n" if msg else "") + "⚠ " + orderimage.last_note
            pdfs = [p for p in paths if p.lower().endswith(".pdf")]
            if messagebox.askyesno("Đã xuất biên lai", (msg + "\n\n" if msg else "") + f"Đã xuất {len(jpgs)} biên lai (PDF in A4 + JPG + Excel) tại:\n" + os.path.dirname(paths[0]) + "\n\nMở file PDF để in ngay?"):
                for p in (pdfs or jpgs):
                    self.app.open_path(p)
        except Exception as e:  # noqa
            messagebox.showwarning("Lỗi xuất biên lai", (msg + "\n\n" if msg else "") + f"Không xuất được biên lai: {e}\nKiểm tra thư mục lưu trong tab Cài đặt.")

    def export_now(self):
        wood = self.otype.get() == "wood"
        if not (self.wood_lines if wood else self.items):
            messagebox.showinfo("Trống", "Đơn hàng chưa có sản phẩm.")
            return
        if not self.check_wood():
            return
        self.run_export(self.order_dict())

    def check_wood(self):
        if self.otype.get() != "wood":
            return True
        bad = [str(i) for i, l in enumerate(self.wood_lines, 1) if receipts.line_issue(l)]
        if bad:
            return messagebox.askyesno("Thiếu kích thước", "Dòng " + ", ".join(bad) + " chưa có kích thước (m2/md) nên THÀNH TIỀN = 0.\n\nVẫn tiếp tục?")
        return True

    def new(self):
        self.items, self.geo, self.order_id = [], None, None
        self.wood_lines = []
        self.inst = []
        self.inst_clear_fields()
        self.final_reason.set(receipts.FINAL_REASON)
        self.title_var.set("")
        self.otype.set("loose")
        self.switch()
        for v in (self.name, self.phone, self.addr, self.km_manual, self.ship_manual, self.asm_ov, self.moist_ov):
            v.set("")
        self.promo_pct.set("0"); self.promo_amt.set("0"); self.lala.set("0")
        self.zone_sel.set("Tự động"); self.tier.set("Tự động theo số lượng")
        self.asm.set(False); self.moist.set(False)
        self.tech.set(self.app.settings["receipt"].get("tech", "")); self.handover.set(""); self.advance.set("")
        self.priority.set("Tiêu Chuẩn"); self.paid.set(False)
        self.code.set(receipts.next_code(self.app.orders))
        self.geo_lbl.config(text="Chưa tính khoảng cách  ·  Ngoại tỉnh: phí Lalamove = km × 12.000đ (để trống ô Lalamove tay)")
        self.recalc()

    def load(self, o):
        self.new()
        c, op = o["customer"], o["opts"]
        self.name.set(c["name"]); self.phone.set(c["phone"]); self.addr.set(c["address"])
        self.items = [dict(i) for i in o["items"]]
        self.order_id, self.geo = o["id"], op.get("geo")
        self.tier.set(op["tier"]); self.promo_pct.set(op["promo_pct"]); self.promo_amt.set(op["promo_amt"])
        self.asm.set(op["asm"]); self.moist.set(op["moist"]); self.zone_sel.set(op["zone"])
        self.lala.set(op["lala"]); self.km_manual.set(op["km_manual"])
        self.ship_manual.set(op.get("ship_manual", "")); self.asm_ov.set(op.get("asm_ov", "")); self.moist_ov.set(op.get("moist_ov", ""))
        rc = o.get("receipt", {})
        self.code.set(rc.get("code", "")); self.tech.set(rc.get("tech", "")); self.handover.set(rc.get("handover", ""))
        self.advance.set(rc.get("advance", "")); self.priority.set(rc.get("priority", "Tiêu Chuẩn")); self.paid.set(bool(rc.get("paid")))
        self.title_var.set(rc.get("title", ""))
        self.wood_lines = [dict(x) for x in o.get("wood_lines", [])]
        self.inst = [dict(x) for x in rc.get("installments", []) if isinstance(x, dict)]
        self.final_reason.set(rc.get("final_reason") or receipts.FINAL_REASON)
        self.otype.set(o.get("type", "loose"))
        self.wood_kind.set(o.get("wood_kind", "Hàng công trình"))
        self.switch()
        if self.geo:
            self.geo_lbl.config(text=f"Khoảng cách đường bộ: {self.geo['km']:.1f} km ({self.geo['method']})\nĐịa chỉ tìm thấy: {self.geo['found']}")
        self.recalc()


class OrdersTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        bar = ttk.Frame(self, padding=(10, 10, 10, 8))
        bar.pack(fill="x")
        ttk.Button(bar, text="Mở lại / chỉnh sửa", style="Accent.TButton", command=self.open).pack(side="left")
        ttk.Button(bar, text="Xuất lại biên lai", command=self.export).pack(side="left", padx=4)
        ttk.Button(bar, text="Xóa", command=self.delete).pack(side="left")
        ttk.Button(bar, text="🖼 Xem biên lai", command=self.view_img).pack(side="left", padx=4)
        ttk.Button(bar, text="📁 Mở thư mục DON HANG", command=self.open_folder).pack(side="left")
        cols = [("date", "Ngày lập"), ("kind", "Loại đơn"), ("name", "Khách hàng"), ("phone", "SĐT"), ("addr", "Địa chỉ"), ("goods", "Tiền hàng"), ("ship", "Phí ship"), ("total", "Tổng")]
        fr, self.t = make_tree(self, cols, (130, 150, 170, 110, 290, 110, 90, 120), height=10, hscroll=True)
        fr.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.t.bind("<Double-1>", lambda e: self.open())
        self.refresh()

    def refresh(self):
        self.t.delete(*self.t.get_children())
        for o in sorted(self.app.orders, key=lambda x: x["created"], reverse=True):
            r, c = o["result"], o["customer"]
            self.t.insert("", "end", iid=o["id"], values=(o["created"], ("Gỗ – " + o.get("wood_kind", "")) if o.get("type") == "wood" else "Nội thất bán sẵn", c["name"], c["phone"], c["address"],
                                                          money(r["goods_total"]), money(r["ship"]["fee"]), money(r["grand"])))

    def sel(self):
        s = self.t.selection()
        return next((o for o in self.app.orders if s and o["id"] == s[0]), None)

    def open(self):
        o = self.sel()
        if o:
            self.app.order.load(o)
            self.app.show_tab(self.app.order)

    def export(self):
        o = self.sel()
        if o:
            self.app.order.run_export(o)

    def view_img(self):
        o = self.sel()
        ps = [p for p in (o.get("images") or ([o["image"]] if o.get("image") else [])) if os.path.exists(p) and p.lower().endswith((".jpg", ".png"))] if o else []
        if ps:
            for p in ps:
                self.app.open_path(p)
        elif o:
            messagebox.showinfo("Ảnh đơn", "Không tìm thấy ảnh của đơn này (có thể đã bị di chuyển/xóa).")

    def open_folder(self):
        self.app.order.open_dir()

    def delete(self):
        o = self.sel()
        if o and messagebox.askyesno("Xóa", "Xóa đơn hàng này?"):
            self.app.orders.remove(o)
            store.save_json("orders.json", self.app.orders)
            self.refresh()


# ======================================================================= Phí ship + Cài đặt
class ShipTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(1, weight=1)
        bar = ttk.Frame(self, padding=(12, 10, 12, 4))
        bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        ttk.Button(bar, text="📥 Nhập bảng phí ship (PDF/Excel/Word)", style="Accent.TButton", command=self.import_file).pack(side="left")
        ttk.Button(bar, text="✎ Sửa dòng chọn", command=self.edit).pack(side="left", padx=6)
        ttk.Button(bar, text="⚙ Ngưỡng giảm / miễn phí", command=self.edit_policy).pack(side="left")
        zf = ttk.LabelFrame(self, text="Vùng vận chuyển", padding=8)
        zf.grid(row=1, column=0, sticky="nsew", padx=(12, 6), pady=(4, 12))
        fr, self.zt = make_tree(zf, [("name", "Vùng"), ("range", "Khoảng cách"), ("fee", "Phí cơ bản"), ("free", "Miễn phí ≥ 15tr"), ("match", "Nhận theo địa chỉ chứa")],
                                (200, 95, 160, 100, 130), height=6)
        fr.pack(fill="both", expand=True)
        rt = ttk.Frame(self)
        rt.grid(row=1, column=1, sticky="nsew", padx=(6, 12), pady=(4, 12))
        rt.columnconfigure(0, weight=1)
        rt.rowconfigure(2, weight=1)
        cf = ttk.LabelFrame(rt, text="Phân loại kích thước (hệ số nhân phí vùng)", padding=8)
        cf.grid(row=0, column=0, sticky="ew")
        fr, self.ct = make_tree(cf, [("name", "Loại"), ("mult", "Hệ số"), ("dims", "Kích thước giới hạn (mm)"), ("kg", "Tối đa (kg)")], (95, 60, 190, 80), height=3)
        fr.pack(fill="x")
        mf = ttk.LabelFrame(rt, text="Cách tính đơn nhiều sản phẩm", padding=8)
        mf.grid(row=1, column=0, sticky="ew", pady=8)
        self.mode = tk.StringVar()
        cb = ttk.Combobox(mf, textvariable=self.mode, state="readonly",
                          values=["1 chuyến xe – lấy phân loại lớn nhất trong đơn", "Cộng theo từng dòng sản phẩm"])
        cb.pack(fill="x")
        cb.bind("<<ComboboxSelected>>", self.set_mode)
        pf = ttk.LabelFrame(rt, text="Chính sách giảm / miễn phí & ghi chú", padding=10)
        pf.grid(row=2, column=0, sticky="nsew")
        self.pol = ttk.Label(pf, justify="left", anchor="nw", wraplength=380)
        self.pol.pack(fill="both", expand=True)
        pf.bind("<Configure>", lambda e: self.pol.config(wraplength=max(200, e.width - 30)))
        self.refresh()

    def refresh(self):
        S = self.app.settings
        self.mode.set("Cộng theo từng dòng sản phẩm" if S.get("ship_mode") == "sum" else "1 chuyến xe – lấy phân loại lớn nhất trong đơn")
        self.zt.delete(*self.zt.get_children())
        for z in S["zones"]:
            rng = "" if z["max_km"] is None and z["min_km"] is None else (f"{z['min_km']}–{z['max_km']} km" if z["max_km"] is not None else f"> {z['min_km']} km")
            self.zt.insert("", "end", iid=z["key"], values=(z["name"], rng, money(z["fee"]) if z["fee"] is not None else f"Lalamove: km × {money(S.get('lalamove_per_km', 12000))}đ", "Có" if z["free_eligible"] else "Không", ", ".join(z["match"])))
        self.ct.delete(*self.ct.get_children())
        for c in S["ship_classes"]:
            self.ct.insert("", "end", iid=c["key"], values=(c["name"], f"{int(c['mult'] * 100)}%", " x ".join(map(str, c["max_dims"])) if c["max_dims"] else "Lớn hơn mức trung bình", c["max_kg"] or ""))
        p = S["ship_policy"]
        self.pol.config(text=f"Đơn từ {money(p['half_from'])}đ: giảm {p['half_pct']}% phí ship (mọi vùng)\n"
                             f"Đơn từ {money(p['free_from'])}đ: miễn phí ship (chỉ vùng dưới 30 km)\n"
                             "Phân loại tự động theo: từ khóa tên sản phẩm → kích thước (có thể ép riêng từng sản phẩm trong màn hình sửa sản phẩm).")

    def set_mode(self, _=None):
        self.app.settings["ship_mode"] = "sum" if self.mode.get().startswith("Cộng") else "max"
        self.app.save_settings()

    def edit(self):
        S = self.app.settings
        if self.zt.selection():
            z = next(z for z in S["zones"] if z["key"] == self.zt.selection()[0])
            if z["fee"] is None:
                n = simpledialog.askinteger("Lalamove", "Đơn giá Lalamove ngoại tỉnh (đ/km):", initialvalue=int(S.get("lalamove_per_km", 12000)), minvalue=0, parent=self)
                if n is not None:
                    S["lalamove_per_km"] = n
                    self.app.save_settings()
                return
            n = simpledialog.askinteger("Phí cơ bản", f"{z['name']}\nPhí cơ bản (đ):", initialvalue=int(z["fee"]), minvalue=0, parent=self)
            if n is not None:
                z["fee"] = n
        elif self.ct.selection():
            c = next(c for c in S["ship_classes"] if c["key"] == self.ct.selection()[0])
            n = simpledialog.askinteger("Hệ số", f"Loại {c['name']}\nHệ số (% phí vùng):", initialvalue=int(c["mult"] * 100), minvalue=0, parent=self)
            if n is not None:
                c["mult"] = n / 100
        else:
            return
        self.app.save_settings()

    def edit_policy(self):
        p = self.app.settings["ship_policy"]
        a = simpledialog.askinteger("Giảm phí", "Giảm phí ship từ giá trị đơn (đ):", initialvalue=p["half_from"], parent=self)
        b = simpledialog.askinteger("Giảm phí", "Mức giảm (%):", initialvalue=p["half_pct"], parent=self)
        c = simpledialog.askinteger("Miễn phí", "Miễn phí ship từ giá trị đơn (đ):", initialvalue=p["free_from"], parent=self)
        if None not in (a, b, c):
            p.update(half_from=a, half_pct=b, free_from=c)
            self.app.save_settings()

    def import_file(self):
        fp = filedialog.askopenfilename(filetypes=[("Bảng phí ship", "*.pdf *.xlsx *.xlsm *.docx *.csv *.txt")])
        if not fp:
            return

        def done(ok, res):
            if not ok:
                messagebox.showerror("Không đọc được", str(res))
                return
            new, rep = res
            if not rep:
                messagebox.showwarning("Không nhận dạng", "Không tìm thấy dòng phí ship nào trong file.")
                return
            if messagebox.askyesno("Cập nhật bảng phí?", "Đọc được:\n\n" + "\n".join("• " + r for r in rep) + "\n\nÁp dụng?"):
                self.app.settings.clear()
                self.app.settings.update(new)
                self.app.save_settings()

        run_bg(self, lambda: importer.parse_shipping_text(importer.file_text(fp), self.app.settings), done)


class SettingsTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        S = app.settings
        self.v = {}
        for c in (0, 1):
            self.columnconfigure(c, weight=1, uniform="cards")
        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)

        def card(title, r, c, **kw):
            f = ttk.LabelFrame(self, text=title, padding=(12, 6, 12, 10))
            f.grid(row=r, column=c, sticky="nsew", padx=(12, 6) if c == 0 else (6, 12), pady=(12, 0) if r == 0 else (10, 0))
            f.columnconfigure(1, weight=1)
            return f

        def field(f, r, label, key, val):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", pady=3)
            self.v[key] = tk.StringVar(value=str(val))
            ttk.Entry(f, textvariable=self.v[key]).grid(row=r, column=1, sticky="ew", padx=(10, 0), pady=3)

        cc, o = S["company"], S["origin"]
        c1 = card("Công ty & kho xuất phát", 0, 0)
        field(c1, 0, "Tên công ty", "c_name", cc["name"])
        field(c1, 1, "Địa chỉ công ty", "c_addr", cc["address"])
        field(c1, 2, "MST", "c_tax", cc["tax"])
        field(c1, 3, "Liên hệ", "c_phone", cc["phone"])
        field(c1, 4, "Địa chỉ kho", "o_addr", o["address"])
        field(c1, 5, "Vĩ độ kho", "o_lat", o.get("lat") or "")
        field(c1, 6, "Kinh độ kho", "o_lng", o.get("lng") or "")
        ttk.Label(c1, text="Mẹo: Google Maps → bấm chuột phải vào nhà máy để copy tọa độ (khoảng cách chính xác nhất).",
                  foreground=MUTED, wraplength=420, justify="left").grid(row=7, column=0, columnspan=2, sticky="w", pady=(4, 0))

        c2 = card("Bản đồ & nơi lưu biên lai", 0, 1)
        ttk.Label(c2, text="Dịch vụ bản đồ").grid(row=0, column=0, sticky="w", pady=3)
        self.v["geo"] = tk.StringVar(value=S["geocoder"])
        ttk.Combobox(c2, textvariable=self.v["geo"], values=["osm", "goong"], state="readonly", width=12).grid(row=0, column=1, sticky="w", padx=(10, 0), pady=3)
        ttk.Label(c2, text="osm = miễn phí (OpenStreetMap)  ·  goong = Goong.io, chính xác hơn với địa chỉ VN (cần API key)",
                  foreground=MUTED, wraplength=420, justify="left").grid(row=1, column=0, columnspan=2, sticky="w")
        field(c2, 2, "Goong API key", "goong", S["goong_key"])
        ttk.Label(c2, text="Thư mục lưu đơn").grid(row=3, column=0, sticky="w", pady=(10, 3))
        self.v["odir"] = tk.StringVar(value=S.get("orders_dir") or orderimage.base_dir(S))
        fo = ttk.Frame(c2)
        fo.grid(row=3, column=1, sticky="ew", padx=(10, 0), pady=(10, 3))
        ttk.Entry(fo, textvariable=self.v["odir"]).pack(side="left", fill="x", expand=True)
        ttk.Button(fo, text="Chọn…", command=self.pick_dir).pack(side="left", padx=(6, 0))
        self.odir_hint = ttk.Label(c2, foreground=MUTED, wraplength=420, justify="left")
        self.odir_hint.grid(row=4, column=0, columnspan=2, sticky="w")
        self.v["odir"].trace_add("write", lambda *a: self.hint())
        self.hint()
        ttk.Label(c2, text="Phí Lalamove ngoại tỉnh: sửa đơn giá/km ở tab Phí vận chuyển.", foreground=MUTED).grid(row=5, column=0, columnspan=2, sticky="w", pady=(8, 0))

        c3 = card("Thông tin in trên biên lai", 1, 0)
        R = S["receipt"]
        for r_, (lab, key) in enumerate((("Quản lý đơn hàng", "manager"), ("SĐT quản lý", "manager_phone"), ("Phụ trách kỹ thuật", "tech"),
                                         ("Giám đốc (chữ ký)", "director"), ("Báo giá hiệu lực (ngày)", "quote_days"), ("Đơn đặt hàng hiệu lực (ngày)", "order_days"))):
            field(c3, r_, lab, "r_" + key, R.get(key, ""))
        ttk.Label(c3, text="Nội dung Lưu ý / Bảo hành: sửa trong settings.json (mục receipt) tại %APPDATA%\\MocTamQuote",
                  foreground=MUTED, wraplength=420, justify="left").grid(row=6, column=0, columnspan=2, sticky="w", pady=(4, 0))

        c4 = card("Mức chiết khấu  (bấm đúp để sửa %)", 1, 1)
        c4.rowconfigure(0, weight=1)
        fr, self.tt = make_tree(c4, [("label", "Mức giá"), ("pct", "Chiết khấu %")], (260, 100), height=6)
        fr.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.tt.bind("<Double-1>", self.edit_tier)

        foot = ttk.Frame(self, padding=(12, 10, 12, 12))
        foot.grid(row=2, column=0, columnspan=2, sticky="ew")
        ttk.Label(foot, text=f"Mộc Tâm Quote  ·  Phiên bản {version.VERSION}  ·  Tác giả: {AUTHOR}  ·  {AUTHOR_PHONE}", foreground=BRAND, font=(FONT, 10, "bold")).pack(side="left")
        ttk.Button(foot, text="💾 Lưu cài đặt", style="Accent.TButton", command=self.save).pack(side="right")
        self.fill()

    def pick_dir(self):
        d = filedialog.askdirectory(initialdir=self.v["odir"].get() or None, title="Chọn nơi lưu thư mục DON HANG")
        if d:
            self.v["odir"].set(d)

    def hint(self):
        b = self.v["odir"].get().strip() or orderimage.base_dir({})
        self.odir_hint.config(text=f"Ảnh sẽ lưu tại: {os.path.join(b, 'DON HANG', 'THÁNG ' + str(orderimage.now_gmt7().month), 'ngàythángnămgiờphútgiây.jpg')}")

    def fill(self):
        self.tt.delete(*self.tt.get_children())
        for t in self.app.settings["tiers"]:
            self.tt.insert("", "end", iid=t["key"], values=(t["label"], t["pct"]))

    def edit_tier(self, _):
        s = self.tt.selection()
        if not s:
            return
        t = next(t for t in self.app.settings["tiers"] if t["key"] == s[0])
        if t["key"] == "list":
            return
        n = simpledialog.askfloat("Chiết khấu", f"{t['label']}\nChiết khấu (%):", initialvalue=t["pct"], minvalue=0, maxvalue=90, parent=self)
        if n is not None:
            t["pct"] = int(n) if n == int(n) else n
            t["label"] = re.sub(r"CK\s*-?\s*\d+(\.\d+)?%", f"CK {t['pct']}%", t["label"])
            self.fill()
            self.app.save_settings()

    def save(self):
        S, v = self.app.settings, self.v
        S["company"].update(name=v["c_name"].get(), address=v["c_addr"].get(), tax=v["c_tax"].get(), phone=v["c_phone"].get())
        S["origin"].update(address=v["o_addr"].get(), lat=parse_float(v["o_lat"].get()), lng=parse_float(v["o_lng"].get()))
        S["geocoder"] = v["geo"].get().strip().lower() or "osm"
        S["goong_key"] = v["goong"].get().strip()
        S["orders_dir"] = v["odir"].get().strip()
        for k in ("manager", "manager_phone", "tech", "director"):
            S["receipt"][k] = v["r_" + k].get().strip()
        for k, dflt in (("quote_days", 14), ("order_days", 7)):
            try:
                S["receipt"][k] = int(v["r_" + k].get())
            except ValueError:
                S["receipt"][k] = dflt
        self.app.save_settings()
        messagebox.showinfo("Đã lưu", "Đã lưu cài đặt.")


# ======================================================================= App
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mộc Tâm Quote – Báo giá & Lên đơn")
        self.geometry("1380x840")
        self.configure(bg=BG)
        self.report_callback_exception = self.on_error
        self._err_shown = False
        try:
            store.cleanup_tmp()
        except Exception:
            pass
        self.settings = store.load_settings()
        self.products = store.load_products()
        self.orders = store.load_json("orders.json", [])
        self.wood = store.load_wood()
        self.reindex()
        self.style()
        self.set_icon()
        head = tk.Frame(self, bg=DARK)
        head.pack(fill="x")
        self._logo = None
        try:
            im = Image.open(store.resource("assets/logo.png")).convert("RGBA")
            im.thumbnail((200, 56))
            self._logo = ImageTk.PhotoImage(im)
            tk.Label(head, image=self._logo, bg=DARK).pack(side="left", padx=(20, 10), pady=10)
        except Exception:
            tk.Label(head, text="MỘC TÂM FURNITURE", bg=DARK, fg=GOLD, font=(FONT, 16, "bold")).pack(side="left", padx=20, pady=10)
        tk.Frame(head, bg="#5A4A33", width=1).pack(side="left", fill="y", pady=14)
        tk.Label(head, text="BÁO GIÁ  ·  LÊN ĐƠN  ·  BIÊN LAI", bg=DARK, fg="#E9D7AE", font=(FONT, 10, "bold")).pack(side="left", padx=14)
        about = tk.Label(head, text=f"ⓘ  Tác giả: {AUTHOR}  ·  {AUTHOR_PHONE}", bg=DARK, fg=GOLD, font=(FONT, 9), cursor="hand2")
        about.pack(side="right", padx=22)
        about.bind("<Button-1>", lambda e: self.show_about())
        tk.Frame(self, bg=GOLD, height=3).pack(fill="x")
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True)
        self.holders = {}

        def mk(cls, title):
            sc = Scroll(self.nb)
            tab = cls(sc.body, self)
            tab.pack(fill="both", expand=True)
            self.nb.add(sc, text=title)
            self.holders[tab] = sc
            return tab

        self.catalog = mk(CatalogTab, "  📦 Sản phẩm  ")
        self.order = mk(OrderTab, "  🧾 Lên đơn  ")
        self.orders_tab = mk(OrdersTab, "  📚 Đơn đã lưu  ")
        self.ship = mk(ShipTab, "  🚚 Phí vận chuyển  ")
        self.setting = mk(SettingsTab, "  ⚙ Cài đặt  ")
        foot = tk.Frame(self, bg="#EDE5D6")
        foot.pack(fill="x", side="bottom")
        self.bar = tk.Label(foot, text="", anchor="w", bg="#EDE5D6", fg=MUTED, font=(FONT, 9))
        self.bar.pack(side="left", padx=12, pady=4)
        tk.Label(foot, text=f"Mộc Tâm Quote v{version.VERSION}  ·  Phát triển bởi {AUTHOR} – {AUTHOR_PHONE}", anchor="e", bg="#EDE5D6", fg=MUTED,
                 font=(FONT, 9)).pack(side="right", padx=12, pady=4)
        lnk = tk.Label(foot, text="🔄 Kiểm tra cập nhật", bg="#EDE5D6", fg=BRAND, cursor="hand2", font=(FONT, 9, "underline"))
        lnk.pack(side="right", padx=8, pady=4)
        lnk.bind("<Button-1>", lambda e: self.check_update(silent=False))
        self._uq = queue.Queue()                       # luồng nền (tải cập nhật) gửi việc về luồng giao diện qua hàng đợi này
        self.after(300, self._poll_uq)
        self.after(2500, self.startup_checks)
        self.nb.pack_forget()
        self.nb.pack(fill="both", expand=True)
        self.fit_window()

    # --- cập nhật online (chỉ tải mã .py về thư mục code; dữ liệu sản phẩm/đơn/cài đặt giữ nguyên)
    def update_url(self):
        return (self.settings.get("update_url") or version.UPDATE_URL or "").strip()

    def _poll_uq(self):
        try:
            while True:
                self._uq.get_nowait()()
        except queue.Empty:
            pass
        except Exception:
            store.log_error(__import__("traceback").format_exc())
        self.after(200, self._poll_uq)

    def startup_checks(self):
        note = updater.pop_rollback_notice()
        if note is not None:
            messagebox.showwarning("Cập nhật bị lỗi", "Bản cập nhật vừa tải về không chạy được nên phần mềm đã tự quay về bản gốc.\nDữ liệu của bạn không bị ảnh hưởng.\nHãy báo người phát triển để sửa.", parent=self)
        if self.settings.get("auto_update", True) and self.update_url():
            self.check_update(silent=True)

    def check_update(self, silent=True):
        url = self.update_url()
        if not url:
            if not silent:
                messagebox.showinfo("Cập nhật", "Chưa cấu hình địa chỉ cập nhật.\nXem file HUONG_DAN_UPDATE.txt (mục UPDATE_URL trong version.py).", parent=self)
            return

        def work():
            try:
                res, err = updater.check(url, version.VERSION), None
            except Exception as e:  # noqa
                res, err = None, str(e)
            self._uq.put(lambda: self._update_found(res, err, silent))
        threading.Thread(target=work, daemon=True).start()

    def _update_found(self, info, err, silent):
        if err:
            if not silent:
                messagebox.showwarning("Cập nhật", f"Không kiểm tra được cập nhật (kiểm tra mạng):\n{err}", parent=self)
            return
        if info is None:
            if not silent:
                messagebox.showinfo("Cập nhật", f"Bạn đang dùng bản mới nhất (v{version.VERSION}).", parent=self)
            return
        notes = info.get("notes") or ""
        if info.get("need_installer"):
            messagebox.showinfo("Có bản mới", f"Có bản v{info['version']} nhưng cần cài lại bằng bộ cài mới.\n{notes}\nLiên hệ {AUTHOR} – {AUTHOR_PHONE} để nhận bộ cài.\n(Dữ liệu của bạn vẫn được giữ khi cài lại.)", parent=self)
            return
        if not messagebox.askyesno("Có bản cập nhật", f"Có bản mới v{info['version']} (đang dùng v{version.VERSION}).\n\n{notes}\n\nCập nhật ngay? Sản phẩm, đơn hàng và cài đặt của bạn được giữ nguyên.", parent=self):
            return
        self.status("Đang tải bản cập nhật…")

        def work():
            try:
                updater.download_install(info, self.update_url(), lambda f: self._uq.put(lambda: self.status(f"Đang tải bản cập nhật… {int(f * 100)}%")))
                err = None
            except Exception as e:  # noqa
                err = str(e)
            self._uq.put(lambda: self._update_done(info, err))
        threading.Thread(target=work, daemon=True).start()

    def _update_done(self, info, err):
        self.status("")
        if err:
            messagebox.showwarning("Cập nhật", f"Cập nhật không thành công, vẫn dùng bản cũ:\n{err}", parent=self)
            return
        if messagebox.askyesno("Đã cập nhật", f"Đã cập nhật lên v{info['version']}.\nKhởi động lại phần mềm ngay?\n(Nhớ lưu đơn đang soạn dở trước khi bấm Có)", parent=self):
            updater.restart()
            self.destroy()

    def on_error(self, exc, val, tb):
        import traceback
        text = "".join(traceback.format_exception(exc, val, tb))
        store.log_error(text)
        if not self._err_shown:
            self._err_shown = True
            messagebox.showerror("Có lỗi xảy ra", f"{val}\n\nChi tiết đã ghi vào:\n{store.path('error.log')}\n(Phần mềm vẫn chạy; nếu lỗi lặp lại hãy gửi file này cho tác giả.)")

    def show_tab(self, tab):
        self.nb.select(self.holders[tab])

    def fit_window(self):
        """Mở vừa màn hình (phóng to trên Windows) – không cần kéo rộng mới thấy đủ."""
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(1440, sw - 20), min(900, sh - 80)
        self.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 2 - 20)}")
        self.minsize(min(1000, sw - 20), min(620, sh - 80))
        try:
            self.state("zoomed")
        except Exception:
            pass

    def show_about(self):
        messagebox.showinfo("Thông tin phần mềm", "MỘC TÂM QUOTE – Báo giá, lên đơn & xuất biên lai\nPhiên bản 1.0\n\n"
                            f"Tác giả: {AUTHOR}\nĐiện thoại / Zalo: {AUTHOR_PHONE}\n\n"
                            "Phần mềm phát triển riêng cho Công ty TNHH Mộc Tâm Furniture.")

    def set_icon(self):
        try:
            self.iconbitmap(store.resource("assets/logo.ico"))
        except Exception:
            try:
                self._icon = ImageTk.PhotoImage(Image.open(store.resource("assets/logo_icon.png")))
                self.iconphoto(True, self._icon)
            except Exception:
                pass

    def style(self):
        import tkinter.font as tkfont
        for nm in ("TkDefaultFont", "TkTextFont", "TkHeadingFont", "TkMenuFont", "TkCaptionFont", "TkTooltipFont"):
            try:
                tkfont.nametofont(nm).configure(family=FONT, size=10)
            except Exception:
                pass
        self.option_add("*Font", f"{FONT} 10")
        self.option_add("*TCombobox*Listbox.font", f"{FONT} 10")
        self.option_add("*TCombobox*Listbox.background", "white")
        self.option_add("*TCombobox*Listbox.selectBackground", BRAND)
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", font=(FONT, 10), background=BG, foreground=TEXT, bordercolor="#D9CBB2", focuscolor=BG)
        s.configure("TFrame", background=BG)
        s.configure("TLabel", background=BG, foreground=TEXT)
        s.configure("TLabelframe", background=BG, bordercolor="#D9CBB2", relief="solid", borderwidth=1)
        s.configure("TLabelframe.Label", background=BG, foreground=BRAND, font=(FONT, 10, "bold"))
        s.configure("TCheckbutton", background=BG)
        s.configure("TRadiobutton", background=BG)
        s.configure("TEntry", padding=5, fieldbackground="white", bordercolor="#CDBE9F", lightcolor="#CDBE9F", darkcolor="#CDBE9F")
        s.configure("TCombobox", padding=4, fieldbackground="white", background="#EFE6D6", arrowcolor=TEXT, bordercolor="#CDBE9F")
        s.map("TCombobox", fieldbackground=[("readonly", "white")], selectbackground=[("readonly", "white")], selectforeground=[("readonly", TEXT)])
        s.configure("TSpinbox", padding=4, fieldbackground="white", bordercolor="#CDBE9F")
        s.configure("TButton", padding=(12, 6), background="#EFE6D6", foreground=TEXT, bordercolor="#D2C3A8", relief="flat")
        s.map("TButton", background=[("active", "#E4D6BB"), ("disabled", "#EFEAE0")], foreground=[("disabled", "#A39A8B")])
        s.configure("Accent.TButton", background=BRAND, foreground="white", font=(FONT, 10, "bold"), padding=(14, 7), bordercolor=BRAND)
        s.map("Accent.TButton", background=[("active", "#8A5C1F"), ("disabled", "#CDB896")], foreground=[("disabled", "white")])
        s.configure("Toolbutton", padding=(14, 7), background="#EFE6D6", foreground=TEXT, font=(FONT, 10, "bold"), bordercolor="#D2C3A8")
        s.map("Toolbutton", background=[("selected", DARK), ("active", "#E4D6BB")], foreground=[("selected", GOLD)])
        s.configure("Treeview", rowheight=28, background="white", fieldbackground="white", foreground=TEXT, bordercolor="#E3D8C3", borderwidth=0)
        s.configure("Compact.Treeview", rowheight=24, background="white", fieldbackground="white", foreground=TEXT, borderwidth=0)
        s.configure("Treeview.Heading", font=(FONT, 10, "bold"), background="#2A2420", foreground="#F3E3BF", padding=(6, 7), relief="flat")
        s.map("Treeview.Heading", background=[("active", "#3A322B")])
        s.map("Treeview", background=[("selected", BRAND)], foreground=[("selected", "white")])
        s.map("Compact.Treeview", background=[("selected", BRAND)], foreground=[("selected", "white")])
        s.configure("TNotebook", background=DARK, borderwidth=0, tabmargins=(14, 8, 14, 0))
        s.configure("TNotebook.Tab", padding=(18, 9), font=(FONT, 10, "bold"), background="#3A322B", foreground="#CDBFA5", borderwidth=0)
        s.map("TNotebook.Tab", background=[("selected", BG), ("active", "#4A3F35")], foreground=[("selected", BRAND), ("active", "#F3E3BF")],
              expand=[("selected", (0, 0, 0, 2))])
        s.configure("Vertical.TScrollbar", background="#D9CBB2", troughcolor=BG, arrowcolor=TEXT, bordercolor=BG, relief="flat")
        s.configure("TPanedwindow", background=BG)

    def reindex(self):
        self.pmap = {p["id"]: p for p in self.products}

    def open_path(self, p):
        try:
            if os.name == "nt":
                os.startfile(p)  # noqa
            else:
                import subprocess
                subprocess.Popen(["xdg-open", p])
        except Exception:
            pass

    def status(self, t):
        self.bar.config(text=t)

    def save_products(self):
        self.reindex()
        store.save_products(self.products)
        self.catalog.reload_options()
        self.order.recalc()

    def save_settings(self):
        store.save_settings(self.settings)
        self.catalog.reload_options()
        self.order.reload_options()
        self.order.refresh_dir_label()
        self.ship.refresh()
        try:
            self.setting.v["odir"].set(self.settings.get("orders_dir") or orderimage.base_dir(self.settings))
        except Exception:
            pass


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
