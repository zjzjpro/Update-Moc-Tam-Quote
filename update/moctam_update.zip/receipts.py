# -*- coding: utf-8 -*-
"""Xuất biên lai (JPG + Excel):
  1) Bảng báo giá            – đồ nội thất bán sẵn
  2) Đơn đặt hàng kiêm biên bản nghiệm thu – nội thất bán sẵn  &  hàng gỗ (hàng rời / công trình)
Cột số liệu tự co giãn theo nội dung nên không bị đè chữ."""
import os
from PIL import Image, ImageDraw, ImageFont

import orderimage, store
from importer import strip_acc

INK, RED, BLUE, YELLOW = (0, 0, 0), (255, 0, 0), (0, 112, 192), (255, 255, 0)
SKY, SKY_LIGHT = (155, 194, 230), (221, 235, 247)
FONT = "Times New Roman"

_SERIF = {
    False: [r"C:\Windows\Fonts\times.ttf", "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf", "/System/Library/Fonts/Supplemental/Times New Roman.ttf"],
    True: [r"C:\Windows\Fonts\timesbd.ttf", "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf",
           "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf"],
}
_SANS_B = [r"C:\Windows\Fonts\arialbd.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]
_cache = {}


def F(size, bold=False, sans=False):
    size = max(8, int(size))
    key = (size, bold, sans)
    if key not in _cache:
        for p in (_SANS_B if sans else _SERIF[bold]):
            if os.path.exists(p):
                _cache[key] = ImageFont.truetype(p, size)
                break
        else:
            _cache[key] = ImageFont.load_default()
    return _cache[key]


def mc(v):
    return f"{float(v):,.0f}"


# ----------------------------------------------------------------------------- đo chữ / co giãn cột
def px(pt):
    return round(pt * 96 / 72)


def text_w(text, pt, bold=False):
    f = F(px(pt), bold)
    return max((f.getlength(l) for l in str(text).split("\n")), default=0)


def wrap_lines(text, pt, bold, width_px):
    f = F(px(pt), bold)
    out = []
    for para in str(text).split("\n"):
        cur = ""
        for w in para.split():
            t = (cur + " " + w).strip()
            if f.getlength(t) <= width_px or not cur:
                cur = t
            else:
                out.append(cur)
                cur = w
        out.append(cur)
    return out


def units_px(u):
    return int(u * 7 + 5)


def cell_h(text, pt, bold, units, pad=18):
    """Chiều cao (pt) cần cho ô chứa text với cột rộng `units`."""
    n = len(wrap_lines(text, pt, bold, units_px(units) - 18))
    return n * pt * 1.22 + pad * 72 / 96 + 4


def fit_columns(base, full, words, flex, pt=20, bold=(), pad=26, group=None):
    """base: độ rộng gốc (ký tự Excel). full: {cột: [text]} – phải hiện đủ 1 dòng.
    words: {cột: [text]} – chỉ cần chứa từ dài nhất. flex: {cột: tối thiểu} – cột được thu hẹp để bù.
    group: [(cột đầu, cột cuối, text)] – nhóm cột gộp cần đủ rộng cho text."""
    u = list(base)
    for i, cells in full.items():
        need = max((text_w(t, pt, i in bold) for t in cells if t), default=0) + pad
        u[i] = max(u[i], (need - 5) / 7)
    for i, cells in words.items():
        need = max((max((text_w(w, pt, i in bold) for w in str(t).split()), default=0) for t in cells if t), default=0) + pad
        u[i] = max(u[i], (need - 5) / 7)
    for a, b, t in group or []:
        need = (text_w(t, pt, True) + pad - 5) / 7
        cur = sum(u[a:b + 1])
        if cur < need:
            for i in range(a, b + 1):
                u[i] += (need - cur) / (b - a + 1)
    excess = sum(u) - sum(base)
    if excess > 0 and flex:
        slack = {i: max(0, u[i] - m) for i, m in flex.items()}
        tot = sum(slack.values())
        if tot > 0:
            take = min(excess, tot)
            for i, s in slack.items():
                u[i] -= take * s / tot
    return u


# ----------------------------------------------------------------------------- tính khối lượng / thành tiền (đúng công thức file mẫu)
def num(v):
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    t = "".join(ch for ch in str(v).replace(",", "") if ch.isdigit() or ch == ".")
    try:
        return float(t) if t else 0.0
    except ValueError:
        return 0.0


def calc_line(unit, dai, cao, qty, price):
    u = str(unit or "").strip().lower()
    if u == "m2":
        kl = num(dai) * num(cao) / 1e6
    elif u == "md":
        kl = num(dai) / 1000
    else:
        kl = 1.0
    qty, price = num(qty), num(price)
    amount = qty * price if u in ("bộ", "chuyến", "cái") else kl * qty * price
    return kl, amount


def line_issue(l):
    """True nếu dòng m2/md thiếu kích thước -> khối lượng = 0 -> thành tiền = 0."""
    u = str(l.get("unit", "")).strip().lower()
    if u == "m2":
        return num(l.get("dai")) <= 0 or num(l.get("cao")) <= 0
    if u == "md":
        return num(l.get("dai")) <= 0
    return False


def dim_val(v):
    s = str(v if v is not None else "").strip()
    if not s:
        return ""
    try:
        f = float(s.replace(",", ""))
        return int(f) if f == int(f) else round(f, 2)
    except ValueError:
        return s


def dim_txt(v):
    d = dim_val(v)
    return "" if d == "" else str(d)


# ----------------------------------------------------------------------------- các đợt ứng / thanh toán (hàng công trình)
FINAL_REASON = "CÒN KHI NGHIỆM THU BÀN GIAO"
ADVANCE_PRESETS = ["CHỐT CỌC SẢN XUẤT", "LÊN HÀNG LẮP RÁP TẠI CÔNG TRÌNH"]      # lý do có sẵn – vẫn gõ tay lý do khác được


def fmt_pct(x):
    s = f"{float(x):.2f}".rstrip("0").rstrip(".")
    return s or "0"


def build_installments(rc, total):
    """Các đợt ứng nhập tay: mỗi đợt {reason, pct | amt, paid}. Trả về danh sách dòng biên lai:
    [TẠM ỨNG x% <lý do> ..., THANH TOÁN y% <lý do cuối>] – dòng cuối luôn = tổng tiền - các đợt ứng.
    Đợt nhập % -> số tiền = tổng x %; đợt nhập số tiền -> % tự tính. Rỗng nếu không có đợt nào (dùng cách cũ)."""
    out, cum = [], 0.0
    for x in (rc.get("installments") or []):
        if not isinstance(x, dict):
            continue
        try:
            p = float(str(x.get("pct") or "").replace(",", ".").replace("%", "").strip() or 0)    # "33,5" = 33.5 (dấu phẩy là thập phân)
        except ValueError:
            p = 0.0
        a = num(x.get("amt"))
        if p > 0:
            amount, pct_in = round(total * p / 100), p
        elif a > 0:
            amount, pct_in = a, None
        else:
            continue
        amount = max(0.0, min(float(amount), total - cum))
        if pct_in is None or abs(amount - round(total * pct_in / 100)) > 0.5:      # nhập số tiền, hoặc bị chặn vì vượt tổng -> % theo số tiền thật
            p = amount / total * 100 if total else 0
        cum += amount
        reason = str(x.get("reason", "") or "").strip()
        out.append({"kind": "adv", "label": f"TẠM ỨNG {fmt_pct(p)}% {reason}".strip(), "amount": amount,
                    "paid": bool(x.get("paid")), "pct_in": pct_in})
    if not out:
        return []
    rest = total - cum
    final = str(rc.get("final_reason") or "").strip() or FINAL_REASON
    out.append({"kind": "final", "label": f"THANH TOÁN {fmt_pct(rest / total * 100 if total else 0)}% {final}",
                "amount": rest, "paid": False, "pct_in": None})
    return out


def tail_rows(data):
    """Các dòng dưới TỔNG TIỀN: [(nhãn, số tiền, đã thanh toán?, kiểu)]."""
    if data.get("installments"):
        return [(x["label"], x["amount"], x["paid"], x["kind"]) for x in data["installments"]]
    return [(data["adv_label"], data["advance"], data["paid"], "legacy_adv"),
            ("THANH TOÁN PHẦN CÒN LẠI", data["total"] - data["advance"], False, "legacy_rest")]


# ----------------------------------------------------------------------------- gom dữ liệu
def _common(order, settings, rows):
    cu, rc = order["customer"], order.get("receipt", {})
    S = settings.get("receipt", {})
    total = sum(x["amount"] for x in rows)
    adv_txt = str(rc.get("advance", "") or "").strip()
    adv = float("".join(ch for ch in adv_txt if ch.isdigit()) or 0)
    pct50 = adv <= 0
    if pct50:
        adv = round(total / 2)
    name = (cu.get("name") or "").upper()
    code = rc.get("code") or "HR"
    inst = build_installments(rc, total)
    if inst:                      # nhiều đợt ứng: "advance" = tổng các đợt ứng (để các biểu mẫu khác vẫn đúng)
        adv, pct50 = sum(x["amount"] for x in inst if x["kind"] == "adv"), False
    return {
        "installments": inst,
        "rows": rows, "total": total, "advance": min(adv, total), "adv_label": "TẠM ỨNG 50%" if pct50 else "TẠM ỨNG",
        "pct50": pct50, "paid": bool(rc.get("paid")), "code": code, "name": name,
        "mid_line": (rc.get("title") or "").strip() or f"{code} - {name}",
        "phone": cu.get("phone", ""), "address": cu.get("address", ""), "handover": rc.get("handover", ""),
        "priority": rc.get("priority", "Tiêu Chuẩn"), "tech": rc.get("tech") or S.get("tech", ""),
        "manager": S.get("manager", "Admin"), "manager_phone": S.get("manager_phone", ""), "director": S.get("director", ""),
        "quote_days": int(S.get("quote_days", 14)), "order_days": int(S.get("order_days", 7)),
        "warranty": S.get("warranty", ""), "quote_extra": S.get("quote_extra", ""), "company": settings["company"],
    }


def _size_text(p):
    import engine
    return engine.size_text(p)


def collect(order, settings, pmap):
    """Nội thất bán sẵn."""
    r = order["result"]
    combo_of = {i["pid"]: str(i.get("combo", "")).strip() for i in order.get("items", [])}
    rows, groups = [], {}
    for l in r["lines"]:
        p = pmap.get(l["pid"], {})
        c = combo_of.get(l["pid"], "")
        if c:
            g = groups.get(c)
            if g is None:
                g = {"cat": f"COMBO {c}", "lines": [], "dai": "", "cao": "", "sau": "", "unit": "BỘ", "qty": 1,
                     "imgs": [], "price": 0.0}
                groups[c] = g
                rows.append(g)
            g["lines"].append(l["name"] + (f" x{l['qty']}" if l["qty"] > 1 else ""))
            g["price"] += l["amount"]
            g["imgs"].append((l["pid"], p.get("category", "")))
            continue
        if l.get("manual") or l.get("fee"):
            # dòng thêm tay / phụ phí: không có ảnh, kích thước (nếu có) ghi vào phần diễn giải
            desc = l["name"] + (("\n" + l["size"]) if l.get("size") else "")
            rows.append({"cat": l["name"], "lines": desc.split("\n"), "dai": "", "cao": "", "sau": "",
                         "unit": l.get("unit") or ("gói" if l.get("fee") else "BỘ"), "qty": l["qty"],
                         "price": l["unit_price"], "imgs": []})
            continue
        cat = p.get("category") or l["name"]
        w, h, d = (str(p.get(k) or "").replace(" ", "") for k in ("w", "h", "d"))
        bed = "giuong" in strip_acc(cat) and "boc" not in strip_acc(cat)
        dai, sau = (d, w) if bed else (w, d)
        desc = l["name"] + (("\n" + p["desc"]) if p.get("desc") else "")
        if l.get("size") is not None and l["size"] != _size_text(p):
            # kích thước đã sửa tay: ghi theo chữ người dùng nhập
            desc = l["name"] + ("\n" + l["size"] if l["size"] else "") + (("\n" + p["desc"]) if p.get("desc") else "")
            dai = h = sau = ""
        rows.append({"cat": cat, "lines": desc.split("\n"), "dai": dai, "cao": h, "sau": sau,
                     "unit": l.get("unit") or "BỘ", "qty": l["qty"], "price": l["unit_price"],
                     "imgs": [(l["pid"], p.get("category", ""))]})
    for g in rows:
        g["kl"] = 1.0
        g["amount"] = g["price"] * g["qty"]
    ship = r["ship"]["fee"] + r["assembly"] + r["moisture"]
    if ship > 0:
        parts = ["giao lắp tại nhà" if r["assembly"] > 0 else "giao hàng tại nhà"]
        if r["moisture"] > 0:
            parts.append("ván chống ẩm")
        rows.append({"cat": "Phụ phí giao lắp", "lines": [", ".join(parts)], "dai": "", "cao": "", "sau": "",
                     "unit": "gói", "qty": 1, "price": ship, "amount": ship, "kl": 1.0, "imgs": []})
    return _common(order, settings, rows)


def collect_wood(order, settings):
    """Hàng gỗ: kích thước, đơn vị, đơn giá nhập tay – công thức như file Excel mẫu."""
    rows = []
    for l in order.get("wood_lines", []):
        kl, amount = calc_line(l.get("unit"), l.get("dai"), l.get("cao"), l.get("qty", 1), l.get("price", 0))
        rows.append({"cat": l.get("cat", ""), "lines": str(l.get("desc", "")).split("\n"), "dai": dim_txt(l.get("dai")),
                     "cao": dim_txt(l.get("cao")), "sau": dim_txt(l.get("sau")), "unit": l.get("unit", ""),
                     "kl": kl, "qty": num(l.get("qty", 1)), "price": num(l.get("price", 0)), "amount": amount, "imgs": [],
                     "raw": l})
    return _common(order, settings, rows)


# ----------------------------------------------------------------------------- vẽ ảnh
class Pg:
    def __init__(self, W, H):
        self.W = W
        self.img = Image.new("RGB", (W, H), "white")
        self.d = ImageDraw.Draw(self.img)

    def wrap(self, text, f, maxw):
        out = []
        for para in str(text).split("\n"):
            cur = ""
            for w in para.split():
                t = (cur + " " + w).strip()
                if self.d.textlength(t, font=f) <= maxw or not cur:
                    cur = t
                else:
                    out.append(cur)
                    cur = w
            out.append(cur)
        return out

    def grow(self, y):
        """Chỉ cấp thêm bộ nhớ khi cần (tránh tạo ảnh khổng lồ ngay từ đầu)."""
        if y > self.img.height - 700:
            new = Image.new("RGB", (self.W, int(y) + 3000), "white")
            new.paste(self.img, (0, 0))
            self.img.close()
            self.img = new
            self.d = ImageDraw.Draw(new)

    def box(self, b, fill=None, w=2, outline=INK):
        self.grow(b[3])
        x0, y0, x1, y1 = [int(round(v)) for v in b]
        if fill:
            self.d.rectangle([x0, y0, x1, y1], fill=fill)
        if outline:
            self.d.rectangle([x0, y0, x1, y1], outline=outline, width=w)

    def text(self, b, text, size=20, bold=False, color=INK, align="center", valign="middle", pad=8,
             sans=False, spacing=1.2, fit=True):
        x0, y0, x1, y1 = b
        self.grow(y1)
        size = int(size)
        while True:
            f = F(size, bold, sans)
            ls = self.wrap(text, f, x1 - x0 - 2 * pad)
            lh = int(size * spacing)
            if not fit or len(ls) * lh <= (y1 - y0) or size <= 9:
                break
            size -= 1
        total = len(ls) * lh
        y = y0 + pad // 2 if valign == "top" else y0 + (y1 - y0 - total) / 2
        for ln in ls:
            if align == "center":
                self.d.text(((x0 + x1) / 2, y), ln, font=f, fill=color, anchor="ma")
            elif align == "right":
                self.d.text((x1 - pad, y), ln, font=f, fill=color, anchor="ra")
            else:
                self.d.text((x0 + pad, y), ln, font=f, fill=color, anchor="la")
            y += lh
        return y

    def paste(self, path, b, align="center", upscale=1.0):
        try:
            with Image.open(path) as src:
                t = src.convert("RGBA")
        except Exception:
            return False
        self.grow(b[3])
        bw, bh = int(b[2] - b[0]), int(b[3] - b[1])
        k = min(bw / max(t.width, 1), bh / max(t.height, 1), upscale)       # thu nhỏ vừa ô; phóng tối đa `upscale` lần
        if abs(k - 1) > 0.02:
            t = t.resize((max(1, int(t.width * k)), max(1, int(t.height * k))), Image.LANCZOS)
        x = int(b[0] + (bw - t.width) / 2) if align == "center" else int(b[0])
        y = int(b[1] + (bh - t.height) / 2)
        self.img.paste(t, (x, y), t)
        return True


def logo_path():
    return store.resource("assets/logo.png")


def _finish(pg, y, path, margin, min_ratio=1.414):
    H = max(int(pg.W * min_ratio), int(y + margin))
    img = pg.img.crop((0, 0, pg.W, min(H, pg.img.height)))
    pg.img.close()
    if path.lower().endswith((".jpg", ".jpeg")):
        img.save(path, "JPEG", quality=94, optimize=True, dpi=(200, 200))
    else:
        img.save(path)
    return path


def _xs(units, W, M):
    colpx = [units_px(u) for u in units]
    S = (W - 2 * M) / sum(colpx)
    xs = [M]
    for c in colpx:
        xs.append(xs[-1] + c * S)
    return xs, S


# ============================================================================ FORM B: Đơn đặt hàng (kiêm biên bản nghiệm thu)
FORM_BASE = [14.1, 34.1, 56.7, 15.6, 12.7, 12.7, 14.3, 22.6, 18.7, 25.3, 36.9, 54.3]
FORM_FLEX = {2: 34, 11: 26}
FORM_TOP_PT = [20, 24.75, 22.5, 24, 26.25]


def form_units(data):
    rows = data["rows"]
    full = {0: ["STT"] + [str(i) for i in range(1, len(rows) + 1)],
            3: ["Dài"] + [r["dai"] for r in rows], 4: ["Cao"] + [r["cao"] for r in rows], 5: ["Sâu"] + [r["sau"] for r in rows],
            6: ["ĐVT"] + [str(r["unit"]).lower() for r in rows], 7: ["Khối Lượng"] + [f"{r['kl']:.2f}" for r in rows],
            8: ["Số Lượng"] + [f"{r['qty']:g}" for r in rows], 9: ["Đơn Giá"] + [mc(r["price"]) for r in rows],
            10: ["Thành Tiền", mc(data["total"])] + [mc(t[1]) for t in tail_rows(data)]}
    words = {1: [r["cat"] for r in rows], 2: ["\n".join(r["lines"]) for r in rows], 11: ["Ghi Chú", "Đã Thanh Toán"]}
    base = list(FORM_BASE)
    if any(quote_imgs(r) for r in rows):
        base[11] = 84          # chừa chỗ cho tối đa 3 ảnh sản phẩm trong cột Ghi Chú
    return fit_columns(base, full, words, FORM_FLEX, 20, bold=(10,), group=[(3, 5, "Kích Thước (mm)")])


def form_row_heights(data, u):
    hs = []
    for r in data["rows"]:
        desc = "\n".join(r["lines"])
        hs.append(max(132 if quote_imgs(r) else 87, cell_h(desc, 20, False, u[2]), cell_h(r["cat"], 20, False, u[1])))
    return hs


def _draw_form(data):
    """Vẽ toàn bộ biên lai lên 1 tấm dài (cao đủ cho mọi số dòng). Trả về (pg, y_cuối, lề, mốc ngắt trang)."""
    u = form_units(data)
    W, M = 2000, 50
    xs, S = _xs(u, W, M)
    pt = lambda v: v * 96 / 72 * S
    fs = lambda v: max(10, int(round(v * 96 / 72 * S)))
    pg = Pg(W, int(pt(sum(FORM_TOP_PT)) + sum(pt(h) for h in form_row_heights(data, u)) + 7000))
    marks = {"rows": []}
    y = M
    co = data["company"]
    hh = pt(sum(FORM_TOP_PT))
    lg = logo_path()
    if os.path.exists(lg):
        pg.paste(lg, (xs[1], y + hh * 0.05, xs[3], y + hh * 0.95), align="left")
    box = (xs[5], y, xs[12], y + hh)
    lines = [(co["name"], True, 16), (f"MST: {co['tax']}", False, 13), (f"Địa chỉ: {co['address']}", False, 13),
             (f"Hotline: {co['phone'].split('(')[0].strip()}", False, 13)]
    ty = y + (hh - sum(int(fs(s) * 1.25) for _, _, s in lines)) / 2
    for t, b, s in lines:
        pg.d.text(((box[0] + box[2]) / 2, ty), t, font=F(fs(s), b), fill=INK, anchor="ma")
        ty += int(fs(s) * 1.25)
    y += hh

    def line(h_pt, text, size, bold=False, align="left", color=INK):
        nonlocal y
        h = pt(h_pt)
        pg.text((xs[0], y, xs[12], y + h), text, fs(size), bold, color, align)
        y += h

    line(48.75, "ĐƠN ĐẶT HÀNG ( KIÊM BIÊN BẢN NGHIỆM THU )", 26, True, "center")
    line(35.25, f"MÃ ĐƠN HÀNG : {data['mid_line']}", 22, False, "center")
    line(30, f"Quản Lí Đơn Hàng : {data['manager']} - Số điện thoại:  {data['manager_phone']}", 20)
    line(30, f"Phụ Trách Kỹ Thuật : {data['tech']}", 20)
    line(30, "THÔNG TIN KHÁCH HÀNG", 20, True)
    line(30, f"Tên Khách Hàng: {data['name']}", 20)
    tot_u = sum(u)
    adr_h = max(30, cell_h("Địa Chỉ Giao Hàng : " + data["address"], 20, False, tot_u))
    line(adr_h, f"Địa Chỉ Giao Hàng : {data['address']}", 20)
    line(30, f"Số Điện Thoại : {data['phone']}", 20)
    h = pt(33.75)
    pg.box((xs[0], y, xs[7], y + h))
    pg.text((xs[0], y, xs[7], y + h), f"Dự Kiến Bàn Giao : {data['handover']}", fs(20), True, RED, "left")
    pg.box((xs[7], y, xs[10], y + h))
    pg.text((xs[7], y, xs[10], y + h), "ĐÁNH GIÁ MỨC ĐỘ ƯU TIÊN", fs(20), True)
    bw = (xs[12] - xs[10]) / 3
    for i, nm in enumerate(("Ưu Tiên", "Tiêu Chuẩn", "Linh Hoạt")):
        b = (xs[10] + i * bw, y, xs[10] + (i + 1) * bw, y + h)
        pg.box(b, fill=YELLOW if nm == data["priority"] else None)
        pg.text(b, nm, fs(14), True, INK, sans=True, pad=2)
    y += h
    h1 = h2 = pt(30)
    marks["hdr0"] = y
    hd = lambda b, t: (pg.box(b), pg.text(b, t, fs(20), False, pad=4))
    hd((xs[0], y, xs[1], y + h1 + h2), "STT")
    hd((xs[1], y, xs[2], y + h1 + h2), "Hạng Mục")
    hd((xs[2], y, xs[3], y + h1 + h2), "Diễn Giải")
    hd((xs[3], y, xs[6], y + h1), "Kích Thước (mm)")
    for i, t in enumerate(("Dài", "Cao", "Sâu")):
        hd((xs[3 + i], y + h1, xs[4 + i], y + h1 + h2), t)
    for i, t in ((6, "ĐVT"), (7, "Khối Lượng"), (8, "Số Lượng"), (9, "Đơn Giá"), (10, "Thành Tiền"), (11, "Ghi Chú")):
        hd((xs[i], y, xs[i + 1], y + h1 + h2), t)
    y += h1 + h2
    marks["hdr1"] = y
    for n, (r, hp) in enumerate(zip(data["rows"], form_row_heights(data, u)), 1):
        need = pt(hp)
        marks["rows"].append((y, y + need))
        cells = [str(n), r["cat"], "\n".join(r["lines"]), r["dai"], r["cao"], r["sau"], str(r["unit"]).lower(),
                 f"{r['kl']:.2f}", f"{r['qty']:g}", mc(r["price"]), mc(r["amount"]), ""]
        for i, t in enumerate(cells):
            b = (xs[i], y, xs[i + 1], y + need)
            pg.box(b)
            pg.text(b, t, fs(20), False, pad=6)
        imgs = quote_imgs(r)
        if imgs:
            gb = (xs[11], y, xs[12], y + need)
            k = min(len(imgs), 3)
            cw = (gb[2] - gb[0] - 10) / k
            for j, (pid, cap) in enumerate(imgs[:k]):
                cx0 = gb[0] + 5 + j * cw
                pg.paste(store.image_path(pid), (cx0 + 3, y + 8, cx0 + cw - 3, y + need - fs(12) * 2.6), upscale=1.8)
                pg.text((cx0, y + need - fs(12) * 2.5, cx0 + cw, y + need - 3), cap, fs(11), False, INK, pad=1)
        y += need

    def total_row(h_pt, label, val, color, fill=None, note=""):
        nonlocal y
        h = pt(h_pt)
        pg.box((xs[0], y, xs[10], y + h), fill=fill)
        pg.text((xs[0], y, xs[10], y + h), label, fs(20), True, color)
        pg.box((xs[10], y, xs[11], y + h), fill=fill)
        pg.text((xs[10], y, xs[11], y + h), mc(val), fs(20), True, color, "right", pad=6)
        pg.box((xs[11], y, xs[12], y + h))
        if note:
            pg.text((xs[11], y, xs[12], y + h), note, fs(20), False)
        y += h

    marks["tail0"] = y
    total_row(38.25, "TỔNG TIỀN", data["total"], RED, YELLOW)
    for label, amount, paid, kind in tail_rows(data):
        total_row(42 if kind in ("final", "legacy_rest") else 42.75, label, amount, BLUE, note="Đã Thanh Toán" if paid else "")
    y += pt(6)
    txt = form_notes(data)
    nh = pt(cell_h(txt, 18, False, tot_u, pad=10))
    pg.text((xs[0], y, xs[12], y + nh), txt, fs(18), False, INK, "left", "top", fit=False)
    y += nh + pt(14)
    for t, b in (("XÁC NHẬN NGHIỆM THU & BÀN GIAO", True), ("ĐÃ NHẬN ĐỦ HÀNG", True),
                 ("Khách hàng xác nhận đã kiểm tra số lượng , kích thước, tình trạng hoàn thiện sản phẩm và cho đánh giá về dịch vụ.", False)):
        h = pt(27)
        x = xs[0] + 8 + (pt(30) if t.startswith("ĐÃ") else 0)
        pg.d.text((x, y + h / 2), t, font=F(fs(19 if b else 18), b), fill=INK, anchor="lm")
        y += h
    for t in ("Ghi chú nghiệm thu :", ""):
        h = pt(23)
        f = F(fs(18))
        x0 = xs[0] + 8
        pg.d.text((x0, y + h / 2), t, font=f, fill=INK, anchor="lm")
        x = x0 + pg.d.textlength(t, font=f)
        dots = "." * int((xs[12] - x - 10) / max(pg.d.textlength(".", font=f), 1))
        pg.d.text((x, y + h / 2), dots, font=f, fill=INK, anchor="lm")
        y += h
    h = pt(35.25)
    pg.d.text((xs[0] + 8, y + h / 2), "Ngày nghiệm thu :        /         /        ", font=F(fs(18)), fill=INK, anchor="lm")
    y += h
    sig = [(0, 2, "KỸ THUẬT\n( Ký xác nhận đã đọc đơn hàng và yêu cầu sản phẩm )"),
           (3, 6, "XƯỞNG ( QC )\n( Xác nhận chất lượng sản phẩm)"), (6, 9, "NGƯỜI GIAO HÀNG"),
           (9, 11, "QUÝ KHÁCH HÀNG\n( Xác nhận nhận hàng )")]
    for a, b, t in sig:
        pg.text((xs[a], y, xs[b], y + pt(60)), t, fs(17), True, INK, "center", "top")
    y += pt(26.25) * 3 + pt(160)
    return pg, y, M, marks


def render_form_jpg(data, path):
    pg, y, M, _ = _draw_form(data)
    return _finish(pg, y, path, M)


def _paginate(marks, y_end, ph, margin):
    """Chia các dòng vào các trang A4 (không cắt ngang dòng, lặp lại tiêu đề bảng ở trang sau,
    phần tổng tiền + ghi chú + chữ ký luôn đi liền nhau và không đứng 1 mình trên trang)."""
    h0, h1, t0 = marks["hdr0"], marks["hdr1"], marks["tail0"]
    hdr_h = h1 - h0
    avail = ph - 70
    pages, cur, used, nrows = [], [(0, h1)], h1, 0
    for r0, r1 in marks["rows"]:
        if used + (r1 - r0) > avail and nrows:
            pages.append(cur)
            cur, used, nrows = [("hdr", h0, h1)], margin + hdr_h, 0
        cur.append((r0, r1))
        used += r1 - r0
        nrows += 1
    tail_h = y_end - t0
    if used + tail_h > avail:
        if nrows > 1:                                   # kéo dòng cuối sang trang tổng tiền để trang đó không trống
            last = cur.pop()
            pages.append(cur)
            cur, used = [("hdr", h0, h1), last], margin + hdr_h + (last[1] - last[0])
        else:
            pages.append(cur)
            cur, used = [], margin
    cur.append(("tail", t0, y_end))
    pages.append(cur)
    return pages


def render_form_pdf(data, path):
    """PDF chuẩn in A4: toàn bộ biên lai (kèm ảnh sản phẩm) trong 1 file, tự chia trang nếu đơn dài."""
    pg, y_end, M, marks = _draw_form(data)
    W = pg.W
    PH = int(round(W * 297 / 210))
    y_end = int(min(pg.img.height, y_end + M))
    pages = _paginate(marks, y_end, PH, M)
    out = []
    for i, items in enumerate(pages, 1):
        im = Image.new("RGB", (W, PH), "white")
        yy = M if i > 1 else 0
        for it in items:
            if isinstance(it[0], str):
                s0, s1 = int(it[1]) - 2, int(it[2]) + 2
            else:
                s0, s1 = (0, int(it[1])) if it[0] == 0 else (int(it[0]) - 2, int(it[1]) + 2)
            s1 = min(s1, pg.img.height)
            im.paste(pg.img.crop((0, max(0, s0), W, s1)), (0, int(yy)))
            yy += s1 - max(0, s0)
        if len(pages) > 1:
            d = ImageDraw.Draw(im)
            d.text((W / 2, PH - 38), f"Trang {i}/{len(pages)}", font=F(22, False, True), fill=INK, anchor="mm")
        out.append(im)
    pg.img.close()
    out[0].save(path, "PDF", resolution=W / 8.2677, save_all=True, append_images=out[1:], quality=92)
    for im in out:
        im.close()
    return path


def form_notes(data):
    notes = ["Lưu ý:", f"* Bảng báo giá có hiệu lực {data['order_days']:02d} ngày kể từ ngày gửi báo giá", data["warranty"]]
    return "\n".join(n for n in notes if n)


# ============================================================================ FORM A: Bảng báo giá
QUOTE_BASE = [6.2, 18.9, 68, 8.6, 8.6, 8.6, 7.0, 8.4, 17.4, 17.4, 36.2]
QUOTE_FLEX = {2: 34, 10: 26}


def quote_units(data):
    rows = data["rows"]
    full = {0: ["Stt"] + [str(i) for i in range(1, len(rows) + 1)],
            3: ["Dài"] + [r["dai"] for r in rows], 4: ["Cao"] + [r["cao"] for r in rows], 5: ["Sâu"] + [r["sau"] for r in rows],
            6: ["ĐVT"] + [str(r["unit"]).upper() for r in rows], 7: ["lượng"] + [f"{r['qty']:g}" for r in rows],
            8: ["Đơn Giá"] + [mc(r["price"]) for r in rows], 9: ["Thành Tiền", mc(data["total"]), mc(data["advance"]), mc(data["total"] - data["advance"])]}
    words = {1: [r["cat"] for r in rows] + ["Hạng mục"], 2: ["\n".join(r["lines"]) for r in rows], 10: ["Ghi chú", "Đã Thanh Toán"]}
    return fit_columns(QUOTE_BASE, full, words, QUOTE_FLEX, 16, bold=(9,), group=[(3, 5, "Kích thước (mm)")])


def quote_imgs(r):
    return [(pid, cap) for pid, cap in r["imgs"] if os.path.exists(store.image_path(pid))]


def quote_row_heights(data, u):
    hs = []
    for r in data["rows"]:
        hs.append(max(112 if quote_imgs(r) else 84, cell_h("\n".join(r["lines"]), 16, False, u[2]), cell_h(r["cat"], 16, False, u[1])))
    return hs


def render_quote_jpg(data, path):
    u = quote_units(data)
    W, M = 1700, 60
    xs, S = _xs(u, W, M)
    pt = lambda v: v * 96 / 72 * S
    fs = lambda v: max(10, int(round(v * 96 / 72 * S)))
    TW = xs[11] - xs[0]
    pg = Pg(W, 3800)
    y = M
    co = data["company"]
    hh = pt(84)
    pg.box((xs[0], y, xs[3], y + hh))
    lg = logo_path()
    if os.path.exists(lg):
        pg.paste(lg, (xs[0] + 25, y + 12, xs[3] - 60, y + hh - 12), align="left")
    pg.box((xs[3], y, xs[11], y + hh))
    pg.text((xs[3], y, xs[11], y + hh), "\n".join([co["name"], f"MST: {co['tax']}", f"Địa chỉ: {co['address']}", f"Liên Hệ: {co['phone']}"]),
            fs(17), True, INK, "center", spacing=1.3)
    y += hh

    def full(h_pt, text, size, bold=True, color=INK, align="left"):
        nonlocal y
        h = pt(h_pt)
        pg.box((xs[0], y, xs[11], y + h))
        pg.text((xs[0], y, xs[11], y + h), text, fs(size), bold, color, align, fit=False)
        y += h

    full(40, data["mid_line"], 24, True, INK, "center")
    full(31, f"Tên Khách hàng: {data['name']} - SĐT: {data['phone']}", 16)
    full(31, f"QLDH: {data['manager']}", 16)
    full(31, f"Kỹ Thuật: {data['tech']}", 16)
    bg = f"Bàn Giao : Tại {data['address']}" if data["address"] else "Bàn Giao :"
    full(max(33, cell_h(bg, 16, True, sum(u))), bg, 16, True, RED)
    h1 = h2 = pt(26)
    hd = lambda b, t, s=16: (pg.box(b, fill=SKY), pg.text(b, t, fs(s), True, INK, pad=3))
    for i, t in ((0, "Stt"), (1, "Hạng mục"), (2, "Diễn giải"), (6, "ĐVT"), (7, "Số lượng"), (8, "Đơn Giá"), (9, "Thành Tiền"), (10, "Ghi chú")):
        hd((xs[i], y, xs[i + 1], y + h1 + h2), t)
    hd((xs[3], y, xs[6], y + h1), "Kích thước (mm)", 14)
    for i, t in enumerate(("Dài", "Cao", "Sâu")):
        hd((xs[3 + i], y + h1, xs[4 + i], y + h1 + h2), t, 14)
    y += h1 + h2
    for n, (r, hp) in enumerate(zip(data["rows"], quote_row_heights(data, u)), 1):
        need = pt(hp)
        cells = [str(n), r["cat"], "\n".join(r["lines"]), r["dai"], r["cao"], r["sau"], str(r["unit"]).upper(), f"{r['qty']:g}",
                 mc(r["price"]), mc(r["amount"])]
        for i, t in enumerate(cells):
            b = (xs[i], y, xs[i + 1], y + need)
            pg.box(b)
            pg.text(b, t, fs(16), False, RED if i == 9 else INK, pad=6)
        gb = (xs[10], y, xs[11], y + need)
        pg.box(gb)
        imgs = quote_imgs(r)
        if imgs:
            k = min(len(imgs), 3)
            cw = (gb[2] - gb[0] - 10) / k
            for j, (pid, cap) in enumerate(imgs[:k]):
                cx0 = gb[0] + 5 + j * cw
                pg.paste(store.image_path(pid), (cx0 + 3, y + 8, cx0 + cw - 3, y + need - 30), upscale=1.8)
                pg.text((cx0, y + need - 28, cx0 + cw, y + need - 3), cap, fs(10), False, INK, pad=1)
        y += need

    def total_row(label, val, color, note=""):
        nonlocal y
        h = pt(30)
        pg.box((xs[0], y, xs[9], y + h), fill=SKY_LIGHT)
        pg.text((xs[0], y, xs[9], y + h), label, fs(17), True, color)
        pg.box((xs[9], y, xs[10], y + h), fill=SKY_LIGHT)
        pg.text((xs[9], y, xs[10], y + h), mc(val), fs(17), True, color, pad=6)
        pg.box((xs[10], y, xs[11], y + h), fill=SKY_LIGHT)
        if note:
            pg.text((xs[10], y, xs[11], y + h), note, fs(14), False)
        y += h

    total_row("TỔNG CỘNG", data["total"], BLUE)
    total_row(data["adv_label"], data["advance"], RED, "Đã Thanh Toán" if data["paid"] else "")
    total_row("THANH TOÁN KHI BÀN GIAO", data["total"] - data["advance"], RED)
    y += pt(14)
    txt = quote_notes(data)
    nh = pt(cell_h(txt, 14, False, sum(u), pad=10))
    pg.text((xs[0], y, xs[11], y + nh), txt, fs(14), False, INK, "left", "top", pad=4, fit=False)
    y += nh + pt(30)
    pg.text((xs[2] - 150, y, xs[2] + 300, y + 40), "QUÝ KHÁCH HÀNG", fs(16), True)
    pg.text((xs[6], y, xs[11], y + pt(60)), f"{co['name']}\nGIÁM ĐỐC", fs(16), True, INK, "center", "top")
    y += pt(60) + pt(120)
    pg.text((xs[6], y, xs[11], y + 40), data["director"], fs(16), True)
    y += 40
    return _finish(pg, y, path, M)


def quote_notes(data):
    notes = ["Lưu ý:", f"* Bảng báo giá có hiệu lực {data['quote_days']} ngày kể từ ngày gửi báo giá", data["quote_extra"], data["warranty"]]
    return "\n".join(n for n in notes if n)


# ============================================================================ EXCEL
def _xl():
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    return Workbook, Alignment, Border, Font, PatternFill, Side


def _put(ws, rng, value=None, pt=20, bold=False, color="000000", h="center", v="center", wrap=True,
         fill=None, border=False, fmt=None, rich=None):
    Workbook, Alignment, Border, Font, PatternFill, Side = _xl()
    thin = Side(style="thin", color="000000")
    if ":" in rng:
        ws.merge_cells(rng)
        flat = [c for row in ws[rng] for c in row]
    else:
        flat = [ws[rng]]
    first = flat[0]
    for c in flat:
        if fill:
            c.fill = PatternFill("solid", fgColor=fill)
        if border:
            c.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    first.value = rich if rich is not None else value
    first.font = Font(name=FONT, size=pt, bold=bold, color=color)
    first.alignment = Alignment(horizontal=h, vertical=v, wrap_text=wrap)
    if fmt:
        first.number_format = fmt
    return first


def _rich_company(co, pt_big, pt_small):
    try:
        from openpyxl.cell.rich_text import CellRichText, TextBlock
        from openpyxl.cell.text import InlineFont
        return CellRichText(
            TextBlock(InlineFont(rFont=FONT, sz=pt_big, b=True), co["name"] + "\n"),
            TextBlock(InlineFont(rFont=FONT, sz=pt_small), f"MST: {co['tax']}\nĐịa chỉ: {co['address']}\nHotline: {co['phone'].split('(')[0].strip()}"))
    except Exception:
        return None


def _add_img(ws, path, col0, row0, w, h, dx=0, dy=0):
    from openpyxl.drawing.image import Image as XLImage
    from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, OneCellAnchor
    from openpyxl.drawing.xdr import XDRPositiveSize2D
    img = XLImage(path)
    img.width, img.height = int(w), int(h)
    img.anchor = OneCellAnchor(_from=AnchorMarker(col=col0, colOff=int(dx * 9525), row=row0, rowOff=int(dy * 9525)),
                               ext=XDRPositiveSize2D(int(w * 9525), int(h * 9525)))
    ws.add_image(img)


def _logo_xl(ws, col0, row0, max_w, max_h, dx=8, dy=6):
    lg = logo_path()
    if not os.path.exists(lg):
        return
    try:
        with Image.open(lg) as im0:
            iw, ih = im0.size
    except Exception:
        return
    s = min(max_w / iw, max_h / ih)
    _add_img(ws, lg, col0, row0, iw * s, ih * s, dx, dy)


def _page_setup(ws, last_row, last_col):
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.properties import PageSetupProperties
    ws.page_setup.orientation = "portrait"
    ws.page_setup.paperSize = 9
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = ws.page_margins.bottom = 0.4
    ws.print_options.horizontalCentered = True
    ws.print_area = f"A1:{get_column_letter(last_col)}{last_row}"
    ws.sheet_view.showGridLines = False


def xlsx_form(data, path):
    from openpyxl.utils import get_column_letter as CL
    Workbook = _xl()[0]
    u = form_units(data)
    hs = form_row_heights(data, u)
    wb = Workbook()
    ws = wb.active
    ws.title = "Đơn đặt hàng"
    for i, w in enumerate(u, 1):
        ws.column_dimensions[CL(i)].width = round(w, 1)
    for i, h in enumerate(FORM_TOP_PT, 1):
        ws.row_dimensions[i].height = h
    co = data["company"]
    rich = _rich_company(co, 16, 13)
    _put(ws, "F1:L5", f"{co['name']}\nMST: {co['tax']}\nĐịa chỉ: {co['address']}\nHotline: {co['phone'].split('(')[0].strip()}",
         13, rich=rich)
    hh = sum(FORM_TOP_PT) * 96 / 72
    _logo_xl(ws, 1, 0, units_px(u[1]) + units_px(u[2]) * 0.4, hh * 0.9)

    def row(r, h, rng, text, pt=20, bold=False, align="left", color="000000"):
        ws.row_dimensions[r].height = h
        _put(ws, rng, text, pt, bold, color, align)

    row(6, 48.75, "A6:L6", "ĐƠN ĐẶT HÀNG ( KIÊM BIÊN BẢN NGHIỆM THU )", 26, True, "center")
    row(7, 35.25, "A7:L7", f"MÃ ĐƠN HÀNG : {data['mid_line']}", 22, False, "center")
    row(8, 30, "A8:L8", f"Quản Lí Đơn Hàng : {data['manager']} - Số điện thoại:  {data['manager_phone']}")
    row(9, 30, "A9:L9", f"Phụ Trách Kỹ Thuật : {data['tech']}")
    row(10, 30, "A10:L10", "THÔNG TIN KHÁCH HÀNG", 20, True)
    row(11, 30, "A11:L11", f"Tên Khách Hàng: {data['name']}")
    row(12, max(30, cell_h("Địa Chỉ Giao Hàng : " + data["address"], 20, False, sum(u))), "A12:L12", f"Địa Chỉ Giao Hàng : {data['address']}")
    row(13, 30, "A13:L13", f"Số Điện Thoại : {data['phone']}")
    ws.row_dimensions[14].height = 33.75
    _put(ws, "A14:G14", f"Dự Kiến Bàn Giao : {data['handover']}", 20, True, "FF0000", "left", border=True)
    _put(ws, "H14:J14", "ĐÁNH GIÁ MỨC ĐỘ ƯU TIÊN", 20, True, border=True)
    pr = "     ".join(("☑ " if n == data["priority"] else "☐ ") + n for n in ("Ưu Tiên", "Tiêu Chuẩn", "Linh Hoạt"))
    _put(ws, "K14:L14", pr, 14, True, fill="FFFF00", border=True)
    ws.row_dimensions[15].height = ws.row_dimensions[16].height = 30
    for rng, t in (("A15:A16", "STT"), ("B15:B16", "Hạng Mục"), ("C15:C16", "Diễn Giải"), ("D15:F15", "Kích Thước (mm)"),
                   ("D16", "Dài"), ("E16", "Cao"), ("F16", "Sâu"), ("G15:G16", "ĐVT"), ("H15:H16", "Khối Lượng"),
                   ("I15:I16", "Số Lượng"), ("J15:J16", "Đơn Giá"), ("K15:K16", "Thành Tiền"), ("L15:L16", "Ghi Chú")):
        _put(ws, rng, t, 20, False, border=True)
    r0 = 17
    for i, (r, hp) in enumerate(zip(data["rows"], hs)):
        n = r0 + i
        ws.row_dimensions[n].height = hp
        unit = str(r["unit"]).lower()
        _put(ws, f"A{n}", i + 1, border=True)
        _put(ws, f"B{n}", r["cat"], border=True)
        _put(ws, f"C{n}", "\n".join(r["lines"]), border=True)
        for col, k in (("D", "dai"), ("E", "cao"), ("F", "sau")):
            _put(ws, f"{col}{n}", dim_val(r[k]) if r[k] != "" else None, border=True)
        _put(ws, f"G{n}", unit, border=True)
        if unit in ("m2", "md"):
            _put(ws, f"H{n}", f'=IF(G{n}="m2",D{n}*E{n}/10^6,D{n}/1000)', border=True, fmt="0.00")
        else:
            _put(ws, f"H{n}", 1, border=True, fmt="0.00")
        _put(ws, f"I{n}", r["qty"], border=True)
        _put(ws, f"J{n}", r["price"], border=True, fmt="#,##0")
        _put(ws, f"K{n}", f'=IF(OR(G{n}="bộ",G{n}="chuyến",G{n}="cái"),I{n}*J{n},H{n}*I{n}*J{n})', border=True, fmt="#,##0")
        imgs = quote_imgs(r)[:3]
        _put(ws, f"L{n}", ("   ".join(c for _, c in imgs) if imgs else None), 9, border=True, v="bottom")
        if imgs:
            from PIL import Image as PI
            lpx = units_px(u[11])
            cw = (lpx - 10) / len(imgs)
            maxh = hp * 96 / 72 - 40
            for j, (pid, _c) in enumerate(imgs):
                try:
                    with PI.open(store.image_path(pid)) as im1:
                        iw, ih = im1.size
                except Exception:
                    continue
                sc = min((cw - 6) / iw, maxh / ih, 1.8)
                _add_img(ws, store.image_path(pid), 11, n - 1, iw * sc, ih * sc, 5 + j * cw + (cw - 6 - iw * sc) / 2, 6)
    last = r0 + max(len(data["rows"]), 1) - 1
    t = last + 1
    tails = tail_rows(data)
    rows_x = [(38.25, "TỔNG TIỀN ", "FF0000", "FFFF00", "total", 0, False)]
    rows_x += [(42 if kind in ("final", "legacy_rest") else 42.75, label, "0070C0", None, kind, amount, paid)
               for label, amount, paid, kind in tails]
    for k, (h, label, color, fill, kind, amount, paid) in enumerate(rows_x):
        n = t + k
        ws.row_dimensions[n].height = h
        _put(ws, f"A{n}:J{n}", label, 20, True, color, fill=fill, border=True)
        if kind == "total":
            f = f"=SUM(K{r0}:K{last})"
        elif kind == "legacy_adv":
            f = f"=K{t}/2" if data["pct50"] else data["advance"]
        elif kind == "legacy_rest":
            f = f"=K{t}-K{t + 1}"
        elif kind == "adv":
            pin = data["installments"][k - 1]["pct_in"]
            f = f"=ROUND(K{t}*{pin:g}/100,0)" if pin else amount
        else:                                   # final: phần còn lại sau tất cả các đợt ứng
            f = f"=K{t}-SUM(K{t + 1}:K{t + k - 1})" if k > 1 else f"=K{t}"
        _put(ws, f"K{n}", f, 20, True, color, "right", fill=fill, border=True, fmt="#,##0")
        _put(ws, f"L{n}", "Đã Thanh Toán" if paid else None, 20, border=True)
    n = t + 1 + len(tails)
    txt = form_notes(data)
    ws.row_dimensions[n].height = cell_h(txt, 16, False, sum(u), pad=10)
    _put(ws, f"A{n}:L{n}", txt, 16, False, h="left", v="top")
    n += 1
    ws.row_dimensions[n].height = 19.5
    n += 1
    for t_, h_, b_ in (("XÁC NHẬN NGHIỆM THU & BÀN GIAO ", 29.25, True), ("             ĐÃ NHẬN ĐỦ HÀNG", 26.25, True),
                       ("Khách hàng xác nhận đã kiểm tra số lượng , kích thước, tình trạng hoàn thiện sản phẩm và cho đánh giá về dịch vụ.", 29.25, False),
                       ("Ghi chú nghiệm thu :" + "." * 300, 23.25, False), ("." * 300, 23.25, False)):
        ws.row_dimensions[n].height = h_
        _put(ws, f"A{n}:L{n}", t_, 16, b_, h="left", wrap=False)
        n += 1
    ws.row_dimensions[n].height = 35.25
    _put(ws, f"A{n}:C{n}", "Ngày nghiệm thu :        /         /        ", 16, False, h="left", wrap=False)
    n += 1
    for k in range(3):
        ws.row_dimensions[n + k].height = 26.25
    for a, b, t_ in (("A", "B", "KỸ THUẬT\n( Ký xác nhận đã đọc đơn hàng và yêu cầu sản phẩm )"), ("D", "E", "XƯỞNG ( QC )\n( Xác nhận chất lượng sản phẩm)"),
                     ("G", "H", "NGƯỜI GIAO HÀNG"), ("J", "K", "QUÝ KHÁCH HÀNG\n( Xác nhận nhận hàng )")):
        _put(ws, f"{a}{n}:{b}{n + 2}", t_, 14, True, v="top")
    n += 3
    _page_setup(ws, n, 12)
    wb.save(path)
    return path


def xlsx_quote(data, path):
    from openpyxl.utils import get_column_letter as CL
    Workbook = _xl()[0]
    u = quote_units(data)
    hs = quote_row_heights(data, u)
    wb = Workbook()
    ws = wb.active
    ws.title = "Bảng báo giá"
    for i, w in enumerate(u, 1):
        ws.column_dimensions[CL(i)].width = round(w, 1)
    co = data["company"]
    for i in range(1, 5):
        ws.row_dimensions[i].height = 21
    _put(ws, "A1:C4", None, border=True)
    _logo_xl(ws, 0, 0, sum(units_px(x) for x in u[:3]) * 0.75, 84 * 96 / 72 - 14)
    rich = _rich_company(co, 16, 16)
    _put(ws, "D1:K4", "\n".join([co["name"], f"MST: {co['tax']}", f"Địa chỉ: {co['address']}", f"Liên Hệ: {co['phone']}"]),
         16, True, border=True, rich=None)

    def row(r, h, text, pt=16, bold=True, align="left", color="000000"):
        ws.row_dimensions[r].height = h
        _put(ws, f"A{r}:K{r}", text, pt, bold, color, align, border=True)

    row(5, 40, data["mid_line"], 24, True, "center")
    row(6, 31, f"Tên Khách hàng: {data['name']} - SĐT: {data['phone']}")
    row(7, 31, f"QLDH: {data['manager']}")
    row(8, 31, f"Kỹ Thuật: {data['tech']}")
    bg = f"Bàn Giao : Tại {data['address']}" if data["address"] else "Bàn Giao :"
    row(9, max(33, cell_h(bg, 16, True, sum(u))), bg, 16, True, "left", "FF0000")
    ws.row_dimensions[10].height = ws.row_dimensions[11].height = 26
    SKYH = "9BC2E6"
    for rng, t in (("A10:A11", "Stt"), ("B10:B11", "Hạng mục"), ("C10:C11", "Diễn giải"), ("D10:F10", "Kích thước (mm)"),
                   ("D11", "Dài"), ("E11", "Cao"), ("F11", "Sâu"), ("G10:G11", "ĐVT"), ("H10:H11", "Số lượng"),
                   ("I10:I11", "Đơn Giá"), ("J10:J11", "Thành Tiền"), ("K10:K11", "Ghi chú")):
        _put(ws, rng, t, 16, True, fill=SKYH, border=True)
    r0 = 12
    kpx = units_px(u[10])
    for i, (r, hp) in enumerate(zip(data["rows"], hs)):
        n = r0 + i
        ws.row_dimensions[n].height = hp
        _put(ws, f"A{n}", i + 1, 16, border=True)
        _put(ws, f"B{n}", r["cat"], 16, border=True)
        _put(ws, f"C{n}", "\n".join(r["lines"]), 16, border=True)
        for col, k in (("D", "dai"), ("E", "cao"), ("F", "sau")):
            _put(ws, f"{col}{n}", dim_val(r[k]) if r[k] != "" else None, 16, border=True)
        _put(ws, f"G{n}", str(r["unit"]).upper(), 16, border=True)
        _put(ws, f"H{n}", r["qty"], 16, border=True)
        _put(ws, f"I{n}", r["price"], 16, border=True, fmt="#,##0")
        _put(ws, f"J{n}", f"=H{n}*I{n}", 16, color="FF0000", border=True, fmt="#,##0")
        imgs = quote_imgs(r)[:3]
        _put(ws, f"K{n}", ("   ".join(c for _, c in imgs) if imgs else None), 9, border=True, v="bottom")
        if imgs:
            from PIL import Image as PI
            cw = (kpx - 10) / len(imgs)
            maxh = hp * 96 / 72 - 40
            for j, (pid, _c) in enumerate(imgs):
                try:
                    with PI.open(store.image_path(pid)) as im1:
                        iw, ih = im1.size
                except Exception:
                    continue
                s = min((cw - 6) / iw, maxh / ih, 1.8)
                _add_img(ws, store.image_path(pid), 10, n - 1, iw * s, ih * s, 5 + j * cw + (cw - 6 - iw * s) / 2, 6)
    last = r0 + max(len(data["rows"]), 1) - 1
    t = last + 1
    for k, (label, color) in enumerate((("TỔNG CỘNG", "0070C0"), (data["adv_label"], "FF0000"), ("THANH TOÁN KHI BÀN GIAO", "FF0000"))):
        n = t + k
        ws.row_dimensions[n].height = 30
        _put(ws, f"A{n}:I{n}", label, 17, True, color, fill="DDEBF7", border=True)
        f = f"=SUM(J{r0}:J{last})" if k == 0 else (f"=J{t}/2" if data["pct50"] else data["advance"]) if k == 1 else f"=J{t}-J{t + 1}"
        _put(ws, f"J{n}", f, 17, True, color, fill="DDEBF7", border=True, fmt="#,##0")
        _put(ws, f"K{n}", "Đã Thanh Toán" if (k == 1 and data["paid"]) else None, 14, fill="DDEBF7", border=True)
    n = t + 3
    ws.row_dimensions[n].height = 10
    n += 1
    txt = quote_notes(data)
    ws.row_dimensions[n].height = cell_h(txt, 14, False, sum(u), pad=10)
    _put(ws, f"A{n}:K{n}", txt, 14, False, h="left", v="top")
    n += 2
    ws.row_dimensions[n].height = 60
    _put(ws, f"A{n}:C{n}", "QUÝ KHÁCH HÀNG", 16, True, v="top")
    _put(ws, f"G{n}:K{n}", f"{co['name']}\nGIÁM ĐỐC", 16, True, v="top")
    n += 1
    ws.row_dimensions[n].height = 120
    n += 1
    ws.row_dimensions[n].height = 30
    _put(ws, f"G{n}:K{n}", data["director"], 16, True)
    _page_setup(ws, n, 11)
    wb.save(path)
    return path


# ============================================================================ xuất tất cả
def export_form(data, stem):
    return [render_form_jpg(data, stem + ".jpg"), xlsx_form(data, stem + ".xlsx"), render_form_pdf(data, stem + ".pdf")]


def export_quote(data, stem):
    return [render_quote_jpg(data, stem + ".jpg"), xlsx_quote(data, stem + ".xlsx")]


def export_receipts(order, settings, pmap, when=None):
    """Trả về danh sách file (JPG + Excel + PDF)."""
    when = when or orderimage.now_gmt7()
    base = orderimage.target_path(settings, when)[:-4]
    if order.get("type") == "wood":
        data = collect_wood(order, settings)
        tag = "HANG ROI" if "roi" in strip_acc(order.get("wood_kind", "")) else "HANG CONG TRINH"
        return export_form(data, f"{base}_DON DAT HANG GO - {tag}")
    data = collect(order, settings, pmap)
    return export_form(data, base + "_DON DAT HANG")        # chỉ giữ biên lai kiêm nghiệm thu (đã bỏ bản báo giá)


def next_code(orders, when=None):
    """HR + tháng + ngày + số thứ tự đơn trong ngày (vd HR102608 = 26/10, đơn thứ 08)."""
    when = when or orderimage.now_gmt7()
    today = when.strftime("%Y-%m-%d")
    n = sum(1 for o in orders if str(o.get("created", "")).startswith(today)) + 1
    return f"HR {when.month}{when.day:02d}{n:02d}"
