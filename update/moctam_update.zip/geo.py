# -*- coding: utf-8 -*-
"""Định vị địa chỉ + khoảng cách đường bộ từ nhà máy. OSM (Nominatim + OSRM, miễn phí) hoặc Goong."""
import json, math, re, time, urllib.parse, urllib.request
import store

UA = "MocTamQuote/1.0 (desktop quoting tool)"
FALLBACK_ORIGIN = (10.9047, 106.7690)  # tâm Dĩ An – chỉ dùng khi không định vị được nhà máy


def _get(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "vi"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def variants(addr):
    parts = [x.strip() for x in addr.split(",") if x.strip()]
    out = []
    for i in range(len(parts)):
        s = ", ".join(parts[i:])
        out.append(s)
        s2 = re.sub(r"^(số\s*)?\d[\w/\-]*\s+", "", s, flags=re.I)
        if s2 != s:
            out.append(s2)
    seen, res = set(), []
    for v in out:
        if v not in seen and len(v) > 3:
            seen.add(v)
            res.append(v)
    return res[:6]


def geocode(addr, settings):
    cache = store.load_json("geocache.json", {})
    if addr in cache:
        return cache[addr]
    res = None
    for i, q in enumerate(variants(addr)):
        try:
            if settings.get("geocoder") == "goong" and settings.get("goong_key"):
                d = _get("https://rsapi.goong.io/geocode?address=%s&api_key=%s"
                         % (urllib.parse.quote(q), settings["goong_key"]))
                if d.get("results"):
                    loc = d["results"][0]["geometry"]["location"]
                    res = (loc["lat"], loc["lng"], d["results"][0].get("formatted_address", q), i)
            else:
                d = _get("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=vn&q="
                         + urllib.parse.quote(q))
                if d:
                    res = (float(d[0]["lat"]), float(d[0]["lon"]), d[0].get("display_name", q), i)
                time.sleep(1.1)
        except Exception:
            time.sleep(1.1)
        if res:
            break
    if not res:
        raise RuntimeError("Không tìm thấy địa chỉ trên bản đồ. Hãy thêm phường/quận/tỉnh hoặc nhập km thủ công.")
    cache[addr] = list(res)
    for k in list(cache)[:max(0, len(cache) - 400)]:
        cache.pop(k, None)
    store.save_json("geocache.json", cache)
    return res


def haversine(a, b):
    R = 6371.0
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp, dl = p2 - p1, math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def route_km(a, b, settings):
    if settings.get("geocoder") == "goong" and settings.get("goong_key"):
        d = _get("https://rsapi.goong.io/Direction?origin=%f,%f&destination=%f,%f&vehicle=car&api_key=%s"
                 % (a[0], a[1], b[0], b[1], settings["goong_key"]))
        return d["routes"][0]["legs"][0]["distance"]["value"] / 1000.0, "Goong"
    d = _get("https://router.project-osrm.org/route/v1/driving/%f,%f;%f,%f?overview=false" % (a[1], a[0], b[1], b[0]))
    return d["routes"][0]["distance"] / 1000.0, "OSRM"


def origin_coords(settings):
    o = settings["origin"]
    if o.get("lat") and o.get("lng"):
        return (float(o["lat"]), float(o["lng"])), ""
    try:
        r = geocode(o["address"], settings)
        return (r[0], r[1]), "" if r[3] == 0 else "Vị trí nhà máy chỉ định vị gần đúng – nên nhập tọa độ chính xác trong Cài đặt."
    except Exception:
        return FALLBACK_ORIGIN, "Không định vị được nhà máy – đang dùng tọa độ tâm Dĩ An. Hãy nhập tọa độ trong Cài đặt."


def measure(addr, settings):
    org, warn = origin_coords(settings)
    lat, lng, disp, lvl = geocode(addr, settings)
    notes = [warn] if warn else []
    if lvl > 0:
        notes.append("Địa chỉ chỉ khớp đến mức tổng quát hơn (bỏ bớt số nhà/đường) – kiểm tra lại khoảng cách.")
    try:
        km, method = route_km(org, (lat, lng), settings)
    except Exception:
        km = haversine(org, (lat, lng)) * settings.get("routing_factor", 1.3)
        method = "ước tính (chim bay x hệ số)"
        notes.append("Không gọi được dịch vụ đường bộ – dùng ước tính.")
    return {"km": round(km, 1), "method": method, "found": disp, "lat": lat, "lng": lng, "notes": notes}
