# -*- coding: utf-8 -*-
"""Phiên bản phần mềm + địa chỉ kiểm tra cập nhật online. File này nằm trong gói cập nhật nên phiên bản tự tăng theo mỗi lần phát hành."""
VERSION = "1.1.1"

# Địa chỉ file version.json trên máy chủ cập nhật (xem HUONG_DAN_UPDATE.txt). Để trống = tắt kiểm tra cập nhật.
# Ví dụ: "https://raw.githubusercontent.com/TEN-GITHUB/TEN-REPO/main/update/version.json"
UPDATE_URL = "https://raw.githubusercontent.com/zjzjpro/Update-Moc-Tam-Quote/main/update/version.json"
