# -*- coding: utf-8 -*-
"""Đọc bảng giá từ Excel / PDF / Word / CSV -> danh sách sản phẩm (nhận dạng cột theo tiêu đề)."""
import csv, io, os, re, unicodedata


def strip_acc(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D").lower()


def clean(v):
    if v is None:
        return ""
    if isinstance(v, float) and v == int(v):
        v = int(v)
    return re.sub(r"\s+", " ", str(v)).strip()


def to_num(v):
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip().replace("đ", "").replace("₫", "").replace(" ", "")
    if re.fullmatch(r"\d{1,3}([.,]\d{3})+|\d+", t):
        return float(re.sub(r"[.,]", "", t))
    if re.fullmatch(r"\d+[.,]\d{1,2}", t):
        return float(t.replace(",", "."))
    return None


KEYS = [
    ("stt", ["stt", "tt"]),
    ("name", ["hang muc", "ten san pham", "san pham", "ten hang"]),
    ("desc", ["dien giai", "mo ta", "quy cach", "chat lieu"]),
    ("w", ["rong"]), ("h", ["cao"]), ("d", ["sau"]),
    ("unit", ["dvt", "don vi"]),
    ("retail", ["don ban le", "gia niem yet", "gia le", "gia goc", "don gia"]),
    ("note", ["ghi chu"]),
    ("img", ["hinh anh", "hinh"]),
]
TIER_RE = re.compile(r"ck\s*[-–]?\s*(\d+(?:[.,]\d+)?)\s*%")
DEFAULT_16 = {"stt": 0, "name": 1, "desc": 2, "w": 3, "h": 4, "d": 5, "unit": 6, "retail": 7, "img": 14, "note": 15}
DEFAULT_TIERS = {8: 15, 9: 18, 10: 20, 11: 27, 12: 30, 13: 32}


def fmt_pct(p):
    p = float(p)
    return str(int(p)) if p == int(p) else str(p)


def match_key(cell):
    t = strip_acc(cell)
    m = TIER_RE.search(t)
    if m:
        return ("tier", float(m.group(1).replace(",", ".")))
    t = re.sub(r"[^a-z0-9 ]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    for key, kws in KEYS:
        for kw in kws:
            if (len(kw) <= 4 and t == kw) or (len(kw) > 4 and kw in t):
                return (key, None)
    return None


def dimstr(s):
    return re.sub(r"\s+", "", s).replace(",", "")


def digits(s):
    return re.sub(r"\D", "", str(s or ""))


def product_key(p):
    n = re.sub(r"[^a-z0-9]", "", strip_acc(p.get("name", "")))
    return f"{n}|{digits(p.get('w'))}|{digits(p.get('h'))}|{digits(p.get('d'))}"


def name_key(p):
    return re.sub(r"[^a-z0-9]", "", strip_acc(p.get("name", "")))


def spec_key(p):
    try:
        r = int(float(p.get("retail") or 0))
    except (TypeError, ValueError):
        r = 0
    return f"{digits(p.get('w'))}|{digits(p.get('h'))}|{digits(p.get('d'))}|{r}"


def match_entry(p, entries):
    """Tìm sản phẩm khớp trong danh sách `entries` (đọc từ file báo giá):
    1) trùng tên + kích thước  2) trùng tên (nếu tên đó duy nhất trong file)  3) trùng kích thước + giá lẻ (nếu duy nhất)."""
    k = product_key(p)
    for e in entries:
        if product_key(e) == k:
            return e
    nk = name_key(p)
    if nk:
        c = [e for e in entries if name_key(e) == nk]
        if len(c) == 1:
            return c[0]
    if float(p.get("retail") or 0) > 0:
        sk = spec_key(p)
        c = [e for e in entries if spec_key(e) == sk]
        if len(c) == 1:
            return c[0]
    return None


class Parser:
    """Nhận từng bảng (list các dòng, mỗi dòng là list ô). Nhớ cột/danh mục giữa các trang."""

    def __init__(self, series="", category=""):
        self.map = None
        self.tiers = {}
        self.series = series
        self.category = category

    def feed(self, rows):
        out = []
        for ri, row in enumerate(rows):
            cells = [clean(c) for c in row]
            if not any(cells):
                continue
            hits, tiers = {}, {}
            for ci, c in enumerate(cells):
                if not c or len(c) > 40:
                    continue
                k = match_key(c)
                if not k:
                    continue
                if k[0] == "tier":
                    tiers[ci] = k[1]
                else:
                    hits.setdefault(k[0], ci)
            nnum = sum(1 for c in cells if to_num(c) is not None)
            if len(hits) + (1 if tiers else 0) >= 2 and nnum <= 1:
                if self.map is None or "name" in hits or "retail" in hits:
                    if "name" in hits or "retail" in hits:
                        self.map, self.tiers = {}, {}
                    elif self.map is None:
                        self.map = {}
                self.map.update(hits)
                self.tiers.update(tiers)
                continue
            if self.map is None and len(cells) == 16:
                self.map, self.tiers = dict(DEFAULT_16), dict(DEFAULT_TIERS)
            nonempty = [c for c in cells if c]
            if len(nonempty) == 1 and not re.search(r"\d", nonempty[0]) and len(nonempty[0]) < 60:
                t = nonempty[0]
                self.category = t.capitalize() if t.isupper() else t
                continue
            p = self._product(cells)
            if p:
                p["_ri"] = ri
                out.append(p)
        return out

    def _product(self, cells):
        m = self.map or {}

        def g(k):
            i = m.get(k)
            return cells[i] if i is not None and i < len(cells) else ""

        retail = to_num(g("retail"))
        file_prices = {}
        if "retail" not in m:  # heuristic khi không có tiêu đề
            nums = [(i, to_num(c)) for i, c in enumerate(cells) if (to_num(c) or 0) >= 10000]
            if not nums:
                return None
            retail = nums[0][1]
        for ci, pct in self.tiers.items():
            v = to_num(cells[ci]) if ci < len(cells) else None
            if v:
                file_prices[fmt_pct(pct)] = v
        name = g("name") or ("" if "name" in m else cells[1] if len(cells) > 1 else "")
        if not retail or retail < 1000 or not (name or g("desc")):
            return None
        note = strip_acc(g("note"))
        asm = moist = 0
        a = re.search(r"lap rap\D*?([\d.,]+)", note)
        b = re.search(r"van chong am\D*?([\d.,]+)", note)
        if a:
            asm = to_num(a.group(1).rstrip(".,")) or 0
        if b:
            moist = to_num(b.group(1).rstrip(".,")) or 0
        return {
            "series": self.series, "category": self.category or "Khác", "name": name,
            "desc": g("desc"), "w": dimstr(g("w")), "h": dimstr(g("h")), "d": dimstr(g("d")),
            "unit": g("unit") or "BỘ", "retail": retail, "file_prices": file_prices,
            "assembly": asm, "moisture": moist, "ship_class": "auto", "_img": None,
        }


def _png(data):
    from PIL import Image
    im = Image.open(io.BytesIO(data))
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGB")
    b = io.BytesIO()
    im.save(b, "PNG")
    return b.getvalue()


def read_excel(path, series=""):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    out = []
    for ws in wb.worksheets:
        parser = Parser(series=series)
        rows = [list(r) for r in ws.iter_rows(values_only=True)]
        prods = parser.feed(rows)
        for im in getattr(ws, "_images", []):
            try:
                a = im.anchor
                r0 = a._from.row
                to = getattr(a, "to", None)
                r = (r0 + to.row) / 2 if to is not None else r0 + 0.5
                data = _png(im._data())
            except Exception:
                continue
            cand = [p for p in prods if p["_ri"] <= r]
            if cand:
                p = max(cand, key=lambda x: x["_ri"])
                if p["_img"] is None:
                    p["_img"] = data
        out += prods
    return out


def _cell_text(page, bbox):
    """Lấy chữ trong 1 ô theo đúng thứ tự dòng của PDF (find_tables().extract() hay trộn lẫn các dòng khi chữ nhỏ, sát nhau)."""
    import fitz
    r = fitz.Rect(bbox)
    r = fitz.Rect(r.x0 + 0.5, r.y0 + 0.5, r.x1 - 0.5, r.y1 - 0.5)
    words = [w for w in page.get_text("words", clip=r)
             if r.x0 - 1 <= (w[0] + w[2]) / 2 <= r.x1 + 1 and r.y0 - 1 <= (w[1] + w[3]) / 2 <= r.y1 + 1]
    words.sort(key=lambda w: (w[5], w[6], w[7]))
    lines, cur = [], None
    for w in words:
        key = (w[5], w[6])
        if key != cur:
            lines.append([])
            cur = key
        lines[-1].append(w[4])
    return "\n".join(" ".join(l) for l in lines)


def _table_rows(page, t):
    out = []
    for row in t.rows:
        out.append([(_cell_text(page, c) if c else "") for c in row.cells])
    return out


def read_pdf(path, series=""):
    import fitz  # PyMuPDF
    doc = fitz.open(path)
    parser = Parser(series=series)
    out = []
    for page in doc:
        try:
            tabs = page.find_tables()
        except Exception:
            continue
        infos = page.get_image_info()
        for t in tabs.tables:
            try:
                rows = _table_rows(page, t)
            except Exception:
                rows = t.extract()
            prods = parser.feed(rows)
            for p in prods:
                if p["_ri"] >= len(t.rows):
                    continue
                row = t.rows[p["_ri"]]
                bb = fitz.Rect(row.bbox)
                best, best_score = None, 0.0
                for inf in infos:
                    r = fitz.Rect(inf["bbox"])
                    if not (max(r.width, r.height) > 20 and min(r.width, r.height) > 8 and (r.x0 + r.x1) / 2 > bb.x0 + bb.width * 0.55):
                        continue
                    # ảnh có thể trải qua nhiều dòng (1 ảnh dùng chung cho 2 dòng liền nhau) -> tính phần chồng lấn theo chiều dọc
                    ov = min(bb.y1, r.y1) - max(bb.y0, r.y0)
                    if ov <= 0:
                        continue
                    score = ov / min(bb.height, r.height)
                    if score > best_score and score >= 0.3:
                        best, best_score = r, score
                if best is not None:
                    try:
                        p["_img"] = page.get_pixmap(clip=best, dpi=150).tobytes("png")
                    except Exception:
                        pass
            out += prods
    return out


def read_docx(path, series=""):
    import docx
    d = docx.Document(path)
    parser = Parser(series=series)
    out = []
    for t in d.tables:
        out += parser.feed([[c.text for c in r.cells] for r in t.rows])
    return out


def read_csv(path, series=""):
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        txt = f.read()
    try:
        dialect = csv.Sniffer().sniff(txt[:2000], delimiters=",;\t")
    except Exception:
        dialect = csv.excel
    return Parser(series=series).feed(list(csv.reader(io.StringIO(txt), dialect)))


def import_file(path, series=""):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        res = read_excel(path, series)
    elif ext == ".pdf":
        res = read_pdf(path, series)
    elif ext == ".docx":
        res = read_docx(path, series)
    elif ext in (".csv", ".txt", ".tsv"):
        res = read_csv(path, series)
    elif ext == ".xls":
        raise ValueError("File .xls cũ chưa hỗ trợ – hãy lưu lại thành .xlsx rồi nhập.")
    else:
        raise ValueError(f"Chưa hỗ trợ định dạng {ext}")
    if not res:
        raise ValueError("Không nhận dạng được sản phẩm nào. Kiểm tra file có bảng với cột tên, giá bán lẻ…")
    return res


# ---------- Bảng phí ship ----------
def file_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        import fitz
        return "\n".join(p.get_text() for p in fitz.open(path))
    if ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        return "\n".join(" ".join(clean(c) for c in r if c is not None)
                         for ws in wb.worksheets for r in ws.iter_rows(values_only=True))
    if ext == ".docx":
        import docx
        d = docx.Document(path)
        return "\n".join(" ".join(c.text for c in r.cells) for t in d.tables for r in t.rows)
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        return f.read()


def parse_shipping_text(text, settings):
    """Trả về (settings_mới, báo_cáo). Chỉ ghi đè những gì đọc được."""
    import copy
    s = copy.deepcopy(settings)
    t = strip_acc(text)
    rep = []
    zones = {z["key"]: z for z in s["zones"]}

    def money(x):
        return to_num(x.strip(".,")) if x else None

    m = re.search(r"di an\s+di an\s+([\d.,]+)", t)
    if m and money(m.group(1)):
        zones["dian"]["fee"] = money(m.group(1))
        rep.append(f"Dĩ An: {int(zones['dian']['fee']):,}đ")
    for m in re.finditer(r"vung\s*(\d)\s*(\d+)\s*[-–—]\s*(\d+)\s*km\s*([\d.,]+)", t):
        k = f"v{m.group(1)}"
        if k in zones and money(m.group(4)):
            z = zones[k]
            z["min_km"], z["max_km"], z["fee"] = int(m.group(2)), int(m.group(3)), money(m.group(4))
            z["name"] = f"Vùng {m.group(1)} ({m.group(2)}–{m.group(3)} km)"
            rep.append(f"{z['name']}: {int(z['fee']):,}đ")
    names = {"nho": "small", "trung binh": "medium", "lon": "large"}
    cls = {c["key"]: c for c in s["ship_classes"]}
    for m in re.finditer(r"san pham\s*(nho|trung binh|lon)\s*(\d+)\s*%", t):
        c = cls[names[m.group(1)]]
        c["mult"] = int(m.group(2)) / 100
        rep.append(f"Sản phẩm {c['name']}: x{c['mult']}")
    dims = re.findall(r"rong\s*(\d+)\s*mm\s*,?\s*cao\s*(\d+)\s*m*\s*,?\s*sau\s*(\d+)", t)
    kgs = re.findall(r"trong luong gioi han\s*(\d+)\s*kg", t)
    for key, i in (("small", 0), ("medium", 1)):
        if i < len(dims):
            cls[key]["max_dims"] = [int(x) for x in dims[i]]
            rep.append(f"Giới hạn {cls[key]['name']}: {' x '.join(dims[i])} mm")
        if i < len(kgs):
            cls[key]["max_kg"] = int(kgs[i])
    pol = s["ship_policy"]
    for m in re.finditer(r"don tu\s*(\d+)\s*trieu\s*(giam\s*(\d+)\s*%|mien phi)", t):
        v = int(m.group(1)) * 1000000
        if m.group(3):
            pol["half_from"], pol["half_pct"] = v, int(m.group(3))
            rep.append(f"Đơn từ {m.group(1)} triệu: giảm {m.group(3)}% phí ship")
        else:
            pol["free_from"] = v
            rep.append(f"Đơn từ {m.group(1)} triệu: miễn phí ship (vùng < 30 km)")
    return s, rep
