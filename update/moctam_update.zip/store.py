# -*- coding: utf-8 -*-
"""Lưu trữ dữ liệu (JSON trong %APPDATA%\\MocTamQuote) + cài đặt mặc định."""
import copy, io, json, os, re, shutil, sys, uuid

APP_NAME = "MocTamQuote"


def data_dir():
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    p = os.path.join(base, APP_NAME)
    os.makedirs(os.path.join(p, "images"), exist_ok=True)
    return p


def resource(rel):
    """Đường dẫn tài nguyên đi kèm (logo…), chạy được cả khi đóng gói PyInstaller."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def path(name):
    return os.path.join(data_dir(), name)


def image_path(pid):
    return os.path.join(data_dir(), "images", f"{pid}.png")


def cleanup_tmp(max_age_h=24):
    """Xoá các tệp *.tmp do chính phần mềm tạo (trong thư mục dữ liệu của nó) nếu bị bỏ lại > 24 giờ."""
    import time
    d = data_dir()
    for fn in os.listdir(d):
        fp = os.path.join(d, fn)
        if fn.endswith(".tmp") and os.path.isfile(fp) and time.time() - os.path.getmtime(fp) > max_age_h * 3600:
            try:
                os.remove(fp)
            except OSError:
                pass


def log_error(text, limit=400_000):
    """Ghi nhật ký lỗi (giới hạn dung lượng) để dễ tìm nguyên nhân khi có sự cố."""
    import datetime
    fp = path("error.log")
    try:
        if os.path.exists(fp) and os.path.getsize(fp) > limit:
            os.remove(fp)
        with open(fp, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}]\n{text}\n")
    except OSError:
        pass


def load_json(name, default):
    try:
        with open(path(name), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return copy.deepcopy(default)


def save_json(name, data):
    tmp = path(name) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path(name))


DEFAULT_SETTINGS = {
    "company": {
        "name": "CÔNG TY TNHH MỘC TÂM FURNITURE",
        "address": "138/28 Đường Mạch Thị Liễu, Phường Dĩ An, TPHCM",
        "phone": "0981 707 222 (Mr.Hoàn)",
        "tax": "3702908327",
    },
    "origin": {"address": "138/28 Đường Mạch Thị Liễu, Phường Dĩ An, TPHCM", "lat": None, "lng": None},
    "moist_fee": 300000,        # phụ thu mặc định cho mỗi sản phẩm kèm ván chống ẩm (đ) – sửa tay được từng dòng khi lên đơn
    "geocoder": "osm",          # osm (miễn phí) | goong (cần API key)
    "goong_key": "",
    "routing_factor": 1.3,      # dùng khi mất mạng: đường chim bay x hệ số
    # Các mức giá (pct = % chiết khấu so với đơn bán lẻ)
    "tiers": [
        {"key": "list", "label": "Giá niêm yết (đơn bán lẻ)", "pct": 0},
        {"key": "ck15", "label": "Giá bán (CK 15%)", "pct": 15},
        {"key": "ck18", "label": "Giá sỉ 2-4 món (CK 18%)", "pct": 18},
        {"key": "ck20", "label": "Giá sỉ từ 5 món (CK 20%)", "pct": 20},
        {"key": "dl1", "label": "Đại lý cấp 1 (CK 27%)", "pct": 27},
        {"key": "dl2", "label": "Đại lý cấp 2 (CK 30%)", "pct": 30},
        {"key": "dl3", "label": "Đại lý cấp 3 (CK 32%)", "pct": 32},
    ],
    # Tự động chọn mức giá theo tổng số lượng
    "auto_tier": [
        {"min_qty": 1, "tier": "ck15"},
        {"min_qty": 2, "tier": "ck18"},
        {"min_qty": 5, "tier": "ck20"},
    ],
    "zones": [
        {"key": "dian", "name": "Dĩ An", "fee": 100000, "min_km": None, "max_km": None,
         "match": ["Dĩ An"], "free_eligible": True},
        {"key": "v1", "name": "Vùng 1 (0–10 km)", "fee": 200000, "min_km": 0, "max_km": 10,
         "match": [], "free_eligible": True},
        {"key": "v2", "name": "Vùng 2 (10–20 km)", "fee": 250000, "min_km": 10, "max_km": 20,
         "match": [], "free_eligible": True},
        {"key": "v3", "name": "Vùng 3 (20–30 km)", "fee": 350000, "min_km": 20, "max_km": 30,
         "match": [], "free_eligible": True},
        {"key": "v4", "name": "Vùng 4 (Ngoại tỉnh – Lalamove)", "fee": None, "min_km": 30, "max_km": None,
         "match": [], "free_eligible": False},
    ],
    "ship_classes": [
        {"key": "small", "name": "Nhỏ", "mult": 0.5, "max_dims": [1000, 600, 400], "max_kg": 50},
        {"key": "medium", "name": "Trung bình", "mult": 1.0, "max_dims": [2000, 1000, 600], "max_kg": 150},
        {"key": "large", "name": "Lớn", "mult": 1.5, "max_dims": None, "max_kg": None},
    ],
    # Từ khóa tên sản phẩm -> phân loại (khớp từ trên xuống, ưu tiên hơn kích thước)
    "class_keywords": [
        ["bọc", "small"], ["giường", "medium"], ["bàn ăn", "medium"], ["mặt đá", "medium"],
        ["kệ tivi", "medium"], ["tủ giày", "medium"], ["tủ giầy", "medium"], ["bàn học", "medium"],
        ["ghế", "small"], ["bông sen", "small"], ["tấm chống", "small"], ["bàn thờ treo", "small"],
    ],
    "ship_policy": {"half_from": 10000000, "half_pct": 50, "free_from": 15000000},
    # max: 1 chuyến xe -> lấy mức phân loại lớn nhất trong đơn; sum: cộng theo từng dòng sản phẩm
    "ship_mode": "max",
    "lalamove_per_km": 12000,   # ngoại tỉnh (Lalamove): phí = số km đường bộ x đơn giá/km
    # Thông tin in trên biên lai
    "receipt": {
        "manager": "Admin", "manager_phone": "0862 032 968", "tech": "Cương", "director": "PHAN VĂN HOÀN",
        "quote_days": 14, "order_days": 7,
        "warranty": "*** BẢO HÀNH : Sản phẩm được bảo hành 12 tháng kể từ ngày bàn giao/nghiệm thu đối với các lỗi kỹ thuật phát sinh do quá trình sản xuất và lắp đặt. Không áp dụng bảo hành đối với hư hỏng do quá trình sử dụng, tác động ngoại lực hoặc tự ý sửa chữa, thay đổi sản phẩm.",
        "quote_extra": "* Phụ Kiện ray bi và bản lề đi kèm mặc định là Vikini giảm chấn cho đơn hàng ko phải ván An Cường, phụ kiện ray bi bản lề đi kèm áp dụng cho đơn hàng ván An Cường là Imundex.",
    },
}


def load_settings():
    s = load_json("settings.json", {})
    out = copy.deepcopy(DEFAULT_SETTINGS)
    for k, v in s.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k].update(v)
        else:
            out[k] = v
    return out


def save_settings(s):
    save_json("settings.json", s)


def attach_bundled_images(products):
    """Chép ảnh đi kèm phần mềm (trích từ bảng giá hàng rời) cho sản phẩm chưa có ảnh – khớp theo tên + kích thước."""
    try:
        with open(resource("assets/product_images/index.json"), encoding="utf-8") as f:
            idx = json.load(f)
    except Exception:
        return 0
    from importer import product_key, name_key, spec_key
    n = 0
    for p in products:
        dst = image_path(p["id"])
        if os.path.exists(dst):
            continue
        # khớp tên+kích thước -> khớp tên (duy nhất) -> khớp kích thước+giá lẻ (duy nhất)
        fn = idx.get(product_key(p)) or idx.get("name:" + name_key(p)) or (
            idx.get("spec:" + spec_key(p)) if float(p.get("retail") or 0) > 0 else None)
        src = resource("assets/product_images/" + fn) if fn else None
        if not os.path.exists(dst) and src and os.path.exists(src):
            try:
                shutil.copyfile(src, dst)
                n += 1
            except OSError:
                pass
    return n


def attach_bundled_wood_images(wood):
    d = resource("assets/wood_images")
    if not os.path.isdir(d):
        return 0
    ids = {it["id"] for k in wood.values() for it in k.get("items", [])}
    n = 0
    for fn in os.listdir(d):
        iid = fn[:-4]
        dst = image_path("wood_" + iid)
        if fn.endswith(".png") and iid in ids and not os.path.exists(dst):
            try:
                shutil.copyfile(os.path.join(d, fn), dst)
                n += 1
            except OSError:
                pass
    return n


def load_products():
    p = load_json("products.json", None)
    if p is None:
        from seed import seed_products
        p = seed_products()
        save_json("products.json", p)
    if ensure_builtin_products(p):
        save_json("products.json", p)
    attach_bundled_images(p)
    return p


# Sản phẩm có sẵn được thêm 1 lần vào danh mục (kể cả máy đã có products.json cũ). Xóa đi thì không tự thêm lại.
BUILTIN_PRODUCTS = [
    {"id": "van-chong-am", "series": "Phụ kiện", "category": "Ván chống ẩm", "name": "VÁN CHỐNG ẨM",
     "desc": "Nâng cấp sang ván MDF chống ẩm (thêm theo từng đơn khi khách cần)", "w": "", "h": "", "d": "", "unit": "Cái",
     "retail": 300000, "file_prices": {}, "assembly": 0, "moisture": 0, "ship_class": "auto",
     "addon": True},      # addon: giá cố định, không tính vào mức giá/KM/ship (như phụ phí)
]


def ensure_builtin_products(products):
    s = load_json("settings.json", {})
    seeded = list(s.get("seeded_products", []))
    changed = False
    for b in BUILTIN_PRODUCTS:
        if b["id"] in seeded:
            continue
        if not any(x.get("id") == b["id"] for x in products):
            products.append(copy.deepcopy(b))
            changed = True
        seeded.append(b["id"])
    if seeded != s.get("seeded_products", []):
        s["seeded_products"] = seeded
        save_json("settings.json", s)
    return changed


def load_wood():
    """Danh mục hàng gỗ: {'roi': {...}, 'congtrinh': {...}} – mỗi loại có items + footer (ghi chú cuối bảng)."""
    w = load_json("wood.json", None)
    if w is None:
        try:
            with open(resource("assets/wood_catalog.json"), encoding="utf-8") as f:
                base = json.load(f)
        except Exception:
            base = {"items": [], "footer": []}
        w = {"roi": copy.deepcopy(base), "congtrinh": copy.deepcopy(base)}
        save_json("wood.json", w)
    attach_bundled_wood_images(w)
    return w


def save_wood(w):
    save_json("wood.json", w)


def save_products(p):
    save_json("products.json", p)


def save_image_bytes(pid, data):
    from PIL import Image
    im = Image.open(io.BytesIO(data))
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGB")
    im.save(image_path(pid), "PNG")


def merge_products(products, new, mode="merge"):
    """mode: merge = cập nhật sản phẩm trùng + thêm mới; replace = thay toàn bộ."""
    from importer import product_key
    added = updated = 0
    if mode == "replace":
        products.clear()
    index = {product_key(p): p for p in products}
    for n in new:
        img = n.pop("_img", None)
        n.pop("_ri", None)
        k = product_key(n)
        if k in index:
            p = index[k]
            for f in ("retail", "file_prices", "w", "h", "d", "unit"):
                if n.get(f):
                    p[f] = n[f]
            if n.get("desc"):
                p["desc"] = n["desc"]
            for f in ("assembly", "moisture"):
                if n.get(f):
                    p[f] = n[f]
            if img:
                save_image_bytes(p["id"], img)
            updated += 1
        else:
            n["id"] = uuid.uuid4().hex[:12]
            n.setdefault("ship_class", "auto")
            if img:
                save_image_bytes(n["id"], img)
            products.append(n)
            index[k] = n
            added += 1
    return added, updated
